package se.csn.backend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import se.csn.backend.models.Kvalitetsmatt;

@CrossOrigin(origins = "*")
public interface KvalitetsmattRepository extends MongoRepository<Kvalitetsmatt, String> {
    List<Kvalitetsmatt> deleteByNamn(String namn);

    boolean existsByNamn(String namn);

    long deleteKvalitetsmattByNamn(String namn);

    @Query("{'namn': ?0}")
    Optional<Kvalitetsmatt> findByNamn(String namn);

}
