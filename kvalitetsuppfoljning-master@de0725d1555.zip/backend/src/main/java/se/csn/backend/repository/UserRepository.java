package se.csn.backend.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import se.csn.backend.models.User;

@CrossOrigin(origins = "*")
public interface UserRepository extends MongoRepository<User, String> {

}
