package se.csn.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Enkatsvar;
import se.csn.backend.models.EnkatsvarCreatorRequest;
import se.csn.backend.models.QuestionBase;
import se.csn.backend.models.QuestionBaseCreatorRequest;
import se.csn.backend.models.QuestionBaseListCreatorRequest;
import se.csn.backend.services.EnkatsvarService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/enkatsvar")
public class EnkatsvarController {
    private final EnkatsvarService enkatsvarService;

    @Autowired
    EnkatController enkatController;

    public EnkatsvarController(EnkatsvarService enkatsvarService) {
        this.enkatsvarService = enkatsvarService;
    }

    @PostMapping
    public ResponseEntity addEnkatsvar(@RequestBody EnkatsvarCreatorRequest enkatsvarCreatorRequest) {
        QuestionBase[] questionBases = enkatsvarCreatorRequest.getQuestionBases();
        String inskickadAv = enkatsvarCreatorRequest.getInskickadAv();
        String enkatnamn = enkatsvarCreatorRequest.getEnkatNamn();
        Enkatsvar enkatsvar = new Enkatsvar(questionBases);
        enkatsvar.setInskickadAv(inskickadAv);
        enkatsvar.setEnkatnamn(enkatnamn);
        enkatsvarService.addEnkatsvar(enkatsvar);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<List<Enkatsvar>> getAllEnkatsvar() {
        return ResponseEntity.ok(enkatsvarService.getAllEnkatsvar());
    }

    /*
     * @GetMapping("/{id}") public ResponseEntity<Enkat>
     * getEnkatByEnkatNamn(@PathVariable String enkatNamn) { return
     * ResponseEntity.ok(enkatService.getEnkatByEnkatNamn(enkatNamn)); }
     */

    @DeleteMapping()
    public ResponseEntity deleteAllEnkatsvar() {
        enkatsvarService.deleteAll();
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity updateAnswers(@PathVariable String id,
            @RequestBody QuestionBaseListCreatorRequest questionBaseListCreatorRequest) {
        QuestionBase[] qbList = questionBaseListCreatorRequest.getQuestionBases();

        enkatsvarService.setValuesForQuestionBases(qbList, id);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
