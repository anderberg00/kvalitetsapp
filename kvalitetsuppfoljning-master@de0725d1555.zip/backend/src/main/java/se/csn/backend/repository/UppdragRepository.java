package se.csn.backend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import se.csn.backend.models.Uppdrag;

@CrossOrigin(origins = "*")
public interface UppdragRepository extends MongoRepository<Uppdrag, String> {
    List<Uppdrag> deleteByNamn(String namn);

    boolean existsByNamn(String namn);

    long deleteUppdragByNamn(String namn);

    @Query("{'namn': ?0}")
    Optional<Uppdrag> findByNamn(String namn);

    /*
     * @Query("{'namn': ?0}") Optional<Uppdrag> findByNamn(String namn);
     */

}
