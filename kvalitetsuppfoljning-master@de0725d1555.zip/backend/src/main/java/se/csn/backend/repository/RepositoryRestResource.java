package se.csn.backend.repository;

public @interface RepositoryRestResource {

}
