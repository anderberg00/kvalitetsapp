package se.csn.backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Kvalitetsmatt;
import se.csn.backend.services.KvalitetsmattService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/kvalitetsmatt")
public class KvalitetsmattController {

    private final KvalitetsmattService kvalitetsmattService;

    public KvalitetsmattController(KvalitetsmattService kvalitetsmattService) {
        this.kvalitetsmattService = kvalitetsmattService;
    }

    @PostMapping
    public ResponseEntity<Kvalitetsmatt> addKvalitetsmatt(@RequestBody Kvalitetsmatt kvalitetsmatt) {
        Kvalitetsmatt _kvalitetsmatt = new Kvalitetsmatt(kvalitetsmatt.getNamn());
        kvalitetsmattService.addKvalitetsmatt(_kvalitetsmatt);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<List<Kvalitetsmatt>> getAllKvalitetsmatt() {
        return ResponseEntity.ok(kvalitetsmattService.getAllKvalitetsmatt());
    }

    @GetMapping("/{namn}")
    public ResponseEntity<Kvalitetsmatt> getKvalitetsmattByNamn(@PathVariable String namn) {
        return ResponseEntity.ok(kvalitetsmattService.findByNamn(namn));
    }

    @DeleteMapping("/{namn}")
    public ResponseEntity deleteKvalitetsmattService(@PathVariable String namn) {
        kvalitetsmattService.deleteByNamn(namn);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping()
    public ResponseEntity deleteAllKvalitetsmatt() {
        kvalitetsmattService.deleteAll();
        return ResponseEntity.noContent().build();
    }

}
