package se.csn.backend.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import se.csn.backend.models.Rekommendation;

@CrossOrigin(origins = "*")
public interface RekommendationRepository extends MongoRepository<Rekommendation, String> {
    void deleteById(String id);

    boolean existsById(String id);

    Optional<Rekommendation> findById(String id);

}
