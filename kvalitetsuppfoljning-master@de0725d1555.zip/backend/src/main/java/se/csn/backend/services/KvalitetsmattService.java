package se.csn.backend.services;

import java.util.List;

import org.springframework.stereotype.Service;

import se.csn.backend.models.Kvalitetsmatt;
import se.csn.backend.repository.KvalitetsmattRepository;

@Service
public class KvalitetsmattService {

    private final KvalitetsmattRepository kvalitetsmattRepository;

    public KvalitetsmattService(KvalitetsmattRepository kvalitetsmattRepository) {
        this.kvalitetsmattRepository = kvalitetsmattRepository;
    }

    public void addKvalitetsmatt(Kvalitetsmatt kvalitetsmatt) {
        if (kvalitetsmattRepository.existsByNamn(kvalitetsmatt.getNamn())) {
            throw new RuntimeException(
                    String.format("Kvalitetsmatt already exists with namn #s", kvalitetsmatt.getNamn()));
        }
        kvalitetsmattRepository.insert(kvalitetsmatt);
    }

    public List<Kvalitetsmatt> getAllKvalitetsmatt() {
        return kvalitetsmattRepository.findAll();
    }

    public Kvalitetsmatt findByNamn(String namn) {
        return kvalitetsmattRepository.findByNamn(namn)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find Kvalitetsmatt by name #s", namn)));
    }

    public void deleteByNamn(String namn) {
        this.kvalitetsmattRepository.deleteKvalitetsmattByNamn(namn);
    }

    public void deleteAll() {
        this.kvalitetsmattRepository.deleteAll();
    }
}
