package se.csn.backend.models;

public class QuestionBaseCreatorRequest {
    private QuestionBase questionBase;
    private String kvalitetsmattNamn;

    public QuestionBaseCreatorRequest(QuestionBase questionBase, String kvalitetsmattNamn) {
        this.questionBase = questionBase;
        this.kvalitetsmattNamn = kvalitetsmattNamn;
    }

    public QuestionBaseCreatorRequest() {
    }

    /**
     * @return String return the kvalitetsmattNamn
     */
    public String getKvalitetsmattNamn() {
        return kvalitetsmattNamn;
    }

    /**
     * @param kvalitetsmattNamn the kvalitetsmattNamn to set
     */
    public void setKvalitetsmattNamn(String kvalitetsmattNamn) {
        this.kvalitetsmattNamn = kvalitetsmattNamn;
    }

    /**
     * @return QuestionBase return the questionBase
     */
    public QuestionBase getQuestionBase() {
        return questionBase;
    }

    /**
     * @param questionBase the questionBase to set
     */
    public void setQuestionBase(QuestionBase questionBase) {
        this.questionBase = questionBase;
    }

}
