package se.csn.backend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import se.csn.backend.models.Enkat;
import se.csn.backend.models.Enkatsvar;

@CrossOrigin(origins = "*")
public interface EnkatsvarRepository extends MongoRepository<Enkatsvar, String> {

}
