package se.csn.backend.models;

import java.util.List;
import java.util.Map;

public class ArendeCreatorRequest {

    private String id;
    private String ar;
    private String kontor;
    private String slutdatum;
    private String notifieringsdatum;
    private String handlaggareNotifiering;
    private String forstaHandlaggare;
    private String andraHandlaggare;
    private String status;
    private String verksamhetsomradeNamn;
    private String uppdragNamn;
    private String enkatNamn;
    private Object[] varden;
    private boolean arGranskad;

    public ArendeCreatorRequest(String ar, String kontor, String slutdatum, String notifieringsdatum,
            String handlaggareNotifiering, String forstaHandlaggare, String andraHandlaggare, String id, String status,
            String enkatNamn, String verksamhetsomradeNamn, String uppdragNamn, Object[] varden, boolean arGranskad) {
        this.ar = ar;
        this.kontor = kontor;
        this.slutdatum = slutdatum;
        this.notifieringsdatum = notifieringsdatum;
        this.handlaggareNotifiering = handlaggareNotifiering;
        this.forstaHandlaggare = forstaHandlaggare;
        this.andraHandlaggare = andraHandlaggare;
        this.id = id;
        this.status = status;
        this.enkatNamn = enkatNamn;
        this.uppdragNamn = uppdragNamn;
        this.verksamhetsomradeNamn = verksamhetsomradeNamn;
        this.varden = varden;
        this.arGranskad = arGranskad;
    }

    /**
     * @return String return the enkatNamn
     */
    public boolean getArGranskad() {
        return arGranskad;
    }

    /**
     * @param enkatNamn the enkatNamn to set
     */
    public void setArGranskad(boolean arGranskad) {
        this.arGranskad = arGranskad;
    }

    /**
     * @return String return the enkatNamn
     */
    public String getEnkatNamn() {
        return enkatNamn;
    }

    /**
     * @param enkatNamn the enkatNamn to set
     */
    public void setEnkatNamn(String enkatNamn) {
        this.enkatNamn = enkatNamn;
    }

    /**
     * @return String return the verksamhetsomradesNamn
     */
    public String getVerksamhetsomradeNamn() {
        return verksamhetsomradeNamn;
    }

    /**
     * @param verksamhetsomradesNamn the verksamhetsomradesNamn to set
     */
    public void setVerksamhetsomradeNamn(String verksamhetsomradeNamn) {
        this.verksamhetsomradeNamn = verksamhetsomradeNamn;
    }

    /**
     * @return String return the uppdragsNamn
     */
    public String getUppdragNamn() {
        return uppdragNamn;
    }

    /**
     * @param uppdragsNamn the uppdragsNamn to set
     */
    public void setUppdragNamn(String uppdragNamn) {
        this.uppdragNamn = uppdragNamn;
    }

    /**
     * @return List<Map<String, String>> return the varden
     */
    public Object[] getVarden() {
        return varden;
    }

    /**
     * 
     * @param varden the varden to set
     */
    public void setVarden(Object[] varden) {
        this.varden = varden;
    }

    /**
     * 
     * @return String return the kontor
     */
    public String getKontor() {
        return kontor;
    }

    /**
     * @param kontor the kontor to set
     */
    public void setKontor(String kontor) {
        this.kontor = kontor;
    }

    /**
     * @return String return the ar
     */
    public String getAr() {
        return ar;
    }

    /**
     * @param ar the ar to set
     */
    public void setAr(String ar) {
        this.ar = ar;
    }

    /**
     * @return String return the slutDatum
     */
    public String getSlutdatum() {
        return slutdatum;
    }

    /**
     * @param slutDatum the slutDatum to set
     */
    public void setSlutdatum(String slutdatum) {
        this.slutdatum = slutdatum;
    }

    /**
     * @return String return the notifieringsDatum
     */
    public String getNotifieringsdatum() {
        return notifieringsdatum;
    }

    /**
     * @param notifieringsDatum the notifieringsDatum to set
     */
    public void setNotifieringsdatum(String notifieringsdatum) {
        this.notifieringsdatum = notifieringsdatum;
    }

    /**
     * @return String return the handlaggareNotifiering
     */
    public String getHandlaggareNotifiering() {
        return handlaggareNotifiering;
    }

    /**
     * @param handlaggareNotifiering the handlaggareNotifiering to set
     */
    public void setHandlaggareNotifiering(String handlaggareNotifiering) {
        this.handlaggareNotifiering = handlaggareNotifiering;
    }

    /**
     * @return String return the forstaHandlaggare
     */
    public String getForstaHandlaggare() {
        return forstaHandlaggare;
    }

    /**
     * @param forstaHandlaggare the forstaHandlaggare to set
     */
    public void setForstaHandlaggare(String forstaHandlaggare) {
        this.forstaHandlaggare = forstaHandlaggare;
    }

    /**
     * @return String return the andraHandlaggare
     */
    public String getAndraHandlaggare() {
        return andraHandlaggare;
    }

    /**
     * @param andraHandlaggare the andraHandlaggare to set
     */
    public void setAndraHandlaggare(String andraHandlaggare) {
        this.andraHandlaggare = andraHandlaggare;
    }

    /**
     * @return String return the id
     */
    public String getId() {
        return this.id;
    }

    /**
     * @return String return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return boolean return the arGranskad
     */
    public boolean isArGranskad() {
        return arGranskad;
    }

}
