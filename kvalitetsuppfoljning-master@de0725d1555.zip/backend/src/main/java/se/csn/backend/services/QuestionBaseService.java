package se.csn.backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import se.csn.backend.models.QuestionBase;
import se.csn.backend.repository.QuestionBaseRepository;

@Service
public class QuestionBaseService {

    @Autowired
    private final QuestionBaseRepository questionBaseRepository;

    public QuestionBaseService(QuestionBaseRepository questionBaseRepository) {
        this.questionBaseRepository = questionBaseRepository;
    }

    public void addQuestionBase(QuestionBase questionBase) {
        if (questionBaseRepository.existsById(questionBase.getId())) {
            throw new RuntimeException(String.format("Questionbase already exists with id #s", questionBase.getId()));
        }
        questionBaseRepository.insert(questionBase);
    }

    public List<QuestionBase> getAllQuestionBase() {
        return questionBaseRepository.findAll();
    }

    public void deleteAll() {
        this.questionBaseRepository.deleteAll();
    }
}
