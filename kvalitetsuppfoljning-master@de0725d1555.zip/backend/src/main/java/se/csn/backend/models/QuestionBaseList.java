package se.csn.backend.models;

import java.util.ArrayList;
import java.util.List;

public class QuestionBaseList {

    private List<QuestionBase> questionbases = new ArrayList<>();

    public List<QuestionBase> getQuestionBases() {
        return questionbases;
    }

    public void setQuestionBases(List<QuestionBase> questionbases) {
        this.questionbases = questionbases;
    }
}