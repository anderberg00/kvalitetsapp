package se.csn.backend.models;

import java.math.BigInteger;
import java.util.List;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Entity(name = "verksamhetsomrade")
@Table
@Document("verksamhetsomrade")
public class Verksamhetsomrade {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false)
    private BigInteger id;

    @Column(name = "namn")
    private String namn;

    @Column(name = "information")
    private Object[] information;

    @OneToMany(mappedBy = "verksamhetsomrade")
    private List<Enkat> enkater;

    @OneToMany(mappedBy = "verksamhetsomrade")
    private List<Arende> arenden;

    @OneToMany(mappedBy = "verksamhetsomrade")
    private List<Rekommendation> rekommendationer;

    public Verksamhetsomrade(String namn, Object[] information) {
        this.namn = namn;
        this.information = information;
    }

    public Verksamhetsomrade() {

    }

    /**
     * @return String return the namn
     */
    public String getNamn() {
        return namn;
    }

    /**
     * @param namn the namn to set
     */
    public void setNamn(String namn) {
        this.namn = namn;
    }

    /**
     * @return Object[] return the information
     */
    public Object[] getInformation() {
        return information;
    }

    /**
     * @param information the information to set
     */
    public void setInformation(Object[] information) {
        this.information = information;
    }

    public BigInteger getId() {
        return this.id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

}
