package se.csn.backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import se.csn.backend.models.Enkat;
import se.csn.backend.models.Verksamhetsomrade;
import se.csn.backend.repository.VerksamhetsomradeRepository;

@Service
public class VerksamhetsomradeService {
    
    @Autowired
    private final VerksamhetsomradeRepository verksamhetsomradeRepository;

    public VerksamhetsomradeService(VerksamhetsomradeRepository verksamhetsomradeRepository) {
        this.verksamhetsomradeRepository = verksamhetsomradeRepository;
    }

    public void addVerksamhetsomrade(Verksamhetsomrade verksamhetsomrade) {
        if (verksamhetsomradeRepository.existsByNamn(verksamhetsomrade.getNamn())) {
            throw new RuntimeException(
                    String.format("Verksamhetsområde already exists with name #s", verksamhetsomrade.getNamn()));
        }
        verksamhetsomradeRepository.insert(verksamhetsomrade);
    }

    public List<Verksamhetsomrade> getAllVerksamhetsomraden() {
        return verksamhetsomradeRepository.findAll();
    }

    public Verksamhetsomrade getVerksamhetsomradeByNamn(String namn) {
        return verksamhetsomradeRepository.findByNamn(namn)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find Uppdrag by name #s", namn)));
    }

    public void deleteVerksamhetsomrade(String id) {
        this.verksamhetsomradeRepository.deleteById(id);
    }

    public void updateVerksamhetsomrade(Verksamhetsomrade verksamhetsomrade) {
        Verksamhetsomrade sparatVerksamhetsomrade = verksamhetsomradeRepository.findByNamn(verksamhetsomrade.getNamn())
                        .orElseThrow(() -> new RuntimeException(
                                String.format("Cannot find verksamhetsomrade by id %s", verksamhetsomrade.getNamn())));

        sparatVerksamhetsomrade.setNamn(verksamhetsomrade.getNamn());
        sparatVerksamhetsomrade.setInformation(verksamhetsomrade.getInformation());
        verksamhetsomradeRepository.save(sparatVerksamhetsomrade);
    }

    public void deleteVerksamhetsomradeByName(String namn) {
        this.verksamhetsomradeRepository.deleteVerksamhetsomradeByNamn(namn);
    }

    public void deleteAll() {
        this.verksamhetsomradeRepository.deleteAll();
    }
}