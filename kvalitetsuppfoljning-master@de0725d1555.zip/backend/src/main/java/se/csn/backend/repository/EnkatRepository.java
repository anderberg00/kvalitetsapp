package se.csn.backend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;

import se.csn.backend.models.Enkat;
import se.csn.backend.models.QuestionBase;

@CrossOrigin(origins = "*")
public interface EnkatRepository extends MongoRepository<Enkat, String> {

    Optional<Enkat> getEnkatById(String id);

    List<Enkat> findByVerksamhetsomradeNamn(String namn);

    List<Enkat> findByUppdragNamn(String namn);

}
