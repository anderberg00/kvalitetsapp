package se.csn.backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Enkat;
import se.csn.backend.models.Verksamhetsomrade;
import se.csn.backend.services.VerksamhetsomradeService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/verksamhetsomrade")
public class VerksamhetsomradeController {
    private final VerksamhetsomradeService verksamhetsomradeService;

    public VerksamhetsomradeController(VerksamhetsomradeService verksamhetsomradeService) {
        this.verksamhetsomradeService = verksamhetsomradeService;
    }

    @PostMapping
    public ResponseEntity<Verksamhetsomrade> addVerksamhetsomrade(@RequestBody Verksamhetsomrade verksamhetsomrade) {
        Verksamhetsomrade _verksamhetsomrade = new Verksamhetsomrade(verksamhetsomrade.getNamn(), verksamhetsomrade.getInformation());
        verksamhetsomradeService.addVerksamhetsomrade(_verksamhetsomrade);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{namn}")
    public ResponseEntity<Verksamhetsomrade> updateVerksamhetsomrade(@RequestBody Verksamhetsomrade verksamhetsomrade) {
        verksamhetsomradeService.updateVerksamhetsomrade(verksamhetsomrade);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @GetMapping
    public ResponseEntity<List<Verksamhetsomrade>> getAllVerksamhetsomraden() {
        return ResponseEntity.ok(verksamhetsomradeService.getAllVerksamhetsomraden());
    }

    @GetMapping("/{namn}")
    public ResponseEntity<Verksamhetsomrade> getVerksamhetsomradeByNamn(@PathVariable String namn) {
        return ResponseEntity.ok(verksamhetsomradeService.getVerksamhetsomradeByNamn(namn));
    }

    @DeleteMapping("/{namn}")
    public ResponseEntity deleteByName(@PathVariable String namn) {
        verksamhetsomradeService.deleteVerksamhetsomradeByName(namn);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping()
    public ResponseEntity deleteAllVerksamhetsomraden() {
        verksamhetsomradeService.deleteAll();
        return ResponseEntity.noContent().build();
    }
}
