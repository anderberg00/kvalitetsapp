package se.csn.backend.models;

public class QuestionBaseListCreatorRequest {
    private QuestionBase[] questionBases;

    public QuestionBaseListCreatorRequest(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

    public QuestionBaseListCreatorRequest() {
    }

    /**
     * @return QuestionBase[] return the questionBases
     */
    public QuestionBase[] getQuestionBases() {
        return questionBases;
    }

    /**
     * @param questionBases the questionBases to set
     */
    public void setQuestionBases(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

}
