package se.csn.backend.models;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Field;

public class QuestionBase {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false)
    private BigInteger id;
    @Field(name = "value")
    private String value;
    @Field(name = "customValue")
    private String customValue;
    @Field(name = "valuesAdditionalTextbox")
    private Object[] valuesAdditionalTextbox;
    @Field(name = "key")
    private String key;
    @Field(name = "label")
    private String label;
    @Field(name = "required")
    private boolean required;
    @Field(name = "order")
    private int order;
    @Field(name = "controlType")
    private String controlType;
    @Field(name = "information")
    private String information;
    @Field(name = "options")
    private Object[] options;
    @Field(name = "additionalTextbox")
    private Object[] additionalTextbox;
    @Field(name = "kvalitetsmatt")
    private Kvalitetsmatt kvalitetsmatt;

    public QuestionBase(String value, String customValue, Object[] valuesAdditionalTextbox, String key, String label,
            boolean required, int order, String controlType, String information, Object[] additionalTextbox,
            Object[] options, Kvalitetsmatt kvalitetsmatt) {
        this.value = value;
        this.customValue = customValue;
        this.valuesAdditionalTextbox = valuesAdditionalTextbox;
        this.key = key;
        this.label = label;
        this.required = required;
        this.order = order;
        this.controlType = controlType;
        this.information = information;
        this.options = options;
        this.additionalTextbox = additionalTextbox;
        this.kvalitetsmatt = kvalitetsmatt;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public BigInteger getId() {
        return id;
    }

    public String getCustomValue() {
        return customValue;
    }

    public Object[] getValuesAdditionalTextbox() {
        return valuesAdditionalTextbox;
    }

    /**
     * @return String return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * @return String return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key the key to set
     */
    public void setKey(String key) {
        this.key = key;
    }

    /**
     * @return String return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @return boolean return the required
     */
    public boolean isRequired() {
        return required;
    }

    /**
     * @param required the required to set
     */
    public void setRequired(boolean required) {
        this.required = required;
    }

    /**
     * @return int return the order
     */
    public int getOrder() {
        return order;
    }

    /**
     * @param order the order to set
     */
    public void setOrder(int order) {
        this.order = order;
    }

    /**
     * @return String return the controlType
     */
    public String getControlType() {
        return controlType;
    }

    /**
     * @param controlType the controlType to set
     */
    public void setControlType(String controlType) {
        this.controlType = controlType;
    }

    /**
     * @return String return the information
     */
    public String getInformation() {
        return information;
    }

    /**
     * @param information the information to set
     */
    public void setInformation(String information) {
        this.information = information;
    }

    /**
     * @return Object[] return the options
     */
    public Object[] getOptions() {
        return options;
    }

    /**
     * @param options the options to set
     */
    public void setOptions(Object[] options) {
        this.options = options;
    }

    /**
     * @return Object[] return the additionalTextbox
     */
    public Object[] getAdditionalTextbox() {
        return additionalTextbox;
    }

    /**
     * @param additionalTextbox the additionalTextbox to set
     */
    public void setAdditionalTextbox(Object[] additionalTextbox) {
        this.additionalTextbox = additionalTextbox;
    }

    public void updateQuestionBase(QuestionBase qb) {
        this.value = qb.getValue();
        this.key = qb.getKey();
        this.label = qb.getLabel();
        this.required = qb.isRequired();
        this.order = qb.getOrder();
        this.controlType = qb.getControlType();
        this.information = qb.getInformation();
        this.options = qb.getOptions();
        this.additionalTextbox = qb.getAdditionalTextbox();
    }

    /**
     * @param customValue the customValue to set
     */
    public void setCustomValue(String customValue) {
        this.customValue = customValue;
    }

    /**
     * @param valuesAdditionalTextbox the valuesAdditionalTextbox to set
     */
    public void setValuesAdditionalTextbox(Object[] valuesAdditionalTextbox) {
        this.valuesAdditionalTextbox = valuesAdditionalTextbox;
    }

    /**
     * @return Kvalitetsmatt return the kvalitetsmatt
     */
    public Kvalitetsmatt getKvalitetsmatt() {
        return kvalitetsmatt;
    }

    /**
     * @param kvalitetsmatt the kvalitetsmatt to set
     */
    public void setKvalitetsmatt(Kvalitetsmatt kvalitetsmatt) {
        this.kvalitetsmatt = kvalitetsmatt;
    }

}
