package se.csn.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Arende;
import se.csn.backend.models.ArendeCreatorRequest;
import se.csn.backend.models.Enkat;
import se.csn.backend.models.Uppdrag;
import se.csn.backend.models.Verksamhetsomrade;
import se.csn.backend.services.ArendeService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/arende")
public class ArendeController {
    private final ArendeService arendeService;

    @Autowired
    UppdragController uppdragController;
    @Autowired
    VerksamhetsomradeController verksamhetsomradeController;
    @Autowired
    EnkatController enkatController;
    @Autowired
    EnkatsvarController enkatsvarController;

    public ArendeController(ArendeService arendeService) {
        this.arendeService = arendeService;
    }

    @PostMapping()
    public ResponseEntity addArende(@RequestBody ArendeCreatorRequest arendeCreatorRequest) {
        String ar = arendeCreatorRequest.getAr();
        String kontor = arendeCreatorRequest.getKontor();
        String slutdatum = arendeCreatorRequest.getSlutdatum();
        String notifieringsdatum = arendeCreatorRequest.getNotifieringsdatum();
        String handlaggareNotifiering = arendeCreatorRequest.getHandlaggareNotifiering();
        String forstaHandlaggare = arendeCreatorRequest.getForstaHandlaggare();
        String andraHandlaggare = arendeCreatorRequest.getAndraHandlaggare();
        String id = arendeCreatorRequest.getId();
        String status = arendeCreatorRequest.getStatus();

        Object[] varden = arendeCreatorRequest.getVarden();

        Uppdrag uppdrag = uppdragController.getUppdragByNamn(arendeCreatorRequest.getUppdragNamn()).getBody();
        Verksamhetsomrade verksamhetsomrade = verksamhetsomradeController
                .getVerksamhetsomradeByNamn(arendeCreatorRequest.getVerksamhetsomradeNamn()).getBody();
        Enkat enkat = enkatController.getEnkatByEnkatNamn(arendeCreatorRequest.getEnkatNamn()).getBody();

        Arende nyttArende = new Arende(ar, kontor, slutdatum, notifieringsdatum, handlaggareNotifiering,
                forstaHandlaggare, andraHandlaggare, id, status, verksamhetsomrade, uppdrag, enkat, varden);

        arendeService.addArende(nyttArende);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity updateArende(@PathVariable String id, @RequestBody ArendeCreatorRequest acr) {
        String ar = acr.getAr();
        String kontor = acr.getKontor();
        String slutdatum = acr.getSlutdatum();
        String notifieringsdatum = acr.getNotifieringsdatum();
        String handlaggareNotifiering = acr.getHandlaggareNotifiering();
        String forstaHandlaggare = acr.getForstaHandlaggare();
        String andraHandlaggare = acr.getAndraHandlaggare();
        String status = acr.getStatus();

        Object[] varden = acr.getVarden();

        Uppdrag uppdrag = uppdragController.getUppdragByNamn(acr.getUppdragNamn()).getBody();
        Verksamhetsomrade verksamhetsomrade = verksamhetsomradeController
                .getVerksamhetsomradeByNamn(acr.getVerksamhetsomradeNamn()).getBody();
        Enkat enkat = enkatController.getEnkatByEnkatNamn(acr.getEnkatNamn()).getBody();

        Arende nyttArende = new Arende(ar, kontor, slutdatum, notifieringsdatum, handlaggareNotifiering,
                forstaHandlaggare, andraHandlaggare, id, status, verksamhetsomrade, uppdrag, enkat, varden);

        arendeService.updateArende(id, nyttArende);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<Arende>> getAllArenden() {
        return ResponseEntity.ok(arendeService.getAllArenden());
    }

    @GetMapping("/{id}")
    public ResponseEntity getArendeById(@PathVariable String id) {
        return ResponseEntity.ok(arendeService.getArendeById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteById(@PathVariable String id) {
        arendeService.deleteArende(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping()
    public ResponseEntity deleteAllArenden() {
        arendeService.deleteAll();
        return ResponseEntity.noContent().build();
    }
}