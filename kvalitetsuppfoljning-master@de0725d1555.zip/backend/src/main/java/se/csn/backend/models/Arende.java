package se.csn.backend.models;

import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.springframework.data.mongodb.core.mapping.Document;

@Entity(name = "arende")
@Document("arende")
public class Arende {

    @Id
    private String id;
    @Column()
    private String ar;
    @Column()
    private String kontor;
    @Column()
    private String slutdatum;
    @Column()
    private String notifieringsdatum;
    @Column()
    private String handlaggareNotifiering;
    @Column()
    private String forstaHandlaggare;
    @Column()
    private String andraHandlaggare;
    @Column()
    private String status;
    @Column()
    private QuestionBase[] questionBases;
    @ManyToOne(cascade = CascadeType.ALL)
    @Column()
    private Verksamhetsomrade verksamhetsomrade;
    @ManyToOne(cascade = CascadeType.ALL)
    @Column()
    private Uppdrag uppdrag;
    @ManyToOne(cascade = CascadeType.ALL)
    @Column()
    private Enkat enkat;
    @Column()
    private Object[] varden;
    @Column()
    private boolean arGranskad;
    // @JoinColumn(name = "enkatsvar_id", referencedColumnName = "id")

    public Arende() {

    }

    public Arende(String ar, String kontor, String slutdatum, String notifieringsdatum, String handlaggareNotifiering,
            String forstaHandlaggare, String andraHandlaggare, String id, String status,
            Verksamhetsomrade verksamhetsomrade, Uppdrag uppdrag, Enkat enkat, Object[] varden) {
        this.ar = ar;
        this.kontor = kontor;
        this.slutdatum = slutdatum;
        this.notifieringsdatum = notifieringsdatum;
        this.handlaggareNotifiering = handlaggareNotifiering;
        this.forstaHandlaggare = forstaHandlaggare;
        this.andraHandlaggare = andraHandlaggare;
        this.id = id;
        this.status = status;
        this.verksamhetsomrade = verksamhetsomrade;
        this.uppdrag = uppdrag;
        this.varden = varden;
        this.enkat = enkat;
        this.arGranskad = false;
    }

    public void setVarden(Object[] varden) {
        this.varden = varden;
    }

    public Object[] getVarden() {
        return this.varden;
    }

    public void setArGranskad(boolean arGranskad) {
        this.arGranskad = arGranskad;
    }

    public boolean getArGranskad() {
        return this.arGranskad;
    }

    public void setEnkat(Enkat enkat) {
        this.enkat = enkat;
    }

    public Enkat getEnkat() {
        return this.enkat;
    }

    public void setUppdrag(Uppdrag uppdrag) {
        this.uppdrag = uppdrag;
    }

    public Uppdrag getUppdrag() {
        return this.uppdrag;
    }

    public void setVerksamhetsomrade(Verksamhetsomrade verksamhetsomrade) {
        this.verksamhetsomrade = verksamhetsomrade;
    }

    public Verksamhetsomrade getVerksamhetsomrade() {
        return this.verksamhetsomrade;
    }

    /**
     * @return String return the kontor
     */
    /*
     * public List<Map<String, String>> getVarden() { return varden; }
     * 
     * /**
     * 
     * @param kontor the kontor to set
     */
    /*
     * public void setVarden(List<Map<String, String>> varden) { this.varden =
     * varden; }
     * 
     * /**
     * 
     * @return String return the kontor
     */
    public String getKontor() {
        return kontor;
    }

    /**
     * @param kontor the kontor to set
     */
    public void setKontor(String kontor) {
        this.kontor = kontor;
    }

    /**
     * @return String return the ar
     */
    public String getAr() {
        return ar;
    }

    /**
     * @param ar the ar to set
     */
    public void setAr(String ar) {
        this.ar = ar;
    }

    /**
     * @return String return the slutDatum
     */
    public String getSlutdatum() {
        return slutdatum;
    }

    /**
     * @param slutDatum the slutDatum to set
     */
    public void setSlutdatum(String slutdatum) {
        this.slutdatum = slutdatum;
    }

    /**
     * @return String return the notifieringsDatum
     */
    public String getNotifieringsdatum() {
        return notifieringsdatum;
    }

    /**
     * @param notifieringsDatum the notifieringsDatum to set
     */
    public void setNotifieringsdatum(String notifieringsdatum) {
        this.notifieringsdatum = notifieringsdatum;
    }

    /**
     * @return String return the handlaggareNotifiering
     */
    public String getHandlaggareNotifiering() {
        return handlaggareNotifiering;
    }

    /**
     * @param handlaggareNotifiering the handlaggareNotifiering to set
     */
    public void setHandlaggareNotifiering(String handlaggareNotifiering) {
        this.handlaggareNotifiering = handlaggareNotifiering;
    }

    /**
     * @return String return the forstaHandlaggare
     */
    public String getForstaHandlaggare() {
        return forstaHandlaggare;
    }

    /**
     * @param forstaHandlaggare the forstaHandlaggare to set
     */
    public void setForstaHandlaggare(String forstaHandlaggare) {
        this.forstaHandlaggare = forstaHandlaggare;
    }

    /**
     * @return String return the andraHandlaggare
     */
    public String getAndraHandlaggare() {
        return andraHandlaggare;
    }

    /**
     * @param andraHandlaggare the andraHandlaggare to set
     */
    public void setAndraHandlaggare(String andraHandlaggare) {
        this.andraHandlaggare = andraHandlaggare;
    }

    /**
     * @return String return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return QuestionBase[] return the questionBases
     */
    public QuestionBase[] getQuestionBases() {
        return questionBases;
    }

    /**
     * @param questionBases the questionBases to set
     */
    public void setQuestionBases(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

    /**
     * @return boolean return the arGranskad
     */
    public boolean isArGranskad() {
        return arGranskad;
    }

}
