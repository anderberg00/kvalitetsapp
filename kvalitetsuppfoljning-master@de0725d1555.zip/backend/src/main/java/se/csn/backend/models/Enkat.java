package se.csn.backend.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Entity
@Document("enkat")
public class Enkat {

    @Id
    private String id;

    @Column
    private String enkatNamn;

    @ManyToOne(cascade = CascadeType.ALL)
    @Column
    private Uppdrag uppdrag;

    @ManyToOne(cascade = CascadeType.ALL)
    @Column
    private Verksamhetsomrade verksamhetsomrade;

    @OneToMany(mappedBy = "arende")
    private List<Arende> arenden;

    @OneToMany(mappedBy = "questionbase")
    private QuestionBase[] questionBases;

    public Enkat(String enkatNamn, Uppdrag uppdrag, Verksamhetsomrade verksamhetsomrade, QuestionBase[] questionBases) {
        this.id = enkatNamn;
        this.uppdrag = uppdrag;
        this.verksamhetsomrade = verksamhetsomrade;
        this.questionBases = questionBases;
    }

    public Enkat() {

    }

    public void setUppdrag(Uppdrag uppdrag) {
        this.uppdrag = uppdrag;
    }

    public Uppdrag getUppdrag() {
        return this.uppdrag;
    }

    public void setVerksamhetsomrade(Verksamhetsomrade verksamhetsomrade) {
        this.verksamhetsomrade = verksamhetsomrade;
    }

    public Verksamhetsomrade getVerksamhetsomrade() {
        return this.verksamhetsomrade;
    }

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return List<QuestionBase> return the enkatList
     */
    public QuestionBase[] getQuestionBases() {
        return questionBases;
    }

    /**
     * @param qb the Questionbase[] to update values
     */
    public void setValuesForQuestionBases(QuestionBase[] qb) {
        for (int i = 0; i < qb.length; i++) {
            if (qb[i].getKey().equals(this.questionBases[i].getKey())) {
                if (qb[i].getValue() != null) {
                    this.questionBases[i].setValue(qb[i].getValue());
                }
                if (qb[i].getValuesAdditionalTextbox() != null) {
                    this.questionBases[i].setValuesAdditionalTextbox(qb[i].getValuesAdditionalTextbox());
                }
                if (qb[i].getCustomValue() != null) {
                    this.questionBases[i].setCustomValue(qb[i].getCustomValue());
                }
            }
        }
    }

    /**
     * @return String return the enkatNamn
     */
    public String getEnkatNamn() {
        return enkatNamn;
    }

    /**
     * @param enkatNamn the enkatNamn to set
     */
    public void setEnkatNamn(String enkatNamn) {
        this.enkatNamn = enkatNamn;
    }

    /**
     * @return List<Arende> return the arenden
     */
    public List<Arende> getArenden() {
        return arenden;
    }

    /**
     * @param arenden the arenden to set
     */
    public void setArenden(List<Arende> arenden) {
        this.arenden = arenden;
    }

    /**
     * @param questionbases the questionbases to set
     */
    public void setQuestionBases(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

}
