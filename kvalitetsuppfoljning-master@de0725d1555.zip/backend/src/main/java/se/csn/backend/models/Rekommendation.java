package se.csn.backend.models;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Entity(name = "rekommendation")
@Document("rekommendation")
public class Rekommendation {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false)
    private String id;
    @ManyToOne()
    @Field()
    private Verksamhetsomrade verksamhetsomrade;
    @Field()
    private String motivering;
    @Field()
    private List<Map<String, String>> varden;
    @Field()
    private String inskickadAv;

    public Rekommendation(String id, String inskickadAv, Verksamhetsomrade verksamhetsomrade, String motivering,
            List<Map<String, String>> varden) {
        this.id = id;
        this.inskickadAv = inskickadAv;
        this.verksamhetsomrade = verksamhetsomrade;
        this.motivering = motivering;
        this.varden = varden;
    }

    public Rekommendation() {

    }

    public void setInskickadAv(String inskickadAv) {
        this.inskickadAv = inskickadAv;
    }

    public String getInskickadAv() {
        return this.inskickadAv;
    }

    public void setVerksamhetsomrade(Verksamhetsomrade verksamhetsomrade) {
        this.verksamhetsomrade = verksamhetsomrade;
    }

    public Verksamhetsomrade getVerksamhetsomrade() {
        return this.verksamhetsomrade;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the kontor
     */
    public List<Map<String, String>> getVarden() {
        return varden;
    }

    /**
     * @param kontor the kontor to set
     */
    public void setVarden(List<Map<String, String>> varden) {
        this.varden = varden;
    }

    /**
     * @return String return the namn
     */
    public String getMotivering() {
        return motivering;
    }

    /**
     * @param namn the namn to set
     */
    public void setMotivering(String motivering) {
        this.motivering = motivering;
    }

}
