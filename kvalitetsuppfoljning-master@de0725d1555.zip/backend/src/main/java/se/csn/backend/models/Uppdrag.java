package se.csn.backend.models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Entity(name = "uppdrag")
@Document("uppdrag")
public class Uppdrag {

    @Field()
    private String namn;

    @OneToMany(mappedBy = "uppdrag")
    private List<Enkat> enkater;

    @OneToMany(mappedBy = "uppdrag")
    private List<Arende> arenden;

    public Uppdrag(String namn) {
        this.namn = namn;
    }

    public Uppdrag() {

    }

    /**
     * @return String return the namn
     */
    public String getNamn() {
        return namn;
    }

    /**
     * @param namn the namn to set
     */
    public void setNamn(String namn) {
        this.namn = namn;
    }
}
