package se.csn.backend.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import se.csn.backend.models.Enkat;
import se.csn.backend.models.QuestionBase;
import se.csn.backend.models.QuestionBaseList;
import se.csn.backend.repository.EnkatRepository;

@Service
public class EnkatService {
    private final EnkatRepository enkatRepository;

    public EnkatService(EnkatRepository enkatRepository) {
        this.enkatRepository = enkatRepository;
    }

    public void addEnkat(Enkat enkat) {
        /*
         * if (enkatRepository.existsById(enkat.getId())) { throw new
         * RuntimeException(String.format("Uppdrag already exists with name #s")); }
         */
        enkatRepository.insert(enkat);
    }

    public List<Enkat> getAllEnkater() {
        return enkatRepository.findAll();
    }

    public void deleteEnkat(String id) {
        enkatRepository.deleteById(id);
    }

    public QuestionBase[] getQuestionBases(String id) {
        Enkat e = enkatRepository.getEnkatById(id)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find Enkat by namn #s", id)));

        return e.getQuestionBases();
    }

    public Enkat getEnkatByEnkatNamn(String enkatNamn) {
        return enkatRepository.getEnkatById(enkatNamn)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find Enkat by namn #s", enkatNamn)));
    }

    public void updateEnkat(Enkat enkat) {
        Enkat sparadEnkat = enkatRepository.findById(enkat.getId())
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find enkat by Id %s", enkat.getId())));

        sparadEnkat.setQuestionBases(enkat.getQuestionBases());
    }

    public void setQuestionBases(Enkat enkat, QuestionBaseList qb) {
        QuestionBase[] questionbase = new QuestionBase[20];
        questionbase = qb.getQuestionBases().toArray(questionbase);
        enkat.setQuestionBases(questionbase);
        enkatRepository.save(enkat);
    }

    public void updateQuestionBase(Enkat enkat, QuestionBase qb) {
        Enkat matchandeEnkat = enkatRepository.findById(enkat.getId())
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find enkat by Id %s", enkat.getId())));

        QuestionBase[] questionList = matchandeEnkat.getQuestionBases();
        for (QuestionBase questionBase : questionList) {
            if (qb.equals(questionBase)) {
                questionBase.updateQuestionBase(qb);
                return;
            }
        }
    }

    public void updateKontor(String kontor) {

    }

    public void deleteAll() {
        this.enkatRepository.deleteAll();
    }

}