package se.csn.backend.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import se.csn.backend.models.Arende;
import se.csn.backend.models.Enkat;
import se.csn.backend.models.Enkatsvar;
import se.csn.backend.models.QuestionBase;
import se.csn.backend.models.QuestionBaseList;
import se.csn.backend.repository.ArendeRepository;
import se.csn.backend.repository.EnkatRepository;
import se.csn.backend.repository.EnkatsvarRepository;

@Service
public class EnkatsvarService {
    private final EnkatsvarRepository enkatsvarRepository;

    @Autowired
    private ArendeRepository arendeRepository;

    public EnkatsvarService(EnkatsvarRepository enkatsvarRepository) {
        this.enkatsvarRepository = enkatsvarRepository;
    }

    public void addEnkatsvar(Enkatsvar enkatsvar) {
        enkatsvarRepository.insert(enkatsvar);
    }

    public List<Enkatsvar> getAllEnkatsvar() {
        return enkatsvarRepository.findAll();
    }

    public void deleteEnkatsvar(String id) {
        enkatsvarRepository.deleteById(id);
    }

    public void deleteAll() {
        this.enkatsvarRepository.deleteAll();
    }

    public void setValuesForQuestionBases(QuestionBase[] questionBases, String id) {
        Arende matchandeArende = arendeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find enkatsvar by Id %s", id)));
        Enkat matchandeEnkat = matchandeArende.getEnkat();
        matchandeArende.setArGranskad(true);
        String status = matchandeArende.getStatus();

        if (status.equals("Omgranskning")) {
            matchandeArende.setStatus("Färdiggranskad omgång 2");
        } else if (status.equals("Klar för granskning")) {
            matchandeArende.setStatus("Färdiggranskad");
        }

        matchandeEnkat.setValuesForQuestionBases(questionBases);
        matchandeArende.setEnkat(matchandeEnkat);
        arendeRepository.save(matchandeArende);
    }

}