package se.csn.backend.models;

import java.math.BigInteger;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.springframework.data.mongodb.core.mapping.Document;

@Entity
@Document("enkatsvar")
public class Enkatsvar {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false)
    private String id;

    @Column
    private String inskickadAv;

    @Column
    private QuestionBase[] questionBases;

    @OneToOne(mappedBy = "enkatsvar")
    @Column
    private Arende arende;

    @Column
    private String enkatnamn;

    public Enkatsvar() {
        
    }

    public Enkatsvar(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

    public QuestionBase[] getQuestionBases() {
        return questionBases;
    }

    public void setArende(Arende arende) {
        this.arende = arende;
    }

    public Arende getArende() {
        return arende;
    }

    /**
     * @param questionBase the questionBase to set
     */
    public void setQuestionBases(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

    public String getInskickadAv() {
        return inskickadAv;
    }

    public void setInskickadAv(String inskickadAv) {
        this.inskickadAv = inskickadAv;
    }

    /**
     * @return String return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the enkatnamn
     */
    public String getEnkatnamn() {
        return enkatnamn;
    }

    /**
     * @param enkatnamn the enkatnamn to set
     */
    public void setEnkatnamn(String enkatnamn) {
        this.enkatnamn = enkatnamn;
    }

}
