package se.csn.backend.controller;

import java.util.List;

import javax.ws.rs.core.Response;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Uppdrag;
import se.csn.backend.services.UppdragService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/uppdrag")
public class UppdragController {
    private final UppdragService uppdragService;

    public UppdragController(UppdragService uppdragService) {
        this.uppdragService = uppdragService;
    }

    @PostMapping
    public ResponseEntity<Uppdrag> addUppdrag(@RequestBody Uppdrag uppdrag) {
        Uppdrag _uppdrag = new Uppdrag(uppdrag.getNamn());
        uppdragService.addUppdrag(_uppdrag);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<List<Uppdrag>> getAllUppdrag() {
        return ResponseEntity.ok(uppdragService.getAllUppdrag());
    }

    @GetMapping("/{namn}")
    public ResponseEntity<Uppdrag> getUppdragByNamn(@PathVariable String namn) {
        return ResponseEntity.ok(uppdragService.getUppdragByNamn(namn));
    }

    @DeleteMapping("/{namn}")
    public ResponseEntity deleteUppdrag(@PathVariable String namn) {
        uppdragService.deleteByNamn(namn);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping()
    public ResponseEntity deleteAllUppdrag() {
        uppdragService.deleteAll();
        return ResponseEntity.noContent().build();
    }

}
