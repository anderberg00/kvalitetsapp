package se.csn.backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import se.csn.backend.models.User;
import se.csn.backend.repository.UppdragRepository;
import se.csn.backend.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public void addUser(User user) {
        userRepository.insert(user);
    }

    public void deleteAll() {
        userRepository.deleteAll();
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}