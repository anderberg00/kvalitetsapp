package se.csn.backend.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import se.csn.backend.models.Arende;

import org.springframework.data.mongodb.repository.Query;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.data.mongodb.repository.MongoRepository;

@CrossOrigin(origins = "*")
public interface ArendeRepository extends MongoRepository<Arende, String> {
    void deleteById(String id);

    @Query("{kontor': ? 0}")
    Optional<Arende> findByKontor(String kontor);

    @Query("{granskningsnummer: ? 0")
    Optional<Arende> findByGranskningsnummer(String granskningsNummer);

    List<Arende> findByVerksamhetsomradeNamn(String namn);

    List<Arende> findByUppdragNamn(String namn);

    List<Arende> findByEnkatId(String id);

    Arende getById(String id);

}
