package se.csn.backend.controller;

import java.util.List;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Kvalitetsmatt;
import se.csn.backend.models.QuestionBase;
import se.csn.backend.models.QuestionBaseCreatorRequest;
import se.csn.backend.services.QuestionBaseService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/questionbase")
public class QuestionBaseController {
    private final QuestionBaseService questionBaseService;

    @Autowired
    KvalitetsmattController kvalitetsmattController;

    public QuestionBaseController(QuestionBaseService questionBaseService) {
        this.questionBaseService = questionBaseService;
    }

    @PostMapping
    public ResponseEntity<QuestionBase> addQuestionBase(
            @RequestBody QuestionBaseCreatorRequest questionBaseCreatorRequest) {
        String kvalitetsmattNamn = questionBaseCreatorRequest.getKvalitetsmattNamn();
        QuestionBase qb = questionBaseCreatorRequest.getQuestionBase();
        Kvalitetsmatt kvalitetsmatt = kvalitetsmattController.getKvalitetsmattByNamn(kvalitetsmattNamn).getBody();

        QuestionBase _questionBase = new QuestionBase(qb.getValue(), qb.getCustomValue(),
                qb.getValuesAdditionalTextbox(), qb.getKey(), qb.getLabel(), qb.isRequired(), qb.getOrder(),
                qb.getControlType(), qb.getInformation(), qb.getAdditionalTextbox(), qb.getOptions(), kvalitetsmatt);
        questionBaseService.addQuestionBase(_questionBase);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<List<QuestionBase>> getAllQuestionBase() {
        return ResponseEntity.ok(questionBaseService.getAllQuestionBase());
    }

    @DeleteMapping()
    public ResponseEntity deleteAllQuestionBase() {
        questionBaseService.deleteAll();
        return ResponseEntity.noContent().build();
    }
}
