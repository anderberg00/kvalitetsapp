package se.csn.backend.models;

import java.util.List;
import java.util.Map;

public class RekommendationCreatorRequest {
    private String id;
    private String verksamhetsomradeNamn;
    private String motivering;
    private List<Map<String, String>> varden;
    private String inskickadAv;

    public RekommendationCreatorRequest(String id, String inskickadAv, String verksamhetsomradeNamn, String motivering,
            List<Map<String, String>> varden) {
        this.id = id;
        this.inskickadAv = inskickadAv;
        this.verksamhetsomradeNamn = verksamhetsomradeNamn;
        this.motivering = motivering;
        this.varden = varden;
    }

    public void setInskickadAv(String inskickadAv) {
        this.inskickadAv = inskickadAv;
    }

    public String getInskickadAv() {
        return this.inskickadAv;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return String return the kontor
     */
    public List<Map<String, String>> getVarden() {
        return varden;
    }

    /**
     * @param kontor the kontor to set
     */
    public void setVarden(List<Map<String, String>> varden) {
        this.varden = varden;
    }

    /**
     * @return String return the namn
     */
    public String getMotivering() {
        return motivering;
    }

    /**
     * @param namn the namn to set
     */
    public void setMotivering(String motivering) {
        this.motivering = motivering;
    }

    /**
     * @return String return the verksamhetsOmradeNamn
     */
    public String getVerksamhetsomradeNamn() {
        return verksamhetsomradeNamn;
    }

    /**
     * @param verksamhetsOmradeNamn the verksamhetsOmradeNamn to set
     */
    public void setVerksamhetsomradeNamn(String verksamhetsomradeNamn) {
        this.verksamhetsomradeNamn = verksamhetsomradeNamn;
    }
}
