package se.csn.backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import se.csn.backend.models.Uppdrag;
import se.csn.backend.repository.UppdragRepository;

@Service
public class UppdragService {

    @Autowired
    private final UppdragRepository uppdragRepository;

    public UppdragService(UppdragRepository uppdragRepository) {
        this.uppdragRepository = uppdragRepository;
    }

    public void addUppdrag(Uppdrag uppdrag) {
        if (uppdragRepository.existsByNamn(uppdrag.getNamn())) {
            throw new RuntimeException(String.format("Uppdrag already exists with namn #s", uppdrag.getNamn()));
        }
        uppdragRepository.insert(uppdrag);
    }

    public List<Uppdrag> getAllUppdrag() {
        return uppdragRepository.findAll();
    }

    public Uppdrag getUppdragByNamn(String namn) {
        return uppdragRepository.findByNamn(namn)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find Uppdrag by namn #s", namn)));
    }

    public void deleteByNamn(String namn) {
        this.uppdragRepository.deleteUppdragByNamn(namn);
    }

    public void deleteAll() {
        this.uppdragRepository.deleteAll();
    }
}
