package se.csn.backend.services;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import se.csn.backend.models.Arende;
import se.csn.backend.models.ArendeCreatorRequest;
import se.csn.backend.models.Enkat;
import se.csn.backend.models.Uppdrag;
import se.csn.backend.models.Verksamhetsomrade;
import se.csn.backend.repository.ArendeRepository;
import se.csn.backend.repository.UppdragRepository;

import org.springframework.stereotype.Service;

@Service
public class ArendeService {
    private final ArendeRepository arendeRepository;

    public ArendeService(ArendeRepository arendeRepository) {
        this.arendeRepository = arendeRepository;
    }

    public void addArende(Arende arende) {
        arendeRepository.insert(arende);
    }

    public List<Arende> getAllArenden() {
        return arendeRepository.findAll();
    }

    public void updateArende(String id, Arende arende) {

        Arende sparatArende = arendeRepository.findById(id).orElseThrow(
                () -> new RuntimeException(String.format("Cannot find Arende by granskningsnummer #s", id)));

        sparatArende.setAr(arende.getAr());
        sparatArende.setKontor(arende.getKontor());
        sparatArende.setSlutdatum(arende.getSlutdatum());
        sparatArende.setNotifieringsdatum(arende.getNotifieringsdatum());
        sparatArende.setHandlaggareNotifiering(arende.getHandlaggareNotifiering());
        sparatArende.setForstaHandlaggare(arende.getForstaHandlaggare());
        sparatArende.setAndraHandlaggare(arende.getAndraHandlaggare());
        sparatArende.setId(arende.getId());
        sparatArende.setStatus(arende.getStatus());
        sparatArende.setVarden(arende.getVarden());
        sparatArende.setArGranskad(arende.getArGranskad());

        arendeRepository.save(sparatArende);
    }

    public void deleteArende(String id) {
        arendeRepository.deleteById(id);
    }

    public Arende getArendeById(String id) {
        return arendeRepository.getById(id);
    }

    public void deleteAll() {
        this.arendeRepository.deleteAll();
    }
}
