package se.csn.backend.api;

import se.csn.backend.services.ApiService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;

@CrossOrigin("*")
@RestController()
@RequestMapping(path = "/controller")
public class Api {
    ApiService apiService;

    @Autowired
    public Api(ApiService apiService) {
        this.apiService = apiService;
    }

    @GetMapping("/test")
    public ResponseEntity<String> Api() {
        return new ResponseEntity<>(this.apiService.test(), new HttpHeaders(), HttpStatus.OK);
    }

    /*
     * @GetMapping("/") public String hello() { return "Det fungerar!"; }
     */

}