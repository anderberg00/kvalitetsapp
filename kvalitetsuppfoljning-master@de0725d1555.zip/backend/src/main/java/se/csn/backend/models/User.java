package se.csn.backend.models;

import javax.persistence.Column;
import javax.persistence.Entity;

import org.springframework.data.mongodb.core.mapping.Document;

@Entity(name = "user")
@Document("user")
public class User {

    @Column()
    private String username;
    @Column()
    private String password;
    @Column()
    private boolean arAdmin;
    @Column()
    private String fornamn;
    @Column()
    private String efternamn;
    @Column()
    private String mail;

    public User() {

    }

    public User(String username, String fornamn, String efternamn, String mail, String password, boolean arAdmin) {
        this.username = username;
        this.fornamn = fornamn;
        this.efternamn = efternamn;
        this.mail = mail;
        this.password = password;
        this.arAdmin = arAdmin;
    }

    /**
     * @return String return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return String return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return boolean return the arAdmin
     */
    public boolean isArAdmin() {
        return arAdmin;
    }

    /**
     * @param arAdmin the arAdmin to set
     */
    public void setArAdmin(boolean arAdmin) {
        this.arAdmin = arAdmin;
    }

    /**
     * @return String return the fornamn
     */
    public String getFornamn() {
        return fornamn;
    }

    /**
     * @param fornamn the fornamn to set
     */
    public void setFornamn(String fornamn) {
        this.fornamn = fornamn;
    }

    /**
     * @return String return the efternamn
     */
    public String getEfternamn() {
        return efternamn;
    }

    /**
     * @param efternamn the efternamn to set
     */
    public void setEfternamn(String efternamn) {
        this.efternamn = efternamn;
    }

    /**
     * @return String return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

}
