package se.csn.backend.services;

import org.springframework.stereotype.Controller;

@Controller
public class ApiService {

    public String test() {
        return "Det funkar";
    }
}
