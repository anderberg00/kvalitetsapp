package se.csn.backend.models;

public class EnkatsvarCreatorRequest {
    private QuestionBase[] questionBases;
    private String enkatNamn;
    private String inskickadAv;

    public EnkatsvarCreatorRequest(String enkatNamn, String inskickadAv, QuestionBase[] questionBases) {
        this.questionBases = questionBases;
        this.enkatNamn = enkatNamn;
        this.inskickadAv = inskickadAv;
    }

    public String getInskickadAv() {
        return inskickadAv;
    }

    public void setInskickadAv(String inskickadAv) {
        this.inskickadAv = inskickadAv;
    }

    /**
     * @return String return the enkatNamn
     */
    public String getEnkatNamn() {
        return enkatNamn;
    }

    /**
     * @param enkatNamn the enkatNamn to set
     */
    public void setEnkatNamn(String enkatNamn) {
        this.enkatNamn = enkatNamn;
    }

    public QuestionBase[] getQuestionBases() {
        return questionBases;
    }

    /**
     * @param questionBase the questionBase to set
     */
    public void setQuestionBases(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

}
