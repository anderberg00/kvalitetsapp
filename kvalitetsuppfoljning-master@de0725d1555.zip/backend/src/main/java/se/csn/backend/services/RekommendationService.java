package se.csn.backend.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import se.csn.backend.models.Rekommendation;
import se.csn.backend.repository.RekommendationRepository;

@Service
public class RekommendationService {

    @Autowired
    private final RekommendationRepository rekommendationRepository;

    public RekommendationService(RekommendationRepository rekommendationRepository) {
        this.rekommendationRepository = rekommendationRepository;
    }

    public void addRekommendation(Rekommendation rekommendation) {
        if (rekommendationRepository.existsById(rekommendation.getId())) {
            throw new RuntimeException(String.format("Rekommendation already exists with namn #s"));
        }
        rekommendationRepository.insert(rekommendation);
    }

    public List<Rekommendation> getAllRekommendationer() {
        return rekommendationRepository.findAll();
    }

    public Rekommendation getRekommendationById(String id) {
        return rekommendationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(String.format("Cannot find Rekommendation by namn #s")));
    }

    public void deleteById(String id) {
        this.rekommendationRepository.deleteById(id);
    }

    public void deleteAll() {
        this.rekommendationRepository.deleteAll();
    }
}