package se.csn.backend.models;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("kvalitetsmatt")
public class Kvalitetsmatt {

    @Field
    private String namn;

    public Kvalitetsmatt() {

    }

    public Kvalitetsmatt(String namn) {
        this.namn = namn;
    }

    public String getNamn() {
        return namn;
    }

    public void setNamn(String namn) {
        this.namn = namn;
    }
}
