package se.csn.backend.models;

public class EnkatCreatorRequest {
    private QuestionBase[] questionBases;
    private String enkatNamn;
    private String uppdragNamn;
    private String verksamhetsomradeNamn;

    public EnkatCreatorRequest(String enkatNamn, String uppdragNamn, String verksamhetsomradeNamn,
            QuestionBase[] questionBases) {
        this.questionBases = questionBases;
        this.enkatNamn = enkatNamn;
        this.uppdragNamn = uppdragNamn;
        this.verksamhetsomradeNamn = verksamhetsomradeNamn;
    }

    /**
     * @return QuestionBase[] return the questionBases
     */
    public QuestionBase[] getQuestionBases() {
        return questionBases;
    }

    /**
     * @param questionBases the questionBases to set
     */
    public void setQuestionBase(QuestionBase[] questionBases) {
        this.questionBases = questionBases;
    }

    /**
     * @return String return the enkatNamn
     */
    public String getEnkatNamn() {
        return enkatNamn;
    }

    /**
     * @param enkatNamn the enkatNamn to set
     */
    public void setFieldName(String enkatNamn) {
        this.enkatNamn = enkatNamn;
    }

    /**
     * @param enkatNamn the enkatNamn to set
     */
    public void setEnkatNamn(String enkatNamn) {
        this.enkatNamn = enkatNamn;
    }

    /**
     * @return String return the uppdragsNamn
     */
    public String getUppdragNamn() {
        return uppdragNamn;
    }

    /**
     * @param uppdragsNamn the uppdragsNamn to set
     */
    public void setUppdragNamn(String uppdragNamn) {
        this.uppdragNamn = uppdragNamn;
    }

    /**
     * @return String return the verksamhetsOmradeNamn
     */
    public String getVerksamhetsomradeNamn() {
        return verksamhetsomradeNamn;
    }

    /**
     * @param verksamhetsOmradeNamn the verksamhetsOmradeNamn to set
     */
    public void setVerksamhetsomradeNamn(String verksamhetsomradeNamn) {
        this.verksamhetsomradeNamn = verksamhetsomradeNamn;
    }

}
