package se.csn.backend.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Rekommendation;
import se.csn.backend.models.RekommendationCreatorRequest;
import se.csn.backend.models.Verksamhetsomrade;
import se.csn.backend.services.RekommendationService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/rekommendation")
public class RekommendationController {
    private final RekommendationService rekommendationService;

    @Autowired
    VerksamhetsomradeController verksamhetsomradeController;

    public RekommendationController(RekommendationService rekommendationService) {
        this.rekommendationService = rekommendationService;
    }

    @PostMapping()
    public ResponseEntity addRekommendation(@RequestBody RekommendationCreatorRequest rekommendationCreatorRequest) {
        String id = rekommendationCreatorRequest.getId();
        String motivering = rekommendationCreatorRequest.getMotivering();
        List<Map<String, String>> varden = rekommendationCreatorRequest.getVarden();
        String inskickadAv = rekommendationCreatorRequest.getInskickadAv();
        Verksamhetsomrade verksamhetsomrade = verksamhetsomradeController
                .getVerksamhetsomradeByNamn(rekommendationCreatorRequest.getVerksamhetsomradeNamn()).getBody();
        rekommendationService
                .addRekommendation(new Rekommendation(id, inskickadAv, verksamhetsomrade, motivering, varden));
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping
    public ResponseEntity<List<Rekommendation>> getAllRekommendationer() {
        return ResponseEntity.ok(rekommendationService.getAllRekommendationer());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Rekommendation> getRekommendationById(@PathVariable String id) {
        return ResponseEntity.ok(rekommendationService.getRekommendationById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deleteById(@PathVariable String id) {
        rekommendationService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping()
    public ResponseEntity deleteAllRekommendationer() {
        rekommendationService.deleteAll();
        return ResponseEntity.noContent().build();
    }
}
