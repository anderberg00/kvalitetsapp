package se.csn.backend.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import se.csn.backend.models.Enkat;
import se.csn.backend.models.EnkatCreatorRequest;
import se.csn.backend.models.Kvalitetsmatt;
import se.csn.backend.models.QuestionBase;
import se.csn.backend.models.QuestionBaseList;
import se.csn.backend.models.Uppdrag;
import se.csn.backend.models.Verksamhetsomrade;
import se.csn.backend.repository.UppdragRepository;
import se.csn.backend.services.EnkatService;
import se.csn.backend.services.UppdragService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/enkat")
public class EnkatController {
    private final EnkatService enkatService;

    @Autowired
    UppdragController uppdragController;

    @Autowired
    VerksamhetsomradeController verksamhetsomradeController;

    @Autowired
    KvalitetsmattController kvalitetsmattController;

    public EnkatController(EnkatService enkatService) {
        this.enkatService = enkatService;
    }

    @PostMapping
    public ResponseEntity addEnkat(@RequestBody EnkatCreatorRequest enkatCreatorRequest) {
        QuestionBase[] questionBases = enkatCreatorRequest.getQuestionBases();
        String enkatNamn = enkatCreatorRequest.getEnkatNamn();
        String verksamhetsomradeNamn = enkatCreatorRequest.getVerksamhetsomradeNamn();
        String uppdragsNamn = enkatCreatorRequest.getUppdragNamn();

        Verksamhetsomrade verksamhetsomrade = verksamhetsomradeController
                .getVerksamhetsomradeByNamn(verksamhetsomradeNamn).getBody();
        Uppdrag uppdrag = uppdragController.getUppdragByNamn(uppdragsNamn).getBody();

        enkatService.addEnkat(new Enkat(enkatNamn, uppdrag, verksamhetsomrade, questionBases));
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{enkatNamn}")
    public ResponseEntity addQuestionBasetoEnkat(@PathVariable String enkatNamn,
            @RequestBody QuestionBaseList questionBaseList) {
        Enkat enkat = enkatService.getEnkatByEnkatNamn(enkatNamn);
        enkatService.setQuestionBases(enkat, questionBaseList);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @GetMapping
    public ResponseEntity<List<Enkat>> getAllEnkater() {
        return ResponseEntity.ok(enkatService.getAllEnkater());
    }

    @GetMapping("/{enkatNamn}/questionbases")
    public ResponseEntity<QuestionBase[]> getQuestionBases(@PathVariable String enkatNamn) {
        return ResponseEntity.ok(enkatService.getQuestionBases(enkatNamn));
    }

    @GetMapping("/{enkatNamn}")
    public ResponseEntity<Enkat> getEnkatByEnkatNamn(@PathVariable String enkatNamn) {
        return ResponseEntity.ok(enkatService.getEnkatByEnkatNamn(enkatNamn));
    }

    @DeleteMapping()
    public ResponseEntity deleteAllEnkater() {
        enkatService.deleteAll();
        return ResponseEntity.noContent().build();
    }

    @PutMapping
    public ResponseEntity updateEnkat(@RequestBody Enkat enkat) {
        enkatService.updateEnkat(enkat);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

}
