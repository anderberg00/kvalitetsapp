import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from './user.service';
import { User } from '../models/users.model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {
  
  
  userList : User[] = [] 
  private arAdmin = new BehaviorSubject<boolean>(this.checkArAdmin());
  private namn = new BehaviorSubject<string>(this.getNamn());

  constructor(private http: HttpClient, private userService: UserService,  private snackBar: MatSnackBar, private router: Router) { 
    this.userService.getAll().subscribe((data: User[])=>{
      this.userList = data;
    });
  }

  getAuthToken(name: string, pwd: string) {
    //Lägg till autentisering sen
    return true;
  }

  logIn(username: string, password: string) {
    for(let i = 0; i < this.userList.length; i++) {
      if(username == this.userList[i].username && password == this.userList[i].password) {
        if(this.userList[i].arAdmin) {
          localStorage.setItem('arAdmin', '1');
        } else {
          localStorage.setItem('arAdmin', '0');
        }
        localStorage.setItem('username', username);
        localStorage.setItem('password', password);
        localStorage.setItem('fornamn', this.userList[i].fornamn);
        localStorage.setItem('efternamn', this.userList[i].efternamn);
        localStorage.setItem('mail', this.userList[i].mail);
        this.onLoginSuccess();
        return;
      }
    }
    this.onLoginFailed();
  }

  onLoginSuccess() {
    this.router.navigateByUrl("/profile");
  }

  onLoginFailed() {
    this.openSnackBar("Inloggningen misslyckades. Var vänlig kontrollera användarnamn och lösenord och försök igen", "Stäng");
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  logOut() {
    localStorage.removeItem("arAdmin");
    localStorage.removeItem("username");
    localStorage.removeItem("password");
    localStorage.removeItem("fornamn");
    localStorage.removeItem("efternamn");
    localStorage.removeItem("mail");
  }

  checkArAdmin(): boolean {
    var adminCookie = localStorage.getItem("arAdmin");
    if(adminCookie == "1") {
      return true;
    }
    return false;
  }

  getNamn(): string {
    var username = localStorage.getItem("fornamn") + " " + localStorage.getItem("efternamn");
    if(username == null) {
      return "fail";
    } else {
      return username;
    }
  }

  getMail(): string {
    var mail = localStorage.getItem("mail");
    if(mail == null) {
      return "failed to get mail";
    } else {
      return mail;
    }
  }

  getRoll(): string {
    var arAdmin = localStorage.getItem("arAdmin");
    if(arAdmin == "1") {
      return "Admin";
    } else {
      return "Handläggare";
    }
  }

  get isArAdmin() {
    return this.arAdmin.asObservable();
  }
}
