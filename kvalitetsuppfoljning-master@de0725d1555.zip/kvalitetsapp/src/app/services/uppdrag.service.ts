import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable, of, throwError} from "rxjs";
import { Uppdrag } from '../models/uppdrag.model';

@Injectable({
  providedIn: 'root'
})
export class UppdragService {
  baseUrl = 'http://localhost:8080/api/uppdrag/';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) {
  }

  getUppdrag() {
    let allaUppdrag: Uppdrag[] = [];
    let uppdrag2:Uppdrag = {
      namn: 'Lärtriad',
    };
    let uppdrag1: Uppdrag = {
      namn: 'Årsredovisning',
    };
    allaUppdrag.push(uppdrag1, uppdrag2);
    return allaUppdrag;
  }

  getAll() : Observable<Uppdrag[]> {
    return this.http.get<Uppdrag[]>(this.baseUrl);
  }

  get(uppdrag: Uppdrag): Observable<any> {
    return this.http.get<Uppdrag>(`${this.baseUrl}/${uppdrag.namn}`);
  }

  add(uppdrag : Uppdrag) : Observable<Uppdrag> {
    return this.http.post<Uppdrag>(this.baseUrl, uppdrag, this.httpOptions);
  }

  update(uppdrag: Uppdrag): Observable<any> {
    return this.http.put<Uppdrag>(`${this.baseUrl}/${uppdrag.namn}`, uppdrag);
  }

  delete(uppdrag: Uppdrag): Observable<any> {
    return this.http.delete<Uppdrag>(`${this.baseUrl}/${uppdrag.namn}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}`);
  }

  errorHandler(error : any) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }

}
