import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs';
import { Verksamhetsomrade } from '../models/verksamhetsomrade.model';

@Injectable({
  providedIn: 'root'
})
export class VerksamhetsomradeService {
  baseUrl = 'http://localhost:8080/api/verksamhetsomrade/';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) {
    this.httpOptions.headers.set("Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS, PUT");
    this.httpOptions.headers.set("Access-Control-Allow-Headers",
    "Origin, X-requested-With, Content-Type, Accept, Authorization");
   }

  getAll() : Observable<Verksamhetsomrade[]> {
    return this.http.get<Verksamhetsomrade[]>(this.baseUrl);
  }

  get(namn: any): Observable<Verksamhetsomrade> {
    return this.http.get<Verksamhetsomrade>(`${this.baseUrl}/${namn}`);
  }

  add(verksamhetsomrade: Verksamhetsomrade) : Observable<Verksamhetsomrade> {
    return this.http.post<Verksamhetsomrade>(this.baseUrl, verksamhetsomrade, this.httpOptions);
  }

  update(namn: String, verksamhetsomrade: Verksamhetsomrade): Observable<any> {
    return this.http.put(`${this.baseUrl}/${namn}`, verksamhetsomrade);
  }

  delete(verksamhetsomrade: Verksamhetsomrade): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${verksamhetsomrade.namn}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }

  errorHandler(error : any) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}
