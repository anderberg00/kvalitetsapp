import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Kvalitetsmatt } from '../models/kvalitetsmatt.model';

@Injectable({
  providedIn: 'root'
})
export class KvalitetsmattService {
  baseUrl = 'http://localhost:8080/api/kvalitetsmatt';

  constructor(private http: HttpClient) { 

  }

  getAll() : Observable<Kvalitetsmatt[]> {
    return this.http.get<Kvalitetsmatt[]>(this.baseUrl);
  }

  get(uppdrag: Kvalitetsmatt): Observable<any> {
    return this.http.get<Kvalitetsmatt>(`${this.baseUrl}/${uppdrag.namn}`);
  }

  add(uppdrag : Kvalitetsmatt) : Observable<Kvalitetsmatt> {
    return this.http.post<Kvalitetsmatt>(this.baseUrl, uppdrag);
  }

  update(uppdrag: Kvalitetsmatt): Observable<any> {
    return this.http.put<Kvalitetsmatt>(`${this.baseUrl}/${uppdrag.namn}`, uppdrag);
  }

  delete(uppdrag: Kvalitetsmatt): Observable<any> {
    return this.http.delete<Kvalitetsmatt>(`${this.baseUrl}/${uppdrag.namn}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(`${this.baseUrl}`);
  }
}
