import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Rekommendation } from '../models/rekommendation.model';


@Injectable({
  providedIn: 'root'
})
export class RekommendationService {
  baseUrl = 'http://localhost:8080/api/rekommendation/';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) { 
    this.httpOptions.headers.set("Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS, PUT");
    this.httpOptions.headers.set("Access-Control-Allow-Headers",
    "Origin, X-requested-With, Content-Type, Accept, Authorization");
  }

  getAll() : Observable<Rekommendation[]> {
    return this.http.get<Rekommendation[]>(`${this.baseUrl}`, this.httpOptions);
  }

  get(id: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`, this.httpOptions);
  }

  add(data: any): Observable<any> {
    return this.http.post(this.baseUrl, data);
  }

  update(id: any, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  delete(id: any): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}
