import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Enkatsvar } from '../models/enkatsvar.model';

@Injectable({
  providedIn: 'root'
})
export class EnkatsvarService {
  baseUrl = 'http://localhost:8080/api/enkatsvar';

  constructor(private http: HttpClient) { 

  }

  add(data: any): Observable<any> {
    console.log(data);
    return this.http.post(this.baseUrl, data);
  }

  getAll() : Observable<Enkatsvar[]> {
    return this.http.get<Enkatsvar[]>(this.baseUrl);
  }

  get(id: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }
  
  update(id: any, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  delete(id: any): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}
