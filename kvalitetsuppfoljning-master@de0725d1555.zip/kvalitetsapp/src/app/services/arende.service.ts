import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Arende } from '../models/arende.model';
import { Uppdrag } from '../models/uppdrag.model';
import { Verksamhetsomrade } from '../models/verksamhetsomrade.model';

@Injectable({
  providedIn: 'root'
})
export class ArendeService {
  baseUrl = 'http://localhost:8080/api/arende';

  constructor(private http: HttpClient) { 
 
  }

  getAll() : Observable<Arende[]> {
    return this.http.get<Arende[]>(this.baseUrl);
  }

  get(id: string): Observable<Arende> {
    return this.http.get<Arende>(`${this.baseUrl}/${id}`);
  }

  add(data: any): Observable<any> {
    return this.http.post(this.baseUrl, data);
  }

  update(id: string, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  delete(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}
