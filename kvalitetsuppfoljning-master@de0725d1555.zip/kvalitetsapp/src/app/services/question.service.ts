import { Injectable } from '@angular/core';

import { QuestionBase } from '../questionnaire/question-base';
import { TextboxQuestion } from '../questionnaire/question-textbox';
import { DropdownQuestion } from '../questionnaire/question-dropdown';
import { RadiobuttonQuestion } from '../questionnaire/question-radiobutton';

import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

/*
All the information about the questions is registered here
*/

@Injectable({
  providedIn: 'root'
})
export class QuestionService {
  baseUrl = 'http://localhost:8080/api/questionbase';
  enkatUrl = 'http://localhost:8080/api/enkat';
  questionbases = 'questionbases';

  constructor(private http: HttpClient) { 

  }

  getAllQuestionsByEnkatNamn(id : any) : Observable<any>{
    return this.http.get<Observable<any>[]>(`${this.enkatUrl}/${id}/${this.questionbases}`);
  }

  // TODO: get from a remote source of question metadata
  getQuestions() {

    const questions: QuestionBase<any>[] = [

      new RadiobuttonQuestion({
        key: 'helhetssyn',
        label: 'Har vi behandlat kunden med helhetssyn?',
        options: [
          {key: 'answer1',  value: 'Ja, eftersom vi har satt oss in i kundens situation och gjort en sammanhållen hantering av relaterade ärenden.', customValue: false, },
          {key: 'answer3',   value: 'Nej, eftersom vi inte har satt oss in i kundens situation och därmed inte gjort en sammanhållen hantering av relaterade ärenden.', customValue: false, },
          {key: 'answer5', value: 'Det går inte att bedöma, eftersom det saknas tjänsteanteckningar', customValue: true, }
        ],
        required: true, //TODO: Fix required prints twice bug
        information: 'Utgå ifrån kundens perspektiv i kombination med den sakkunskap du har när du gör din bedömning. Att behandla kunden med helhetssyn i ärendet här innebär att: Vi utgår från hela processen från ansökan till detta beslut. Vi handlägger alla kundens ärenden som är relaterade till varandra vid samma tillfälle. Med helhetssyn menar vi har vi gjort en grundlig analys av ansökan, bifogade handlingar, tidigare ansökan, inkomna e-brev i ärendet så att vi har kunnat fatta beslut på rätt grunder?',
        order: 2,
        additionalTextbox: [
          {key: 'Felet', value: 'Annat svar, förklara nedan: '}
        ]
      }),

      new RadiobuttonQuestion({
        key: 'förvaltningsrätt',
        label: 'Har vi förvaltat kundens ärende på ett korrekt sätt?',
        order: 3,
        options: [
            {key: 'answer1', value: 'Ja, eftersom vi har tagit hänsyn till alla relevanta underlag i ärendet och hanterat ärendet korrekt (t ex vid behov kommunicerat och kompletterat korrekt) och beslutet är korrekt motiverat samt anpassat efter kunden.', customValue: false, },
            {key: 'answer2', value: 'Ja, eftersom...', customValue: true, },
            {key: 'answer3', value: 'Nej, eftersom vi inte har tagit hänsyn till alla relevanta underlag (t ex handlingar i ärendet samt uppgifter som finns i vårt system) och vår beslutsmotivering är bristfällig.', customValue: false,},
            {key: 'answer4', value: 'Nej, eftersom...', customValue: true, },
            {key: 'answer5', value: 'Det går inte att bedöma, eftersom...', customValue: true, }
          ],   
        information: 'När du besvarar frågan ska du ta ställning till hur du anser att vi har hanterat kunden utifrån förvaltningsrättsliga aspekter. Du ska inte bedöma om handläggaren har följt de studiestödsrättsliga reglerna - den bedömningen kommer senare. Fundera utifrån följande: * vi har tagit hänsyn till alla relevanta underlag i ärendet * alla relevanta uppgifter från tredje part har kommunicerats* eventuell komplettering är korrekt gjord * vi har dokumenterat när så har krävs * beslut är korrekt motiverade * vi har bemött kundens samtliga frågor och skäl.  Det är viktigt att besluten är korrekt motiverade genom att rätt motivtexter har använts och att de är anpassade till situationen. Om beslutsmotiveringen är bristfällig har gällande förvaltning inte skett på ett bra sätt.'
      }),

      new RadiobuttonQuestion({
        key: 'rätt',
        label: "Har vi tagit rätt beslut?",
        order: 1, 
        options: [
          {key: 'Ja',  value: 'Ja', customValue: false},
          {key: 'Nej',  value: 'Nej', customValue: false},
        ],
        controlType: "radio",
        additionalTextbox: [
          {key: 'Felet', value: 'Skulle du ha gjort annorlunda? Om ja, berätta hur'}
        ]
      }),

      new TextboxQuestion({
        key: 'bemötande',
        label: "Har vi haft ett bra bemötande?",
        order: 2, 
        controlType: "textbox",
        additionalTextbox: [
          {key: 'Felet', value: 'Skulle du ha gjort annorlunda? Om ja, berätta hur'}
        ]
      }),
    ]
     

    return questions;
  }
     

}

 /* MALLAR:
      new RadiobuttonQuestion({
        key: '',
        label: ' ',
        order: 1,
        options: [
          {key: 'answer1',  value: '', customValue: false},
          {key: 'answer2',  value: '', customValue: true},
          {key: 'answer3',   value: '', customValue: false},
          {key: 'answer4', value: '', customValue: true},
          {key: 'answer5', value: '', customValue: true}
        ],
        information: '',
      }),

      new TextboxQuestion({
        key: '',
        label: '',
        order: 100
      }),*/


      // new TextboxQuestion({
      //   key: 'signature',
      //   label: "Skriv in din signatur",
      //   order: 1
      // }),
/* 
      new RadiobuttonQuestion({
        key: 'forstaBeslut',
        label: 'Är det lätt för nästkommande handläggare att förstå beslutet/beskedet?',
        order: 1,
        options: [
          {key: 'Ja',  value: 'Ja', customValue: true, },
          {key: 'Nej',  value: 'Nej', customValue: true, },
        ],
        information: 'Utgå ifrån att du tar emot kundens följdfrågor på sitt beslut/besked via telefon, e-brev eller i ett nytt handläggningsärende. Du behöver snabbt sätta dig in i vad som hänt i kundens tidigare kontakt med oss. Är det lätt att förstå vad som har hänt?* Framgår det i tjänsteanteckningar och övriga texter varifrån uppgifter är hämtade? * Framgår det tydligt vad kunden ska göra härnäst? * Framgår det varför vi exempelvis begär kompletterande uppgifter och vilka uppgifter vi behöver? * Framgår det på vilka grunder vi fattat beslutet eller vidtagit åtgärder? * Finns relevant dokumentation från exempelvis telefonsamtal i STIS? * Är överenskomna åtgärder genomförda?',
        additionalTextbox: [
          {key: 'GjortAnnorlunda', value: 'Skulle du ha gjort annorlunda? Om ja, berätta hur'}
        ]
      }),

      new DropdownQuestion({
        key: 'testardropdown',
        label: "Testar en dropdown question",
        order: 1,
        options: [
          {key: 'answer1', value: 'Lund', customValue: false},
          {key: 'answer2', value: 'Göteborg', customValue: false},
        ]
      }),

      new RadiobuttonQuestion({
        key: 'beslutstyp',
        label: 'Vilken typ av beslut följer du upp?',
        order: 1,
        options: [
          {key: 'Manuellt',  value: 'Manuellt', customValue: false},
          {key: 'Maskinellt',  value: 'Maskinellt', customValue: false},
        ]
      }),

      new TextboxQuestion({
        key: 'granskningsnr',
        label: 'Skriv in ärendets granskningsnummer (4 siffror)',
        order: 1
      }),

      new TextboxQuestion({
        key: 'csnnr',
        label: 'Skriv in ärendets CSN-nummer (8-siffror)',
        order: 1
      }),

      new RadiobuttonQuestion({
        key: 'arendeKlass',
        label: 'Vilken ärendeklass?',
        order: 1,
        options: [
          {key: 'answer1',  value: 'GRUND', customValue: false, },
          {key: 'answer2',  value: 'GRUNDU', customValue: false, },
          {key: 'answer3',   value: 'MLÅNU', customValue: false, },
          {key: 'answer4', value: 'TBID', customValue: false, },
          {key: 'answer5', value: 'TLÅN', customValue: false, }
        ]
      }),

      new RadiobuttonQuestion({
        key: 'gender',
        label: 'Vilket kön har personen?',
        order: 1,
        options: [
          {key: 'answer1',  value: 'Kvinna', customValue: false, },
          {key: 'answer2',  value: 'Man', customValue: false, }
        ]
      }),
      

      new TextboxQuestion({
        key: 'stisNbr',
        label: 'Skriv in ärendenummer från STIS (max 3 siffror)',
        order: 1
      }),

      new TextboxQuestion({
        key: 'beslutsDatum',
        label: 'Skriv eller kopiera beslutsdatumet här:',
        order: 1
      }),

      new RadiobuttonQuestion({
        key: 'helhetssyn',
        label: 'Har vi behandlat kunden med helhetssyn?',
        options: [
          {key: 'answer1',  value: 'Ja, eftersom vi har satt oss in i kundens situation och gjort en sammanhållen hantering av relaterade ärenden.', customValue: false, },
          {key: 'answer2',  value: 'Ja, eftersom...', customValue: true, },
          {key: 'answer3',   value: 'Nej, eftersom vi inte har satt oss in i kundens situation och därmed inte gjort en sammanhållen hantering av relaterade ärenden.', customValue: false, },
          {key: 'answer4', value: 'Nej, eftersom...', customValue: true,},
          {key: 'answer5', value: 'Det går inte att bedöma, eftersom...', customValue: true, }
        ],
        required: true, //TODO: Fix required prints twice bug
        information: 'Utgå ifrån kundens perspektiv i kombination med den sakkunskap du har när du gör din bedömning. Att behandla kunden med helhetssyn i ärendet här innebär att: Vi utgår från hela processen från ansökan till detta beslut. Vi handlägger alla kundens ärenden som är relaterade till varandra vid samma tillfälle. Med helhetssyn menar vi har vi gjort en grundlig analys av ansökan, bifogade handlingar, tidigare ansökan, inkomna e-brev i ärendet så att vi har kunnat fatta beslut på rätt grunder?',
        order: 2
      }),

      new RadiobuttonQuestion({
        key: 'förvaltningsrätt',
        label: 'Har vi förvaltat kundens ärende på ett korrekt sätt?',
        order: 3,
        options: [
            {key: 'answer1', value: 'Ja, eftersom vi har tagit hänsyn till alla relevanta underlag i ärendet och hanterat ärendet korrekt (t ex vid behov kommunicerat och kompletterat korrekt) och beslutet är korrekt motiverat samt anpassat efter kunden.', customValue: false, },
            {key: 'answer2', value: 'Ja, eftersom...', customValue: true, },
            {key: 'answer3', value: 'Nej, eftersom vi inte har tagit hänsyn till alla relevanta underlag (t ex handlingar i ärendet samt uppgifter som finns i vårt system) och vår beslutsmotivering är bristfällig.', customValue: false,},
            {key: 'answer4', value: 'Nej, eftersom...', customValue: true, },
            {key: 'answer5', value: 'Det går inte att bedöma, eftersom...', customValue: true, }
          ],   
        information: 'När du besvarar frågan ska du ta ställning till hur du anser att vi har hanterat kunden utifrån förvaltningsrättsliga aspekter. Du ska inte bedöma om handläggaren har följt de studiestödsrättsliga reglerna - den bedömningen kommer senare. Fundera utifrån följande: * vi har tagit hänsyn till alla relevanta underlag i ärendet * alla relevanta uppgifter från tredje part har kommunicerats* eventuell komplettering är korrekt gjord * vi har dokumenterat när så har krävs * beslut är korrekt motiverade * vi har bemött kundens samtliga frågor och skäl.  Det är viktigt att besluten är korrekt motiverade genom att rätt motivtexter har använts och att de är anpassade till situationen. Om beslutsmotiveringen är bristfällig har gällande förvaltning inte skett på ett bra sätt.'
      }),

      new RadiobuttonQuestion({
        key: 'rattBeslut',
        label: 'Är beslutet rätt? (Dvs. ärendet med datum som du har blivit tilldelad)',
        order: 6,
        options: [
          {key: 'answer1',  value: 'Ja, beskriv hur du kommit fram till att beslutet/beskedet är rätt', customValue: true},
          {key: 'answer2',  value: 'Nej, beskriv hur du kommit fram till att beslutet/beskedet är fel', customValue: true},
        ],
        information: 'När du besvarar frågan ska du ta ställning till om du anser att svaret är rätt enligt studiestödsrättsliga regler. Du ska däremot inte bedöma om handläggaren följt aktuella rutiner (förvaltning). Denna bedömning har du redan gjort. Vissa svar kan grunda sig på tidigare bedömningar gjorda av andra handläggare. Det är viktigt att du tänker på att det är omständigheterna vid tidpunkten för svaret som gäller och inte vad som har hänt senare. Du ska t ex ta ställning till om beslutet är fattat på rätt grunder, för rätt tid, rätt summa bidrag resp. lån, rätt nivå och omfattning på studierna. Tänk utifrån vilka bedömningar du ser att du har behövt ta ställning till i ärendet. Någon utanför CSN bör kunna förstå.',
      }),

      new RadiobuttonQuestion({
        key: 'orsak',
        label: 'Vad är orsaken till felet? (Om flera alternativ är aktuella välj Annat och beskriv)',
        order: 7,
        options: [
          {key: 'answer1',  value: 'Fel i registrering', customValue: false,},
          {key: 'answer2',  value: 'Bristande dokumentation', customValue: false, },
          {key: 'answer3',   value: 'Fel i bedömning', customValue: false, },
          {key: 'answer4', value: 'Annat, nämligen', customValue: true, }
        ]
      }),

      new RadiobuttonQuestion({
        key: 'felUtbet',
        label: 'Orsakade beslutet en felaktig utbetalning?',
        order: 8,
        options: [
          {key: 'answer1',  value: 'Nej', customValue: false, },
          {key: 'answer2',  value: 'Ja, och den blev stor', customValue: false, },
          {key: 'answer3',   value: 'Ja, och den blev liten', customValue: false, },
          {key: 'answer4', value: 'Inte aktuellt och går inte att avgöra eftersom', customValue: true, },
        ]
      }),

      new RadiobuttonQuestion({
        key: 'felAter',
        label: 'Orsakade beslutet ett felaktigt återkrav?',
        order: 9,
        options: [
          {key: 'answer1',  value: 'Nej', customValue: false, },
          {key: 'answer2',  value: 'Ja, och det blev stort', customValue: false, },
          {key: 'answer3',   value: 'Ja, och det blev litet', customValue: false,},
          {key: 'answer4', value: 'Går inte att avgöra eftersom', customValue: true, },
        ]
      }),

      new TextboxQuestion({
        key: 'losning',
        label: 'Hur skulle vi ha gjort för att beslutet/beskedet skulle ha blivit rätt?',
        order: 10
      }),

      new RadiobuttonQuestion({
        key: 'forbattring',
        label: 'Efter att du har bedömt beslutet som rätt är det något du ser vi skulle kunna göra bättre vid ett senare tillfäle - om ja, vänligen skriv och berätta:',
        order: 11,
        options: [
          {key: 'answer1',  value: 'Ja, nämligen', customValue: true, },
          {key: 'answer2',  value: 'Nej', customValue: false, },
        ]
      }),


    ]; */