import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Enkat } from '../models/enkat.model';
import { Enkatsvar } from '../models/enkatsvar.model';
import { Uppdrag } from '../models/uppdrag.model';
import { Verksamhetsomrade } from '../models/verksamhetsomrade.model';
import { QuestionBase } from '../questionnaire/question-base';
import { QuestionControlService } from '../questionnaire/question-control.service';
import { DropdownQuestion } from '../questionnaire/question-dropdown';
import { RadiobuttonQuestion } from '../questionnaire/question-radiobutton';
import { QuestionService } from './question.service';

@Injectable({
  providedIn: 'root'
})
export class EnkatService {
  baseUrl = 'http://localhost:8080/api/enkat';

  constructor(private http: HttpClient) { }
  

  addQuestionBases(namn: any, data : any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${namn}`, data);
  }

  add(data: any): Observable<any> {
    return this.http.post(this.baseUrl, data);
  }

  getAll() : Observable<Enkat[]> {
    return this.http.get<Enkat[]>(this.baseUrl);
  }

  get(namn: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/${namn}`);
  }

  update(namn: any, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${namn}`, data);
  }

  delete(namn: any): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${namn}`);
  }

  deleteAll(): Observable<any> {
    return this.http.delete(this.baseUrl);
  }
}

/*
  getEnkater() {
    let allaEnkater: Enkat[] = [];
    const questions: QuestionBase<any>[] = [

      new DropdownQuestion({
        key: 'testardropdown',
        label: "Testar en dropdown question",
        order: 4,
        options: [
          {key: 'answer1', value: 'Lund', customValue: true},
          {key: 'answer2', value: 'Göteborg', customValue: false},
        ]
      }),

      new RadiobuttonQuestion({
        key: 'beslutstyp',
        label: 'Vilken typ av beslut följer du upp?',
        order: 2,
        options: [
          {key: 'answer1',  value: 'Manuellt', customValue: false},
          {key: 'answer2',  value: 'Maskinellt', customValue: false},
        ]
      }),

    new RadiobuttonQuestion({
      key: 'gender',
      label: 'Vilket kön har personen?',
      order: 1,
      options: [
        {key: 'answer1',  value: 'Kvinna', customValue: false},
        {key: 'answer2',  value: 'Man', customValue: false}
      ]
    })];
    
    
    let identifieringsattribut: {key: string, value: string}[] = [];
    identifieringsattribut.push(
      {key: "Ärendeklass", value: "UTLAND"},
      {key: "Ärendegrupp", value: "HH"}
    );

    let v : Verksamhetsomrade = {
      namn: "Hemutrustningslån",
      information: [
        {key: "Lånenummer", visaHandlaggare: true, kolumnExcel: "9"},
        {key: "Beslutsdatum", visaHandlaggare: true, kolumnExcel: "10"},
        {key: "Kön", visaHandlaggare: false, kolumnExcel: "11"},
        ]
      }
    let uppdrag2:Uppdrag = {
      namn: 'Lärtriad',
    };
    let uppdrag1: Uppdrag = {
      namn: 'Årsredovisning',
    };

    allaEnkater.push(new Enkat("Årsredovisning UTLAND", v, uppdrag1, questions));
    allaEnkater.push(new Enkat("Lärtriad UTLAND", v, uppdrag2, questions));
    return allaEnkater;
  }*/