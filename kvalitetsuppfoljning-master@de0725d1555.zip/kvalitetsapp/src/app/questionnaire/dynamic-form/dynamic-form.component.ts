import { JsonpClientBackend } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Arende } from 'src/app/models/arende.model';
import { ArendeService } from 'src/app/services/arende.service';
import { EnkatService } from 'src/app/services/enkat.service';
import { EnkatsvarService } from 'src/app/services/enkatsvar.service';
import { QuestionService } from 'src/app/services/question.service';

import { QuestionBase } from '../question-base';
import { QuestionControlService } from '../question-control.service';


@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  providers: [ QuestionControlService ],
})

/**
 * The entry point and main container for the form. Contains a present list of questions binding
 * each one to a question that matches the DynamicFormQuestionComponent
 */
export class DynamicFormComponent implements OnInit {
    questions: QuestionBase<any>[] = [];
    tempquestions: QuestionBase<any>[] = [];

    @Input() nonSubmittable!: boolean;
    form!: FormGroup;
    arende!: Arende;


    constructor(private fb: FormBuilder, private questionService: QuestionService, private arendeService: ArendeService, private route: ActivatedRoute,
       private enkatsvarService: EnkatsvarService, private qcs: QuestionControlService, private router: Router) {
    }

    ngOnInit(): void {
      //this.form = this.qcs.toFormGroup(this.questions as QuestionBase<string>[]);
      this.getArende(this.route.snapshot.params.granskningsnummer);
      this.form = this.fb.group({
        
      })
    }
  
    getArende(id: string): void {
      this.arendeService.get(id)
        .subscribe(
          data => {
            this.arende = data;
            this.questionService.getAllQuestionsByEnkatNamn(this.arende.enkat.id).subscribe((data) => {
              this.questions = this.arende.enkat.questionBases;

              this.questions.forEach(question => {
                //Kontroll för svaret
                
                if (question.required) {
                  this.form.addControl(question.key, this.fb.control('',[Validators.required]));
                } else {
                  this.form.addControl(question.key, this.fb.control(''));
                }
                //Kontroll för customvalue för radiofrågor
                /* if (question.controlType == 'radio') {
                  question.options.forEach(option => {
                    this.form.addControl(option.key, this.fb.control(''));
                  })
                }  */
                //Kontroll för extra fritextruta
                if(question.additionalTextbox.length != 0) {
                  question.additionalTextbox.forEach(additionalTextbox => {
                    this.form.addControl(additionalTextbox.key, this.fb.control(''));
                  })
                }
              }) 
            }); 
        });
    }
    
    onSubmit(data : any) {
        let questionBases: { key: string; value: string; valuesAdditionalTextbox: string[]; }[] = []; 
        
        this.questions.forEach(question => {
          let value = this.form.controls[question.key].value;

          let valuesAdditionalTextBoxes: string[] = [];
          for(let i = 0; i < question.additionalTextbox.length; i++) {
            console.log(this.form.controls[question.additionalTextbox[i].key])
            let valueATB = this.form.controls[question.additionalTextbox[i].key].value;
            console.log(valueATB);
            valuesAdditionalTextBoxes.push(valueATB);
          }
          const questionbase =  {
            "key": question.key,
            "value": value,
            "valuesAdditionalTextbox": valuesAdditionalTextBoxes,
          }

        questionBases.push(questionbase);
        })
        
        const sendData = {questionBases};
        this.enkatsvarService.update(this.arende.id, sendData).subscribe();
        this.router.navigateByUrl("/mina-arenden");
  }

  getForm() {
    return this.form;
  }
}