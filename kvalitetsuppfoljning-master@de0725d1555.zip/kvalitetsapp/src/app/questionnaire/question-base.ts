import { Kvalitetsmatt } from "../models/kvalitetsmatt.model";
/*
Base class to represent the controls that represents a question in the questionnaire.
*/
export class QuestionBase<T> {
    //Svaren på frågorna
    value?: T;
    customValue?: T;
    valuesAdditionalTextbox: { key: string; value: string; }[];

    kvalitetsmatt!: Kvalitetsmatt; 
    key!: string;
    label!: string;
    required?: boolean;
    order?: number;
    controlType?: string;
    information?: string;
    options: { key: string; value: string; customValue: boolean}[];
    additionalTextbox!: { key: string; value: string; }[];
    
    constructor(options: {
        value?: T; 
        customValue?: T;
        valuesAdditionalTextbox?: {key: string, value: string, customValue: boolean}[];
        kvalitetsmatt?: Kvalitetsmatt;
        key?: string;
        label?: string;
        required?: boolean;
        order?: number;
        controlType?: string;
        information?: string;
        additionalTextbox?: {key: string, value: string}[];
        options?: {key: string, value: string, customValue: boolean}[];
    }) {
        this.value = options.value;
        this.customValue = options.customValue;
        this.valuesAdditionalTextbox = options.valuesAdditionalTextbox || [];
        this.kvalitetsmatt = options.kvalitetsmatt || new Kvalitetsmatt();
        this.key = options.key || '';
        this.label = options.label || '';
        this.required = !!options.required;
        this.order = options.order === undefined ? 1 : options.order;
        this.controlType = options.controlType || '';
        this.information = options.information || '';
        this.options = options.options || [];
        this.additionalTextbox = options.additionalTextbox || [];
    }

    public getKvalitetsmatt(): Kvalitetsmatt | undefined {
        return this.kvalitetsmatt;
    }
    public setKvalitetsmatt(kvalitetsmatt: Kvalitetsmatt) {
        this.kvalitetsmatt = kvalitetsmatt;
    }

    public getAdditionalTextbox(): { key: string; value: string; }[] {
        return this.additionalTextbox;
    }
    public setAdditionalTextbox(value: { key: string; value: string; }[]) {
        this.additionalTextbox = value;
    }

    public getOptions(): { key: string; value: string; customValue: boolean}[] {
        return this.options;
    }
    public setOptions(value: { key: string; value: string; customValue: boolean}[]) {
        this.options = value;
    }

    public getCustomValue(): T | undefined {
        return this.customValue;
    }
    public setCustomValue(value: T | undefined) {
        this.customValue = value;
    }

    public getValuesAdditionalTextbox(): { key: string; value: string; }[] {
        return this.valuesAdditionalTextbox;
    }
    public setValuesAdditionalTextbox (value: { key: string; value: string; }[]) {
        this.valuesAdditionalTextbox = value;
    }

    public getInformation(): string  | undefined{
        return this.information;
    }
    public setInformation(value: string) {
        this.information = value;
    }

    public getControlType(): string | undefined {
        return this.controlType;
    }
    public setControlType(value: string) {
        this.controlType = value;
    }

    public getOrder(): number | undefined {
        return this.order;
    }
    public setOrder(value: number) {
        this.order = value;
    }

    public getRequired(): boolean | undefined{
        return this.required;
    }
    public setRequired(value: boolean) {
        this.required = value;
    }

    public getValue(): T | undefined {
        return this.value;
    }
    public setValue(value: T | undefined) {
        this.value = value;
    }

    public getKey() {
        return this.key;
    }
    public setKey(value: string) {
        this.key = value;
    }

    public getLabel(): string | undefined{
        return this.label;
    }
    public setLabel(value: string) {
        this.label = value;
    }
}