import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicFormShowOnlyAnswersComponent } from './dynamic-form-show-only-answers.component';

describe('DynamicFormShowOnlyAnswersComponent', () => {
  let component: DynamicFormShowOnlyAnswersComponent;
  let fixture: ComponentFixture<DynamicFormShowOnlyAnswersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicFormShowOnlyAnswersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicFormShowOnlyAnswersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
