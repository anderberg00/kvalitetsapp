import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { QuestionBase } from '../question-base';

@Component({
  selector: 'app-dynamic-form-show-only-answers',
  templateUrl: './dynamic-form-show-only-answers.component.html',
  styleUrls: ['./dynamic-form-show-only-answers.component.scss']
})
export class DynamicFormShowOnlyAnswersComponent implements OnInit {
  @Input() questions: QuestionBase<any>[] = [];

  constructor() { }

  ngOnInit(): void {
  }

}
