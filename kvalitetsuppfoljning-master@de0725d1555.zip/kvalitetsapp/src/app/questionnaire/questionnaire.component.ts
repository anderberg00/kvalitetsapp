import { Component } from '@angular/core';

import { QuestionService } from '../services/question.service';
import { QuestionBase } from './question-base';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-questionnaire',
  template: `
    <div>
      <!-- <app-dynamic-form [questions]="questions$ | async"></app-dynamic-form> -->
    </div>
  `,
  providers:  [QuestionService]
})
export class QuestionnaireComponent {

  //questions$: Observable<QuestionBase<any>[]>;

  constructor(private service: QuestionService) {
    //this.questions$ = service.getQuestions();
  }

}
