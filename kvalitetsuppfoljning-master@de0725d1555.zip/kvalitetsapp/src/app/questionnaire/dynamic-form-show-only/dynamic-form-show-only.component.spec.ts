import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicFormShowOnlyComponent } from './dynamic-form-show-only.component';

describe('DynamicFormShowOnlyComponent', () => {
  let component: DynamicFormShowOnlyComponent;
  let fixture: ComponentFixture<DynamicFormShowOnlyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicFormShowOnlyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicFormShowOnlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
