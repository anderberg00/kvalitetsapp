import { Component, Input, OnInit } from '@angular/core';
import { QuestionBase } from '../question-base';

@Component({
  selector: 'app-dynamic-form-show-only',
  templateUrl: './dynamic-form-show-only.component.html',
  styleUrls: ['./dynamic-form-show-only.component.scss']
})
export class DynamicFormShowOnlyComponent implements OnInit {
  @Input() questions: QuestionBase<any>[] = [];
  
  constructor() { 

  }

  ngOnInit(): void {
  }

}
