import { Injectable } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { QuestionBase } from './question-base';

/*
Collects a set of FormGroup instances from the QuestionBase model. 
*/
@Injectable()
export class QuestionControlService {
  formGroup! : FormGroup;

  constructor(private fb : FormBuilder) { }

  toFormGroup(questions: QuestionBase<string>[] ) {
    
    this.formGroup = this.fb.group({

    });

    questions.forEach(question => {
      //För svaret på frågan
      if (question.required) {
        this.formGroup.addControl(question.key || '', new FormControl(question.value || '', Validators.required))
      } else {
        this.formGroup.addControl(question.key || '', new FormControl(question.value || ''))
      }

      //För customvalue svar
      for (let i = 0; i < question.getOptions().length; i++) {
        if (question.options[i].customValue == true) {
          this.formGroup.addControl(question.options[i].key, new FormControl(''));
        }
      }

       //För additionaltextbox svar
      if (question.getAdditionalTextbox() != undefined) {
        for (let i = 0; i < question.getAdditionalTextbox().length; i++) {
          this.formGroup.addControl(question.getAdditionalTextbox()[i].key, new FormControl(''));
        }
      } 

    });

    return this.formGroup;
  }
}

/* toFormGroup(questions: QuestionBase<string>[] ) {
    
  const group: any = {};

  questions.forEach(question => {
    group[question.key] = question.required ? new FormControl(question.value || '', Validators.required)
                                            : new FormControl(question.value || '');
  });

  questions.forEach(question => {
    
    }
  )

  return new FormGroup(group);
} */


/* for (let i = 0; i < question.options.length; i++) {
  if (question.options[i].customValue == true) {
    this.form.addControl(question.options[i].key, new FormControl(''));
    }
  } */