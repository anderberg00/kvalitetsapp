/*
Class that presents  a question given the users input in the type field in class QuestionBase. 
*/
import { QuestionBase } from './question-base';

export class TextboxQuestion extends QuestionBase<string> {
  controlType = 'textbox';
}