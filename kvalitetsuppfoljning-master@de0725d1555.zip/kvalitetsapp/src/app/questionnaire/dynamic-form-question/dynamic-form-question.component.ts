import { Component, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { QuestionBase } from '../question-base';

@Component({
  selector: 'app-question',
  templateUrl: './dynamic-form-question.component.html',
  styleUrls: ['./dynamic-form-question.component.scss']
})
/*
Renders the details of an individual question based on given values in the QuestionBase object. 
Creates form groups and populates them with controls which is defined in the QuestionBase model. 
*/
export class DynamicFormQuestionComponent {
  @Input() question!: QuestionBase<any>;
  @Input() form!: FormGroup;

  get isValid() {
     return this.form.controls[this.question.key].valid;
  }

}
