/*
Class that presents a question given the users input in the type field in class QuestionBase. 
*/
import { QuestionBase } from './question-base';

export class RadiobuttonQuestion extends QuestionBase<string> {
  controlType = 'radio';
}