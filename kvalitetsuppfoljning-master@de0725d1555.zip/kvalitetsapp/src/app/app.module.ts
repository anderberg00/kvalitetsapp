import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { ChartModule } from 'angular2-chartjs';

import { CsnKomponentbibliotekModule } from 'csn-komponentbibliotek';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatExpansionModule} from '@angular/material/expansion';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatCardModule} from '@angular/material/card';

import { HeaderComponent } from './containers/header/header.component';
import { AppComponent } from './app.component';
import { ProfileComponent } from './views/profile/profile.component';
import { LoginComponent } from './views/login/login.component';
import { StatisticsComponent } from './views/statistics/statistics.component';
import { SidebarComponent } from './containers/sidebar/sidebar.component';
import { DashboardsComponent } from './views/dashboards/dashboards.component';
import { MinaArendenComponent } from './views/mina-arenden/mina-arenden.component';
import { HanteraArendenComponent } from './views/hantera-arenden/hantera-arenden.component';
import { HanteraProcesserComponent } from './views/hantera-processer/hantera-processer.component';
import { HandbokComponent } from './views/handbok/handbok.component';
import { QuestionnaireComponent } from './questionnaire/questionnaire.component';
import { DynamicFormComponent } from './questionnaire/dynamic-form/dynamic-form.component';
import { DynamicFormQuestionComponent } from './questionnaire/dynamic-form-question/dynamic-form-question.component';
import { RedigeraArendeComponent } from './views/redigera-arende/redigera-arende.component';
import { VisaArendeComponent } from './views/visa-arende/visa-arende.component';
import { RedigeraVerksamhetsomradeComponent } from './views/redigera-verksamhetsomrade/redigera-verksamhetsomrade.component';
import { RedigeraUppdragComponent } from './views/redigera-uppdrag/redigera-uppdrag.component';
import { RegistreraArendenComponent } from './views/registrera-arenden/registrera-arenden.component';
import { HanteraEnkaterComponent } from './views/hantera-enkater/hantera-enkater.component';
import { RedigeraEnkatComponent } from './views/redigera-enkat/redigera-enkat.component';
import { SkapaEnkatComponent } from './views/skapa-enkat/skapa-enkat.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatListModule } from '@angular/material/list';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { VisaEnkatComponent } from './views/visa-enkat/visa-enkat.component';
import { VisaArendeAdminComponent } from './views/visa-arende-admin/visa-arende-admin.component';
import { MatRadioModule } from '@angular/material/radio';

import { UppdragService } from './services/uppdrag.service';
import { VerksamhetsomradeService } from './services/verksamhetsomrade.service';
import { EnkatService } from './services/enkat.service';
import { ArendeService } from './services/arende.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatMenuModule } from '@angular/material/menu';
import { LayoutModule } from '@angular/cdk/layout';
import { HanteraRekommendationerComponent } from './views/hantera-rekommendationer/hantera-rekommendationer.component';
import { RekommenderaArendenComponent } from './views/rekommendera-arende/rekommendera-arenden.component';
import { VisaRekommendationComponent } from './views/visa-rekommendation/visa-rekommendation.component';
import { QuestionService } from './services/question.service';
import { DynamicFormShowOnlyComponent } from './questionnaire/dynamic-form-show-only/dynamic-form-show-only.component';
import { VisaEnkatsvarComponent } from './views/visa-enkatsvar/visa-enkatsvar.component';
import { DynamicFormShowOnlyAnswersComponent } from './questionnaire/dynamic-form-show-only-answers/dynamic-form-show-only-answers.component';
import { UserService } from './services/user.service';
import { VisaEnkatsvarAdminComponent } from './views/visa-enkatsvar-admin/visa-enkatsvar-admin.component';

@NgModule({
  declarations: [
    AppComponent,
    ProfileComponent,
    LoginComponent,
    StatisticsComponent,
    HeaderComponent,
    SidebarComponent,
    DashboardsComponent,
    MinaArendenComponent,
    HanteraProcesserComponent,
    HandbokComponent,
    QuestionnaireComponent,
    DynamicFormComponent,
    DynamicFormQuestionComponent,
    HanteraArendenComponent,
    RedigeraArendeComponent,
    VisaArendeComponent,
    RedigeraVerksamhetsomradeComponent,
    RedigeraUppdragComponent,
    RegistreraArendenComponent,
    HanteraEnkaterComponent,
    RedigeraEnkatComponent,
    SkapaEnkatComponent,
    VisaEnkatComponent,
    VisaArendeAdminComponent,
    DashboardComponent,
    HanteraRekommendationerComponent,
    RekommenderaArendenComponent,
    VisaRekommendationComponent,
    DynamicFormShowOnlyComponent,
    VisaEnkatsvarComponent,
    DynamicFormShowOnlyAnswersComponent,
    VisaEnkatsvarAdminComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CsnKomponentbibliotekModule,
    FormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    MatSidenavModule,
    MatDividerModule,
    MatIconModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatChipsModule,
    MatTableModule,
    MatExpansionModule,
    Ng2OrderModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    MatBadgeModule,
    MatCardModule,
    MatTabsModule,
    MatSortModule,
    MatPaginatorModule,
    MatListModule,
    MatStepperModule,
    MatSnackBarModule, 
    HttpClientModule,
    MatRadioModule,
    MatGridListModule,
    MatMenuModule,
    LayoutModule,
    ChartModule
  ],
  providers: [QuestionService, UppdragService, VerksamhetsomradeService, EnkatService, ArendeService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
