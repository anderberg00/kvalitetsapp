import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaEnkatComponent } from './visa-enkat.component';

describe('VisaEnkatComponent', () => {
  let component: VisaEnkatComponent;
  let fixture: ComponentFixture<VisaEnkatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisaEnkatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaEnkatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
