import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Enkat } from 'src/app/models/enkat.model';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { EnkatService } from 'src/app/services/enkat.service';

@Component({
  selector: 'app-visa-enkat',
  templateUrl: './visa-enkat.component.html',
  styleUrls: ['./visa-enkat.component.scss']
})
export class VisaEnkatComponent implements OnInit {
  title: string = "Enkät"
  allaFragor!: QuestionBase<any>[];
  enkatAttVisa!: Enkat

  constructor(private route: ActivatedRoute, private router : Router, private enkatService : EnkatService) { 
  
  }

  ngOnInit(): void {
    this.getEnkat(this.route.snapshot.params.namn);
  }

  getEnkat(id: string): void {
    this.enkatService.get(id)
      .subscribe(
        (data: Enkat) => {
          this.enkatAttVisa = data;
          this.title = "Enkät " + this.enkatAttVisa.id;
          this.allaFragor = this.enkatAttVisa.questionBases;
      });
  }

  onClickBackVisaEnkat() {
    this.router.navigate(['hantera-enkater']);
  }

}
