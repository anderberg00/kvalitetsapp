import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { User } from 'src/app/models/users.model';
import { UserService } from 'src/app/services/user.service';
import { AuthenticationService } from 'src/app/services/authentication.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})

export class LoginComponent {
  title: string = "Kvalitetsapplikation";
  username!: string;
  password!: string;
  loginForm!: FormGroup;
  userList : User[] = [] 
  

  constructor(private router: Router, private fb: FormBuilder,
     private userService: UserService, private authenticationService: AuthenticationService) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    })

    this.userService.getAll().subscribe((data: User[])=>{
      this.userList = data;
    });
  }

  onClickLogIn() {
    this.authenticationService.logIn(this.loginForm.controls["username"].value, this.loginForm.controls["password"].value);
  }
}