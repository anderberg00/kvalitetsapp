import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { Arende } from 'src/app/models/arende.model';
import { Enkat } from 'src/app/models/enkat.model';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { ArendeService } from 'src/app/services/arende.service';
import { EnkatService } from 'src/app/services/enkat.service';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

@Component({
  selector: 'app-redigera-arende',
  templateUrl: './redigera-arende.component.html',
  styleUrls: ['./redigera-arende.component.scss']
})

export class RedigeraArendeComponent implements OnInit {
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaUppdrag: Uppdrag[] = [];
  allaArenden: Arende[] = [];
  allaEnkater: Enkat[] = [];

  valtUppdrag!: Uppdrag | any;
  valdEnkat!: Enkat | any;

  title: string = 'Redigera ärende';
  arendeAttVisa!: any;

  formData!: FormGroup;
  uppladdadSamtalsfil!: File;

  constructor(private router: Router, private enkatService: EnkatService, private snackBar: MatSnackBar, private route: ActivatedRoute, private fb: FormBuilder, private arendeService : ArendeService, private verksamhetsomradeService: VerksamhetsomradeService, private uppdragService: UppdragService) { 
    this.formData = this.fb.group({

    });

    this.getArende(this.route.snapshot.params.granskningsnummer);
    
    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.enkatService.getAll().subscribe((data: Enkat[])=>{
      this.allaEnkater = data;
    });
  }

  ngOnInit(): void {
  }

  getArende(id: string): void {
    this.arendeService.get(id)
      .subscribe(
        data => {
          this.arendeAttVisa = data;
          this.valtUppdrag = this.arendeAttVisa.uppdrag;
          this.valdEnkat = this.arendeAttVisa.enkat;

           //forms
           this.formData = this.fb.group({
            regUppdrag: [this.arendeAttVisa.uppdrag, Validators.required],
            regAr: [this.arendeAttVisa.ar, Validators.required],
            regKontor: [this.arendeAttVisa.kontor, Validators.required],
            regSlutdatum: [this.arendeAttVisa.slutdatum, Validators.required],
            regNotifieringsdatum: [this.arendeAttVisa.notifieringsdatum, Validators.required],
            regStatus:[this.arendeAttVisa.status, Validators.required],
            regHandlaggareNotifiering: [this.arendeAttVisa.handlaggareNotifiering, Validators.required],
            regForstaHandlaggare:[this.arendeAttVisa.forstaHandlaggare, Validators.required],
            regAndraHandlaggare:[this.arendeAttVisa.andraHandlaggare],
            regEnkat:[this.arendeAttVisa.enkat.namn]
          })
          
          console.log(this.arendeAttVisa);

          for(let i = 0; i < this.arendeAttVisa.varden.length; i++) {
            this.formData.addControl(this.arendeAttVisa.varden[i].key, new FormControl(this.arendeAttVisa.varden[i].value));
          }
    });
  }

  onClickDelete() {
    this.arendeService.delete(this.arendeAttVisa.id).subscribe();
    this.router.navigate(['hantera-arenden']);
  }

  changeUppdrag(event : any) {
    this.valtUppdrag = this.allaUppdrag.find(p => p.namn === event.target.value);
  }

  changeEnkat(event : any) {
    this.valdEnkat = this.allaEnkater.find(p => p.namn === event.target.value);
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  onClickSaveChanges(data: any) {
   /*  for (let i = 0; i < this.arendeAttVisa.varden.length; i++) {
      this.arendeAttVisa.varden[i].varde = (<HTMLInputElement>document.getElementById(this.arendeAttVisa.varden[i].attribut)).value;
    } */
/* 
    let varden = [];
      for (let j = 0; j < this.valtVerksamhetsomrade.information.length; j++) {
        let kolumnExcelInt = parseInt(this.valtVerksamhetsomrade.information[j].kolumnExcel);
        varden.push({key: this.valtVerksamhetsomrade.information[j].key, value: this.data[i][kolumnExcelInt-1]});
    } */
    console.log(this.arendeAttVisa);

    for (let i = 0; i < this.arendeAttVisa.varden.length; i++) {
      let varde = this.formData.controls[this.arendeAttVisa.varden[i].key].value;
      this.arendeAttVisa.varden[i].value = varde;
    }
    this.arendeAttVisa.uppdrag = this.valtUppdrag;
    this.arendeAttVisa.enkat = this.valdEnkat;

    console.log(data.regKontor);

    const postData = {
      id: this.arendeAttVisa.id,
      ar: data.regAr,
      kontor: data.regKontor,
      slutdatum: data.regSlutdatum,
      notifieringsdatum: data.regNotifieringsdatum,
      handlaggareNotifiering: data.regHandlaggareNotifiering,
      forstaHandlaggare: data.regForstaHandlaggare,
      andraHandlaggare: data.regAndraHandlaggare,
      status: this.arendeAttVisa.status,
      enkatNamn: data.regEnkat,
      verksamhetsomradeNamn: this.arendeAttVisa.verksamhetsomrade.namn,
      uppdragNamn: data.regUppdrag,
      varden : this.arendeAttVisa.varden,
      arGranskad: this.arendeAttVisa.arGranskad,
    };
    
    this.arendeService.update(this.arendeAttVisa.id, postData);
    
    this.openSnackBar("Dina ändringar har sparats!", "Stäng");
  }

  onClickTillbaka() {
    this.router.navigate(['hantera-arenden']);
  }
}
