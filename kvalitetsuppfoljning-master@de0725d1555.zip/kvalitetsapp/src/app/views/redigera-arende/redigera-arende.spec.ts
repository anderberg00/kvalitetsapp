import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedigeraArendeComponent } from './redigera-arende.component';

describe('RedigeraArendeComponent', () => {
  let component: RedigeraArendeComponent;
  let fixture: ComponentFixture<RedigeraArendeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedigeraArendeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedigeraArendeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
