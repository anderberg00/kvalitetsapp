import { Component, OnInit, ViewChild } from '@angular/core';
import { Form, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { queueScheduler } from 'rxjs';
import { Enkat } from 'src/app/models/enkat.model';
import { DynamicFormComponent } from 'src/app/questionnaire/dynamic-form/dynamic-form.component';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { QuestionControlService } from 'src/app/questionnaire/question-control.service';
import { RadiobuttonQuestion } from 'src/app/questionnaire/question-radiobutton';
import { TextboxQuestion } from 'src/app/questionnaire/question-textbox';
import { QuestionService } from 'src/app/services/question.service';
import { EnkatService } from 'src/app/services/enkat.service';
@Component({
  selector: 'app-hantera-enkater',
  templateUrl: './hantera-enkater.component.html',
  styleUrls: ['./hantera-enkater.component.scss']
})
export class HanteraEnkaterComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  title: string = 'Hantera enkäter';
  allaEnkater: Enkat[] = [];  
  displayedColumns = ['namn', 'verksamhetsomrade', 'uppdrag', 'antalFragor', 'visa', 'redigera'];
  dataSource!: MatTableDataSource<Enkat>;

  constructor(private router: Router, private enkatService : EnkatService) {
 
  }

  ngAfterViewInit() {

  }

  ngOnInit(): void {
    this.enkatService.getAll().subscribe((data: Enkat[])=>{
      this.allaEnkater = data;
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    }); 
  }

  onClickRedigeraEnkat(enkat: Enkat) {
    this.router.navigate(['redigera-enkat', {namn: enkat.id}]);
  }

  onClickVisaEnkat(enkat: Enkat) {
    this.router.navigate(['/visa-enkat/', enkat.id]);
  }

  onClickNyEnkat() {
    this.router.navigate(['/skapa-enkat']);
  }
}
