import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedigeraVerksamhetsomradeComponent } from './redigera-verksamhetsomrade.component';

describe('RedigeraVerksamhetsomradeComponent', () => {
  let component: RedigeraVerksamhetsomradeComponent;
  let fixture: ComponentFixture<RedigeraVerksamhetsomradeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedigeraVerksamhetsomradeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedigeraVerksamhetsomradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
