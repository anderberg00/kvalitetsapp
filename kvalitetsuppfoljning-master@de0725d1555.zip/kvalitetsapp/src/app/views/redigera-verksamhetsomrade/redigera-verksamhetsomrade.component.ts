import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

@Component({
  selector: 'app-redigera-verksamhetsomrade',
  templateUrl: './redigera-verksamhetsomrade.component.html',
  styleUrls: ['./redigera-verksamhetsomrade.component.scss']
})
export class RedigeraVerksamhetsomradeComponent implements OnInit {
  title: string = "Redigera verksamhetsområde";
  verksamhetsomradeAttVisa: Verksamhetsomrade = {
    namn: "",
    information: [],
  }
  userForm!: FormGroup;

  constructor(private router: Router, private verksamhetsomradeService : VerksamhetsomradeService, private fb: FormBuilder, private route : ActivatedRoute) { 
    this.userForm = this.fb.group({
      regAttribut: ['', Validators.required],
      regVisaForHandlaggare: ['', Validators.required],
      regKolumnExcel: ['', Validators.required]
    })

    this.getVerksamhetsomrade(this.route.snapshot.params.namn);
    this.title = "Redigera verksamhetsområde " + this.verksamhetsomradeAttVisa.namn;
  } 

  ngOnInit(): void {
  }

  getVerksamhetsomrade(namn: string): void {
    this.verksamhetsomradeService.get(namn)
      .subscribe(
        data => {
          this.verksamhetsomradeAttVisa = data;
        });
  }

  onClickTillbaka() {
    this.router.navigate(['hantera-processer']);
  }

  onClickAdd(data: any) {
    let visaHandlaggare = true;

    if (data.regVisaForHandlaggare === 'Ja') {
      visaHandlaggare = true;
    } else {
      visaHandlaggare = false;
    }

    let nyInformation = {key: data.regAttribut, visaHandlaggare: visaHandlaggare, kolumnExcel: data.regKolumnExcel}

    this.verksamhetsomradeAttVisa.information.push(nyInformation);
    this.verksamhetsomradeService.update(this.verksamhetsomradeAttVisa.namn, this.verksamhetsomradeAttVisa).subscribe();
    this.userForm.reset();
  }

  onClickReset() {
    this.userForm.reset();
  }

  onClickRemove(obj: {key: string, visaHandlaggare: boolean, kolumnExcel: string}) {
    for (let i = 0; i < this.verksamhetsomradeAttVisa.information.length; i++) {
      if (this.verksamhetsomradeAttVisa.information[i] === obj) {
        this.verksamhetsomradeAttVisa.information.splice(i, 1);
      }
    }

    let nyInfo = this.verksamhetsomradeAttVisa.information;
    this.verksamhetsomradeService.update(this.verksamhetsomradeAttVisa.namn, this.verksamhetsomradeAttVisa).subscribe();
  }

}
