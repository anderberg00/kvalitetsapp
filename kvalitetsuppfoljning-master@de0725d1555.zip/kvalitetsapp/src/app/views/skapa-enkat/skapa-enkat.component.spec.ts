import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SkapaEnkatComponent } from './skapa-enkat.component';

describe('SkapaEnkatComponent', () => {
  let component: SkapaEnkatComponent;
  let fixture: ComponentFixture<SkapaEnkatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SkapaEnkatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SkapaEnkatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
