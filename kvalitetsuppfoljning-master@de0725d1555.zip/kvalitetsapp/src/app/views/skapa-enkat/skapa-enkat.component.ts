import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RadiobuttonQuestion } from 'src/app/questionnaire/question-radiobutton';
import { DropdownQuestion } from 'src/app/questionnaire/question-dropdown';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TextboxQuestion } from 'src/app/questionnaire/question-textbox';
import { Router } from '@angular/router';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { Kvalitetsmatt } from 'src/app/models/kvalitetsmatt.model';
import { KvalitetsmattService } from 'src/app/services/kvalitetsmatt.service';
import { EnkatService } from 'src/app/services/enkat.service';

@Component({
  selector: 'app-skapa-enkat',
  templateUrl: './skapa-enkat.component.html',
  styleUrls: ['./skapa-enkat.component.scss'],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: {showError: true}
  }]
})

export class SkapaEnkatComponent {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  displayedColumns = ['order', 'label', 'controlType', 'visa', 'radera'];
  dataSource!: MatTableDataSource<QuestionBase<any>>;

  title: string = "Skapa enkät";
  allaUppdrag: Uppdrag[] = [];
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaKvalitetsmatt: Kvalitetsmatt [] = [];

  valtVerksamhetsomrade!: Verksamhetsomrade | any;
  valtUppdrag!: Uppdrag | any;
  valdFragetyp!: string;

  allaSvarsalternativRadio: {value: string, customValue: boolean}[] = [];
  allaSvarsalternativDropDown: string[] = [];
  allaAdditionalTextbox: string[] = [];
  allaFragor: QuestionBase<any>[] = [];

  visaEnskildFraga: boolean = false;
  fragaAttVisa: QuestionBase<any> = new QuestionBase<any>({});

  formData!: FormGroup;
  questionForm!: FormGroup;

  keyCounter: number = 1;
  additionalTextBoxCounter = 1;

  constructor(private enkatService: EnkatService, private kvalitetsmattService : KvalitetsmattService, private router: Router, private snackBar: MatSnackBar,
     private fb: FormBuilder, private uppdragService: UppdragService, private verksamhetsomradeService: VerksamhetsomradeService) {    
    this.formData = this.fb.group({
      regEnkatNamn: ['', Validators.required],
      regUppdrag: ['', Validators.required],
      regVerksamhetsomrade: ['', Validators.required],
    })

    this.questionForm = this.fb.group({
      regControlType: ['', Validators.required],
      regKvalitetsmatt: ['', Validators.required],
      regOrder:['', Validators.required],
      regLabel: ['', Validators.required],
      regInformation: [''],
      regRequired: [''],
      regSvarsalternativRadio: [''],
      regCustomValue: [''],
      regSvarsalternativDropDown: [''],
      regAdditionalTextbox: [''],
    })

    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.kvalitetsmattService.getAll().subscribe((data: Kvalitetsmatt[])=>{
      this.allaKvalitetsmatt = data;
    });
  }

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource(this.allaFragor);
  }

  onClickRegistreraEnkat(data : any) {
    this.openSnackBar("Din enkät har registrerats!", "Stäng");
    this.keyCounter = 1;
    this.additionalTextBoxCounter = 1;

    const sendData = {
      enkatNamn: data.regEnkatNamn,
      uppdragNamn: this.valtUppdrag.namn,
      verksamhetsomradeNamn: this.valtVerksamhetsomrade.namn,
      questionBase: JSON.parse(JSON.stringify(this.allaFragor))
    }
    
    this.enkatService.add(sendData).subscribe();

    //Reset 
    this.questionForm.reset();
    this.allaFragor = [];
    this.formData.reset();
    this.valdFragetyp == null;
    this.valtUppdrag == null;
    this.valtVerksamhetsomrade == null;
    this.allaSvarsalternativRadio = []; 
    this.allaSvarsalternativDropDown = [];
    this.allaAdditionalTextbox = [];
  }

  onClickRegistreraFraga(data : any) {    
    if (this.valdFragetyp == 'Radioknappsfråga') {

      let options: {key: string, value: string, customValue: boolean}[] = [];
      for (let i = 0; i < this.allaSvarsalternativRadio.length; i++) {
        options.push({key: this.allaSvarsalternativRadio[i].value, value: this.allaSvarsalternativRadio[i].value, customValue: this.allaSvarsalternativRadio[i].customValue})
      }

      let additionalTextbox: {key: string, value: string}[] = [];
      for (let i = 0; i < this.allaAdditionalTextbox.length; i++) {
        additionalTextbox.push({key: this.allaAdditionalTextbox[i], value: ""})
        this.additionalTextBoxCounter++;
      }
      
      var tempKey = "id" + this.keyCounter.toString();
      console.log(data.regRequired);
      this.allaFragor.push(new RadiobuttonQuestion({
        key: tempKey,
        label: data.regLabel,
        kvalitetsmatt: data.regKvalitetsmatt,
        order: data.regOrder,
        options: options,
        information: data.regInformation,
        required: data.regRequired,
        additionalTextbox: additionalTextbox,
      }));

      this.questionForm.reset();
      this.dataSource = new MatTableDataSource(this.allaFragor);
      this.allaSvarsalternativDropDown = [];
      this.allaSvarsalternativRadio = [];
      this.allaAdditionalTextbox = [];
      this.ngAfterViewInit();
      this.keyCounter++;
    } else if (this.valdFragetyp == 'Dropdown-fråga') {

      let options: {key: string, value: string, customValue: boolean}[] = [];
      for (let i = 0; i < this.allaSvarsalternativDropDown.length; i++) {
        options.push({key: this.allaSvarsalternativDropDown[i], value: this.allaSvarsalternativDropDown[i], customValue: false});
      }

      let additionalTextbox: {key: string, value: string}[] = [];
      for (let i = 0; i < this.allaAdditionalTextbox.length; i++) {
        additionalTextbox.push({key: this.allaAdditionalTextbox[i], value: ""})
        this.additionalTextBoxCounter++;
      }

      let kvalitetsmatt = this.allaKvalitetsmatt.find(p => p.namn === data.regKvalitetsmatt)
      var tempKey = "id" + this.keyCounter.toString();

      this.allaFragor.push(new DropdownQuestion({
        key: tempKey,
        label: data.regLabel,
        order: data.regOrder,
        kvalitetsmatt: kvalitetsmatt,
        options: options,
        required: data.regRequired,
        information: data.regInformation,
        additionalTextbox: additionalTextbox,
      }));
      this.questionForm.reset();
      this.dataSource = new MatTableDataSource(this.allaFragor);
      this.ngAfterViewInit();
      this.keyCounter++;
    } else if (this.valdFragetyp == 'Textboxfråga'){

      let additionalTextbox: {key: string, value: string}[] = [];
      for (let i = 0; i < this.allaAdditionalTextbox.length; i++) {
        additionalTextbox.push({key: this.allaAdditionalTextbox[i], value: ""})
        this.additionalTextBoxCounter++;
      }

      let kvalitetsmatt = this.allaKvalitetsmatt.find(p => p.namn === data.regKvalitetsmatt);
      var tempKey = "id" + this.keyCounter.toString();

      this.allaFragor.push(new TextboxQuestion({
        key: tempKey,
        label: data.regLabel,
        kvalitetsmatt: kvalitetsmatt,
        order: data.regOrder,
        required: data.regRequired,
        information: data.regInformation,
        additionalTextbox: additionalTextbox,
      }))
      this.questionForm.reset();
      this.dataSource = new MatTableDataSource(this.allaFragor);
      this.ngAfterViewInit();
      this.keyCounter++;
    } else {
      this.openSnackBar("Du har inte valt frågetyp", "Stäng");
    }
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  onClickControlType(event : any) {
    this.valdFragetyp = event.target.value;
  }

  onClickAddSvarsalternativRadio(data : any) {
    const svarsalternativ = data.regSvarsalternativRadio;
    let customValue = false;
    if (data.regCustomValue == "Ja") {
      customValue = true;
    } 
    this.allaSvarsalternativRadio.push({value: svarsalternativ, customValue: customValue});
  }

  onClickAddSvarsalternativDropDown(data : any) {
    const svarsalternativ = data.regSvarsalternativDropDown;
    this.allaSvarsalternativDropDown.push(svarsalternativ);
  }

  onClickAddAdditionalTextbox(data : any) {
    const rubrik = data.regAdditionalTextbox;
    this.allaAdditionalTextbox.push(rubrik);
  }

  onClickDeleteAdditionalTextbox(rubrik : String) {
    for(let i = 0; i < this.allaAdditionalTextbox.length; i++){ 
      if (this.allaAdditionalTextbox[i] === rubrik) { 
        this.allaAdditionalTextbox.splice(i, 1); 
        break;
      }
    }
  }

  onClickDeleteSvarsalternativRadio(svarsalternativ : {value: string, customValue: boolean}) {
    for(let i = 0; i < this.allaSvarsalternativRadio.length; i++){ 
      if (this.allaSvarsalternativRadio[i] === svarsalternativ) { 
        this.allaSvarsalternativRadio.splice(i, 1); 
        break;
      }
    }
  }

  onClickDeleteSvarsalternativDropDown(svarsalternativ: String) {
    for(let i = 0; i < this.allaSvarsalternativDropDown.length; i++){ 
      if (this.allaSvarsalternativDropDown[i] === svarsalternativ) { 
        this.allaSvarsalternativDropDown.splice(i, 1); 
        break;
      }
    }
  }

  onClickTillbaka() {
    this.router.navigate(['hantera-enkater']);
  }
 
  changeVerksamhetsomrade(event : any) {
    this.valtVerksamhetsomrade = this.allaVerksamhetsomraden.find(p => p.namn === event.target.value);
  }

  changeUppdrag(event : any) {
    this.valtUppdrag = this.allaUppdrag.find(p => p.namn === event.target.value);
  }

  onClickResetQuestionForm() {
    this.questionForm.reset();
    this.formData.reset();
  }

  onClickVisaFraga(fraga: QuestionBase<any>) {
    this.visaEnskildFraga = true;
    this.fragaAttVisa = fraga;
  }

  onClickTillbakaVisaFraga() {
    this.visaEnskildFraga = false;
  }

  onClickDeleteFraga(fraga: QuestionBase<any>) {
    for(let i = 0; i < this.allaFragor.length; i++) {
      if (this.allaFragor[i] === fraga) { 
        this.allaFragor.splice(i, 1); 
        this.dataSource = new MatTableDataSource(this.allaFragor);
        this.ngAfterViewInit();
        break;
      }
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}