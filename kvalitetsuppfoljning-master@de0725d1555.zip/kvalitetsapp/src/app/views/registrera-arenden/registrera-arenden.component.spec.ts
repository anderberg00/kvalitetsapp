import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistreraArendenComponent } from './registrera-arenden.component';

describe('RegistreraArendenComponent', () => {
  let component: RegistreraArendenComponent;
  let fixture: ComponentFixture<RegistreraArendenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistreraArendenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistreraArendenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
