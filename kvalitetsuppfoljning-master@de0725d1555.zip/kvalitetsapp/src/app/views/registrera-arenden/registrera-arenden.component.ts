import { Component, ViewEncapsulation, Input, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as XLSX from 'xlsx';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { Arende } from 'src/app/models/arende.model';
import { ArendeService } from 'src/app/services/arende.service';
import { UUID } from 'angular2-uuid';
import { EnkatService } from 'src/app/services/enkat.service';
import { Enkat } from 'src/app/models/enkat.model';

@Component({
  selector: 'app-registrera-arenden',
  templateUrl: './registrera-arenden.component.html',
  styleUrls: ['./registrera-arenden.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class RegistreraArendenComponent implements OnInit {
  title: string = "Registrera ärenden";
  regForm!: FormGroup;
  regArende!: FormGroup;
  regFleraArenden!: FormGroup;
  allaUppdrag: Uppdrag[] = [];
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaEnkater: Enkat[] = [];
  aktuellaEnkater: Enkat[] = [];
  harValtEnkat: boolean = false;

  valtVerksamhetsomrade!: Verksamhetsomrade;
  valtUppdrag!: Uppdrag;

  data!: string [][];
  hasUploadedFile!: boolean;
  fileName!: string;

  constructor(private enkatService: EnkatService, private snackBar : MatSnackBar, private fb: FormBuilder, private uppdragService: UppdragService,
     private verksamhetsomradeService: VerksamhetsomradeService, private arendeService: ArendeService) { 
    
      this.regForm = this.fb.group({
      verksamhetsomrade: ['', [Validators.required]],
      uppdrag: ['', [Validators.required]]
    })

    this.regArende = this.fb.group({
      regAr: ['', Validators.required],
      regKontor: ['', Validators.required],
      regSlutdatum: ['', Validators.required],
      regNotifieringsdatum: ['', Validators.required],
      regHandlaggareNotifiering: ['', Validators.required],
      regForstaHandlaggare:['', Validators.required],
      regAndraHandlaggare:[''],
      regEnkat:[''],
    })

    this.regFleraArenden = this.fb.group({
      regEnkatFleraArenden:['']
    })
    
    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.enkatService.getAll().subscribe((data: Enkat[])=>{
      this.allaEnkater = data;
    });
    
  }

  ngOnInit(): void {

  }

  changeEnkat() {
    this.harValtEnkat = true;
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  changeVerksamhetsomrade(event: any) {
    //Vi redan har valt verksamhetsområde en gång
    if (this.valtVerksamhetsomrade != null) {
      for(let k = 0; k < this.valtVerksamhetsomrade.information.length; k++) {
        this.regArende.removeControl(this.valtVerksamhetsomrade.information[k].key);
      }
    }

    for(let i = 0; i < this.allaVerksamhetsomraden.length; i++) {
      if (this.allaVerksamhetsomraden[i].namn === event.target.value) {
        this.valtVerksamhetsomrade = this.allaVerksamhetsomraden[i];
        break;
      }
    }

    for(let j = 0; j < this.valtVerksamhetsomrade.information.length; j++) {
      this.regArende.addControl(this.valtVerksamhetsomrade.information[j].key, this.fb.control('', [Validators.required]));
    }

    if (this.valtVerksamhetsomrade != null && this.valtUppdrag != null) {
      this.hittaAktuellaEnkater();
    }
  }

  changeUppdrag(event: any) {
    for(let i = 0; i < this.allaUppdrag.length; i++) {
      if (this.allaUppdrag[i].namn === event.target.value) {
        this.valtUppdrag = this.allaUppdrag[i];
        break;
      }
    }

    if (this.valtVerksamhetsomrade != null && this.valtUppdrag != null) {
      this.hittaAktuellaEnkater();
    }
  }

  hittaAktuellaEnkater() {
    this.allaEnkater.forEach(p => {
      if (p.uppdrag.namn == this.valtUppdrag.namn && p.verksamhetsomrade.namn == this.valtVerksamhetsomrade.namn) {
          this.aktuellaEnkater.push(p);
      }
    })
  }

  receiveData($event: any) {
    this.data = $event 
    this.hasUploadedFile = true;
  }

  skapaFleraArenden(post : any) {
    for(let i = 1; i < this.data.length; i++) {
      let varden = [];
      for (let j = 0; j < this.valtVerksamhetsomrade.information.length; j++) {
        let kolumnExcelInt = parseInt(this.valtVerksamhetsomrade.information[j].kolumnExcel);
        varden.push({key: this.valtVerksamhetsomrade.information[j].key, value: this.data[i][kolumnExcelInt-1]});
      }
      
      this.openSnackBar("Ärendena har registrerats!", "Stäng");
      let status = this.setStatus(this.data[i][0], this.data[i][1], this.data[i][2], this.data[i][3], this.data[i][4], this.data[i][5]);
      //Skicka ärendet till databasen
      const postData = {
        id: UUID.UUID(),
        ar: this.data[i][0],
        kontor: this.data[i][1],
        slutdatum: this.data[i][2],
        notifieringsdatum: this.data[i][3],
        handlaggareNotifiering: this.data[i][4],
        forstaHandlaggare: this.data[i][5],
        andraHandlaggare: this.data[i][6],
        status: status,
        enkatNamn: post.regEnkatFleraArenden,
        verksamhetsomradeNamn: this.valtVerksamhetsomrade.namn,
        uppdragNamn: this.valtUppdrag.namn,
        varden : varden,
        arGranskad: false,
      };

      this.arendeService.add(postData).subscribe();
    }
    this.onClickReset();
  }

  setStatus(ar: string, kontor: string, slutdatum: string, notifieringsdatum: string, handlaggareNotifiering: string, forstaHandlaggare: string) : string {
    if ((ar == "" || null) || (kontor == "" || null) || (slutdatum == "" || null)|| (notifieringsdatum == "" || null)|| (handlaggareNotifiering == "" || null)) {
      return "Saknar information";
    } else {
      return "Klar för granskning";
    }
  }

  skapaEttArende(data : any) {
    let varden: {key: string, value: string} [] = [];
    for (let i = 0; i < this.valtVerksamhetsomrade.information.length; i++) {
      varden.push({ key: this.valtVerksamhetsomrade.information[i].key, value: (<HTMLInputElement>document.getElementById(this.valtVerksamhetsomrade.information[i].key)).value});
    }
    this.openSnackBar("Ärendet har registrerats!", "Stäng");  
    let status = this.setStatus(data.regAr, data.regKontor, data.regSlutdatum, data.regNotifieringsdatum, data.regHandlaggareNotifiering, data.regForstaHandlaggare)

    const postData = {
      id: UUID.UUID(),
      ar: data.regAr,
      kontor: data.regKontor,
      slutdatum: data.regSlutdatum,
      notifieringsdatum: data.regNotifieringsdatum,
      handlaggareNotifiering: data.regHandlaggareNotifiering,
      forstaHandlaggare: data.regForstaHandlaggare,
      andraHandlaggare: data.regAndraHandlaggare,
      status: status,
      enkatNamn: data.regEnkat,
      verksamhetsomradeNamn: this.valtVerksamhetsomrade.namn,
      uppdragNamn: this.valtUppdrag.namn,
      varden : varden,
      arGranskad: false, 
    };

    console.log(postData);
    //Skicka ärendet till databasen
    this.arendeService.add(postData).subscribe();
    
    this.onClickReset();
  }

  onFileChange(event : any) {    
    const target : DataTransfer = <DataTransfer>(event.target);

    if(target.files.length!==1) throw new Error('Cannot use multiple files');

    const reader: FileReader = new FileReader();
    this.fileName = event.target.files[0].name;

    reader.onload = (e: any) => {
      const bString: string = e.target.result;
      const workbook: XLSX.WorkBook = XLSX.read(bString, { type: 'binary'});
      const worksheetName: string = workbook.SheetNames[0];
      const worksheet: XLSX.WorkSheet = workbook.Sheets[worksheetName];
      this.data = (XLSX.utils.sheet_to_json(worksheet, { header: 1}));
    }
    reader.readAsBinaryString(target.files[0]);
    this.hasUploadedFile = true;
  }

  onClickReset() {
    this.regForm.reset();
    this.regArende.reset();
    this.regFleraArenden.reset();
    this.valtVerksamhetsomrade == null;
    this.valtUppdrag == null;
  }


}
