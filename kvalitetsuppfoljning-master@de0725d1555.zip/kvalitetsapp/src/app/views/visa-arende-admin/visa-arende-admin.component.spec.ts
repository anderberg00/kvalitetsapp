import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaArendeAdminComponent } from './visa-arende-admin.component';

describe('VisaArendeAdminComponent', () => {
  let component: VisaArendeAdminComponent;
  let fixture: ComponentFixture<VisaArendeAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisaArendeAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaArendeAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
