import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Arende } from 'src/app/models/arende.model';
import { Enkat } from 'src/app/models/enkat.model';
import { Enkatsvar } from 'src/app/models/enkatsvar.model';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { ArendeService } from 'src/app/services/arende.service';

@Component({
  selector: 'app-visa-arende-admin',
  templateUrl: './visa-arende-admin.component.html',
  styleUrls: ['./visa-arende-admin.component.scss']
})
export class VisaArendeAdminComponent implements OnInit {
  title: string = "Ärende";
  granskningsnummer!: string | undefined;
  allaArenden: Arende[] = [];
  arendeAttVisa!: Arende;
  allaFragor: QuestionBase<any>[] = [];
  
  constructor(private router: Router, private route: ActivatedRoute, private arendeService: ArendeService) { 
    this.getArende(this.route.snapshot.params.granskningsnummer);
  } 

  ngOnInit(): void {
  }

  getArende(id: string): void {
    this.arendeService.get(id)
      .subscribe(
        data => {
          this.arendeAttVisa = data;
          this.allaFragor = this.arendeAttVisa.enkat.questionBases;
        });
  }

  onClickRedigera() {
    this.router.navigate(['/redigera-arende', this.arendeAttVisa.id]);
  }

  onClickBegarOmgranskning() {
    
    const postData = {
      id: this.arendeAttVisa.id,
      ar: this.arendeAttVisa.ar,
      kontor: this.arendeAttVisa.kontor,
      slutdatum: this.arendeAttVisa.slutdatum,
      notifieringsdatum: this.arendeAttVisa.notifieringsdatum,
      handlaggareNotifiering: this.arendeAttVisa.handlaggareNotifiering,
      forstaHandlaggare: this.arendeAttVisa.forstaHandlaggare,
      andraHandlaggare: this.arendeAttVisa.andraHandlaggare,
      status: "Omgranskning",
      enkatNamn: this.arendeAttVisa.enkat.id,
      verksamhetsomradeNamn: this.arendeAttVisa.verksamhetsomrade.namn,
      uppdragNamn: this.arendeAttVisa.uppdrag.namn,
      varden : this.arendeAttVisa.varden,
      arGranskad: false, 
    };

    this.arendeService.update(this.arendeAttVisa.id, postData).subscribe();
    this.router.navigate(['hantera-arenden']);
  }

  onClickTillbaka() {
    this.router.navigate(['hantera-arenden']);
  }

}
