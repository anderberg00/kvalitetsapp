import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaEnkatsvarAdminComponent } from './visa-enkatsvar-admin.component';

describe('VisaEnkatsvarAdminComponent', () => {
  let component: VisaEnkatsvarAdminComponent;
  let fixture: ComponentFixture<VisaEnkatsvarAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisaEnkatsvarAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaEnkatsvarAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
