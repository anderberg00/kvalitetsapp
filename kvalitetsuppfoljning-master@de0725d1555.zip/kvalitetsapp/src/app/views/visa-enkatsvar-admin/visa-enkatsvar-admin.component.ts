import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuestionBase } from 'src/app/questionnaire/question-base';

@Component({
  selector: 'app-visa-enkatsvar-admin',
  templateUrl: './visa-enkatsvar-admin.component.html',
  styleUrls: ['./visa-enkatsvar-admin.component.scss']
})
export class VisaEnkatsvarAdminComponent implements OnInit {
  title: string = "Enkätsvar";
  allaFragor: QuestionBase<any>[] = [];

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  onClickBack() {
    this.router.navigate(['statistics']);
  }

}
