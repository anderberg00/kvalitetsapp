import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Arende } from 'src/app/models/arende.model';
import { Enkat } from 'src/app/models/enkat.model';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { ArendeService } from 'src/app/services/arende.service';
import { EnkatService } from 'src/app/services/enkat.service';
import { QuestionService } from 'src/app/services/question.service';

@Component({
  selector: 'app-visa-arende',
  templateUrl: './visa-arende.component.html',
  styleUrls: ['./visa-arende.component.scss']
})
export class VisaArendeComponent implements OnInit {
  title: string = "Ärende";
  arendeAttVisa!: Arende;
  allaArenden!: Arende[];
  attributAttVisa: {key: string, value: string} [] = [];

  constructor(private http: HttpClient, private router: Router, private qService: QuestionService, private route: ActivatedRoute, private arendeService: ArendeService, private enkatService : EnkatService) { 
    

  }

  ngOnInit(): void {
    this.getArende(this.route.snapshot.params.granskningsnummer);
  }

  getArende(id: string): void {
    this.arendeService.get(id)
      .subscribe(
        (data: Arende) => {
          this.arendeAttVisa = data;

          for(let i = 0; i < this.arendeAttVisa.verksamhetsomrade.information.length; i++) {
            if (this.arendeAttVisa.verksamhetsomrade.information[i].visaHandlaggare) {
              let value = this.hittaVardeAvAttribut(this.arendeAttVisa.verksamhetsomrade.information[i].key, this.arendeAttVisa);
              this.attributAttVisa.push({key: this.arendeAttVisa.verksamhetsomrade.information[i].key, value: value})
            }
          }
      });
  }

  hittaVardeAvAttribut(key: string, arende: Arende) : string {
    for (let i = 0; i < arende.varden.length; i++) {
      if (arende.varden[i].key == key) {
        return arende.varden[i].value;
      }
    }
    return '';
  }

  onClickTillbaka() {
    this.router.navigate(['mina-arenden']);
  }

}
