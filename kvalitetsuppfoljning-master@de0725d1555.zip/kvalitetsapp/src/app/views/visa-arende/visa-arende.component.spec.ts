import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaArendeComponent } from './visa-arende.component';

describe('VisaArendeComponent', () => {
  let component: VisaArendeComponent;
  let fixture: ComponentFixture<VisaArendeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisaArendeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaArendeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
