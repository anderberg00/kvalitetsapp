import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UUID } from 'angular2-uuid';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { RekommendationService } from 'src/app/services/rekommendation.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

@Component({
  selector: 'app-rekommendera-arenden',
  templateUrl: './rekommendera-arenden.component.html',
  styleUrls: ['./rekommendera-arenden.component.scss']
})
export class RekommenderaArendenComponent implements OnInit {
  title: String = "Rekommendera ärende";
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  valtVerksamhetsomrade!: Verksamhetsomrade;
  
  regForm!: FormGroup;
  regArende!: FormGroup;

  constructor(private snackBar : MatSnackBar, private rekommendationService: RekommendationService, private verksamhetsomradeService: VerksamhetsomradeService, private fb: FormBuilder) { 
    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.regForm = this.fb.group({
      verksamhetsomrade: ['', [Validators.required]],
      regMotivering: ['', [Validators.required]]
    })
  }

  ngOnInit(): void {
  }

  skapaRekommendation(data : any) {
    let varden: {key: string, value: string} [] = [];
    for (let i = 0; i < this.valtVerksamhetsomrade.information.length; i++) {
      varden.push({ key: this.valtVerksamhetsomrade.information[i].key, value: (<HTMLInputElement>document.getElementById(this.valtVerksamhetsomrade.information[i].key)).value});
    }
    const postData = {
      id: UUID.UUID(),
      inskickadAv:"Handläggare XX",
      verksamhetsomradeNamn: this.valtVerksamhetsomrade.namn,
      motivering: data.regMotivering,
      varden: varden,
    }
    this.rekommendationService.add(postData).subscribe();
    this.onClickReset();
    this.openSnackBar("Rekommendationen har registrerats!", "Stäng");  
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  onClickReset() {
    this.valtVerksamhetsomrade == null;
    this.regForm.reset();
  }

  changeVerksamhetsomrade(event: any) {
    //Vi redan har valt verksamhetsområde en gång
    if (this.valtVerksamhetsomrade != null) {
      for(let k = 0; k < this.valtVerksamhetsomrade.information.length; k++) {
        this.regForm.removeControl(this.valtVerksamhetsomrade.information[k].key);
      }
    }

    for(let i = 0; i < this.allaVerksamhetsomraden.length; i++) {
      if (this.allaVerksamhetsomraden[i].namn === event.target.value) {
        this.valtVerksamhetsomrade = this.allaVerksamhetsomraden[i];
        break;
      }
    }

    for(let j = 0; j < this.valtVerksamhetsomrade.information.length; j++) {
      this.regForm.addControl(this.valtVerksamhetsomrade.information[j].key, this.fb.control(''));
    }
  }

}
