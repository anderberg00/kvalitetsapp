import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RekommenderaArendenComponent } from './rekommendera-arenden.component';

describe('RekommenderaArendenComponent', () => {
  let component: RekommenderaArendenComponent;
  let fixture: ComponentFixture<RekommenderaArendenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RekommenderaArendenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RekommenderaArendenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
