import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Arende } from 'src/app/models/arende.model';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { ArendeService } from 'src/app/services/arende.service';

@Component({
  selector: 'app-visa-enkatsvar',
  templateUrl: './visa-enkatsvar.component.html',
  styleUrls: ['./visa-enkatsvar.component.scss']
})
export class VisaEnkatsvarComponent implements OnInit {
  title: string = "Enkätsvar"
  arendeAttVisa!: Arende;
  allaFragor: QuestionBase<any>[] = [];

  constructor(private router: Router, private route: ActivatedRoute, private arendeService: ArendeService) { }

  ngOnInit(): void {
    this.getArende(this.route.snapshot.params.granskningsnummer);
  }

  getArende(id: string) {
    this.arendeService.get(id).subscribe((data: Arende) => {
      this.arendeAttVisa = data;
      this.allaFragor = this.arendeAttVisa.enkat.questionBases;
      console.log(this.allaFragor);
    });
  }

  onClickBackMinaArenden() {
    this.router.navigate(['mina-arenden']);
  }
}
