import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaEnkatsvarComponent } from './visa-enkatsvar.component';

describe('VisaEnkatsvarComponent', () => {
  let component: VisaEnkatsvarComponent;
  let fixture: ComponentFixture<VisaEnkatsvarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisaEnkatsvarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaEnkatsvarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
