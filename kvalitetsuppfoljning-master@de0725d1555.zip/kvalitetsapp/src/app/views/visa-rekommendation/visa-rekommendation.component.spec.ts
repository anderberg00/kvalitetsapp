import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaRekommendationComponent } from './visa-rekommendation.component';

describe('VisaRekommendationComponent', () => {
  let component: VisaRekommendationComponent;
  let fixture: ComponentFixture<VisaRekommendationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisaRekommendationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaRekommendationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
