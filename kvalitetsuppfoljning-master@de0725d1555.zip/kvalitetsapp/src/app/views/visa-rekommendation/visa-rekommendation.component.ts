import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Rekommendation } from 'src/app/models/rekommendation.model';
import { RekommendationService } from 'src/app/services/rekommendation.service';

@Component({
  selector: 'app-visa-rekommendation',
  templateUrl: './visa-rekommendation.component.html',
  styleUrls: ['./visa-rekommendation.component.scss']
})
export class VisaRekommendationComponent implements OnInit {
  title: String = "Rekommendation";
  rekommendationAttVisa!: any;
  allaRekommendationer: Rekommendation[] = [];

  constructor(private router: Router, private rekommendationService: RekommendationService, private route: ActivatedRoute) {
    this.rekommendationService.getAll().subscribe((data: Rekommendation[])=>{
      this.allaRekommendationer = data;
    });
    this.getRekommendation(this.route.snapshot.params.id);
  }

  ngOnInit(): void {
    
  }

  onClickTillbaka() {
    this.router.navigate(['hantera-rekommendationer']);
  }

  getRekommendation(id: string): void {
      this.rekommendationService.get(id)
    .subscribe(
      (data : Rekommendation) => {
        this.rekommendationAttVisa = data;
      });
  }

}
