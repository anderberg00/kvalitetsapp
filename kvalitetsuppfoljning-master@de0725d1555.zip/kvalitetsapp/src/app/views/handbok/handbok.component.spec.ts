import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HandbokComponent } from './handbok.component';

describe('HandbokComponent', () => {
  let component: HandbokComponent;
  let fixture: ComponentFixture<HandbokComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HandbokComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HandbokComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
