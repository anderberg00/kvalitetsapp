import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-handbok',
  templateUrl: './handbok.component.html',
  styleUrls: ['./handbok.component.scss']
})
export class HandbokComponent implements OnInit {
  title: string = "Handbok"

  constructor() { }

  ngOnInit(): void {
  }

}
