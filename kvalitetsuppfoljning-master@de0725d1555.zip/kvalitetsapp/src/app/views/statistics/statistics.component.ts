import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Chart, LinearScale, registerables } from 'chart.js';
import { Arende } from 'src/app/models/arende.model';
import { Enkat } from 'src/app/models/enkat.model';
import { Enkatsvar } from 'src/app/models/enkatsvar.model';
import { Kvalitetsmatt } from 'src/app/models/kvalitetsmatt.model';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { User } from 'src/app/models/users.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { ArendeService } from 'src/app/services/arende.service';
import { EnkatService } from 'src/app/services/enkat.service';
import { EnkatsvarService } from 'src/app/services/enkatsvar.service';
import { KvalitetsmattService } from 'src/app/services/kvalitetsmatt.service';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { UserService } from 'src/app/services/user.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

Chart.register(...registerables);

export interface SvarOchProcent {
  fragenummer: number,
  svar: string,
  procent: string
}

@Component({
  selector: 'app-statistics',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.scss']
})
export class StatisticsComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  displayedColumns = ['svar', 'granskningsomgang', 'granskningsnummer', 'visa'];
  displayedColumnsPercentage = ['svar2', 'procent'];

  dataSource!: MatTableDataSource<Arende>;
  dataSourcePercentage!: MatTableDataSource<SvarOchProcent>;
  tempSvarOchProcent: SvarOchProcent[] = [];

  title: string = "Enkätsvar";
  allaAr = ['2021', '2020', '2019'];
  allaKontor = ['Kiruna', 'Umeå', 'Sundsvall', 'Stockholm', 'Gävle', 'Linköping', 'Lund', 'Kalmar', 'Visby', 'Göteborg', 'Eskilstuna'];
  svarsLista: Arende[] = [];
  allaFragor: QuestionBase<any>[] = [];
  allaEnkater: Enkat[] = [];
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaUppdrag: Uppdrag[] = [];
  allaKvalitetsmatt: Kvalitetsmatt[] = []; 
  allaUsers: User[] = [];
  allaCharts: Chart[] = [];

  harKlickatSortera: boolean = false;

  valdEnkat!: string;
  valtKontor: string = '';
  valtAr: string = '';
  valtKvalitetsmatt: string = '';
  antalFragor: number[] = [];

  antalFragorSomVisas!: number;

  form!: FormGroup;

  chartData: any[] = [];
  chartOptions: any[] = [];

  constructor(private userService: UserService, private router: Router, private arendeService: ArendeService, private fb: FormBuilder, private uppdragService: UppdragService, private verksamhetsomradeService: VerksamhetsomradeService, private kvalitetsmattService: KvalitetsmattService, private enkatsvarService: EnkatsvarService, private enkatService: EnkatService) {
    this.form = this.fb.group({
      regEnkat: ['', Validators.required],
      regKvalitetsmatt:[''],
      regKontor:[''],
      regAr: [''],
      regTidsperiodFran:[''],
      regTidsperiodTill: [''],
      regHandlaggare: ['']
    });

    this.enkatService.getAll().subscribe((data: Enkat[])=>{
      this.allaEnkater = data;
    });

    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.kvalitetsmattService.getAll().subscribe((data: Kvalitetsmatt[])=>{
      this.allaKvalitetsmatt = data;
    });

    this.userService.getAll().subscribe((data: User[]) => {
      this.allaUsers = data;
    });
  }

  ngOnInit(): void {
    
  }

  onClickSort(data : any) {
    this.chartData = [];
    this.chartOptions = [];
    this.svarsLista = [];
    this.tempSvarOchProcent = [];

    this.getEnkatsvarLista();

    this.valdEnkat = data.regEnkat;
    if (data.regAr != '') {
      this.valtAr = data.regAr;
    } if (data.regKontor != '') {
      this.valtKontor = data.regKontor;
    } if (data.regKvalitetsmatt != '') {
      this.valtKvalitetsmatt = data.regKvalitetsmatt;
    } 
    this.harKlickatSortera = true;
  }

  getEnkatsvarLista() {
    //Vald enkät, sedan sortera på ytterligare eventuellt kontor, år, kvalitetsmått
    this.arendeService.getAll().subscribe((data: Arende[]) => {
      data.forEach(arende => {
        if (arende.arGranskad && arende.enkat.id == this.valdEnkat) {
          this.svarsLista.push(arende);
        }
      });

      if (this.valtKontor != '' && this.valtKontor != "Alla kontor") {
        this.svarsLista = this.svarsLista.filter((arende) => arende.kontor == this.valtKontor);
      } if (this.valtAr != '' && this.valtAr != "Alla år") {
        this.svarsLista = this.svarsLista.filter((arende) => arende.ar == this.valtAr);
      } 

      this.antalFragor = Array(this.svarsLista[0].enkat.questionBases.length).fill(0).map((x, i) => i);
      this.skapaCharts(this.svarsLista);

      if (this.valtKvalitetsmatt == '' || this.valtKvalitetsmatt == 'Alla kvalitetsmått') {
        this.antalFragorSomVisas = this.antalFragor.length;
      } else {
        let number = 0;
        this.svarsLista[0].enkat.questionBases.filter((q)=> {
          if (q.kvalitetsmatt.namn == this.valtKvalitetsmatt) {
            number++;
          }
        });
        this.antalFragorSomVisas = number;
      }

      this.dataSource = new MatTableDataSource(this.svarsLista);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  skapaCharts(svarslista: Arende[]) {

    //Gå igenom varje fråga
    for(let fraga = 0; fraga < svarslista[0].enkat.questionBases.length; fraga++) {
      if (svarslista[0].enkat.questionBases[fraga].controlType === "textbox") {
        this.chartData.push('');
        this.chartOptions.push('')
        const pushdata: SvarOchProcent = {
          fragenummer: fraga,
          svar: '',
          procent: '',
        }
        this.tempSvarOchProcent.push(pushdata);
      } else {
        let fragesvar = [];
        //Gå igenom varje enkät och lägg till svar i frågesvar
        for (let i = 0; i < svarslista.length; i++) {
          fragesvar.push(svarslista[i].enkat.questionBases[fraga]);
        }
        //Få tag på svarsalternativen      
        let labels: string [] = [];
        for (let i = 0; i < svarslista[0].enkat.questionBases[fraga].options.length; i++) {
          labels.push(svarslista[0].enkat.questionBases[fraga].options[i].key)
        }

        let data = Array.apply(null, Array(labels.length)).map(Number.prototype.valueOf,0);

        //Räkna ut antal som svarat ett visst svar
        for (let i = 0; i < fragesvar.length; i++) {
          for (let j = 0; j < labels.length; j++) {
            if (fragesvar[i].value === labels[j]) {
              data[j]++; 
            }
          }
        }

        let options = {
          responsive: true,
          plugins: {
            labels: {
              render: 'percentage',
              fontColor: ['green', 'white', 'red'],
              precision: 2
            },
          },
          legend: { display: false },
          title: {
            display: true,
            text: svarslista[0].enkat.questionBases[fraga].label
          },
          scales: {
              yAxes : [{
                  ticks : {
                      max : Math.round((Math.max.apply(Math, data)*(3/2))),    
                      min : 0,
                      index: 1,
                      type: 'linear',
                      stepSize: 1
                  },
                  index: 1,
              }],
              xAxes: [
                {
                  ticks: {
                    callback: (label: any) => {
                      return label.length > 5 ? label.substr(0, 30): label;
                    },              
                  }
                }
              ]
          }
        };
        
        let chart = {
          labels: labels,
          datasets: [{
            label: svarslista[0].enkat.questionBases[fraga].label,
            data: data,
            backgroundColor: ['#EB6B6D', '#FFE8B1', '#ffd164', '#F8CBCC', '#CFEAEC', '#75c5c9'],
          }],
        }

        this.chartData.push(chart);
        this.chartOptions.push(options);
        
        let svarOchProcent = [];
        //Fyll i svar och procent
        for (let i = 0; i < labels.length; i++) {
          let procent = Math.round(((data[i]/(this.svarsLista.length))*100)).toString();
          const pushdata: SvarOchProcent = {
            fragenummer: fraga,
            svar: labels[i],
            procent: procent,
          }
          this.tempSvarOchProcent.push(pushdata);
        }
      }
    }

    this.dataSourcePercentage = new MatTableDataSource(this.tempSvarOchProcent);
  } 

  onClickVisaArende(arende: Arende) {
    this.router.navigate(['/visa-arende-admin/', arende.id]);  
  }

}

