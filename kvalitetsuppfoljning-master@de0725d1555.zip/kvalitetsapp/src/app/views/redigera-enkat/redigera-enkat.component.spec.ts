import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedigeraEnkatComponent } from './redigera-enkat.component';

describe('RedigeraEnkatComponent', () => {
  let component: RedigeraEnkatComponent;
  let fixture: ComponentFixture<RedigeraEnkatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedigeraEnkatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedigeraEnkatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
