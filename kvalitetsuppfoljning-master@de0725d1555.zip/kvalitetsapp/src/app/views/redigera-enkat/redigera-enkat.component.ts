import { Component, OnInit, ViewChild } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { Enkat } from 'src/app/models/enkat.model';
import { Kvalitetsmatt } from 'src/app/models/kvalitetsmatt.model';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { QuestionBase } from 'src/app/questionnaire/question-base';
import { DropdownQuestion } from 'src/app/questionnaire/question-dropdown';
import { RadiobuttonQuestion } from 'src/app/questionnaire/question-radiobutton';
import { TextboxQuestion } from 'src/app/questionnaire/question-textbox';
import { EnkatService } from 'src/app/services/enkat.service';
import { KvalitetsmattService } from 'src/app/services/kvalitetsmatt.service';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

@Component({
  selector: 'app-redigera-enkat',
  templateUrl: './redigera-enkat.component.html',
  styleUrls: ['./redigera-enkat.component.scss']
})
export class RedigeraEnkatComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  displayedColumns = ['order', 'label', 'controlType', 'visa', 'radera'];
  dataSource!: MatTableDataSource<QuestionBase<any>>;
  title: string = "Redigera enkät";

  formData!: FormGroup;
  questionForm!: FormGroup;

  allaUppdrag: Uppdrag[] = [];
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaKvalitetsmatt: Kvalitetsmatt[] = [];

  enkatAttVisa!: Enkat | any;
  allaEnkater!: Enkat[];

  valtVerksamhetsomrade!: Verksamhetsomrade | any;
  valtUppdrag!: Uppdrag | any;
  valdFragetyp!: string | any;
  allaFragor: QuestionBase<any>[] = [];

  allaSvarsalternativRadio: {value: string, customValue: boolean}[] = [];
  allaSvarsalternativDropDown: string[] = [];
  allaAdditionalTextbox: string[] = [];

  visaEnskildFraga: boolean = false;
  fragaAttVisa: QuestionBase<any> = new QuestionBase<any>({});; 

  constructor(private kvalitetsmattService: KvalitetsmattService, private snackBar: MatSnackBar, private enkatService : EnkatService, private route: ActivatedRoute, private fb : FormBuilder, private uppdragService: UppdragService, private verksamhetsomradeService: VerksamhetsomradeService) { 
    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.kvalitetsmattService.getAll().subscribe((data: Kvalitetsmatt[])=>{
      this.allaKvalitetsmatt = data;
    });
    
    this.formData = this.fb.group({
      regEnkatNamn: ['', Validators.required],
      regUppdrag: ['', Validators.required],
      regVerksamhetsomrade: ['', Validators.required],
    })

    this.questionForm = this.fb.group({
      regControlType: ['', Validators.required],
      regKvalitetsmatt: ['', Validators.required],
      regKey: ['', Validators.required],
      regOrder: ['', Validators.required],
      regLabel: ['', Validators.required],
      regInformation: [''],
      regRequired: [''],
      regSvarsalternativRadio: [''],
      regCustomValue: [''],
      regSvarsalternativDropDown: [''],
      regAdditionalTextbox: [''],
    })
  }

  ngOnInit(): void {
    this.getEnkat(this.route.snapshot.params.namn);
    this.dataSource = new MatTableDataSource(this.allaFragor);
  }

  getEnkat(id: string): void {
    this.enkatService.get(id)
      .subscribe(
        (data: Enkat) => {
          this.enkatAttVisa = data;
          console.log(this.enkatAttVisa)
          this.title = "Enkät " + this.enkatAttVisa.id;
          this.allaFragor = this.enkatAttVisa.questionBases;
      });
  }

  onClickRegistreraEnkat(data : any) {
    this.openSnackBar("Din enkät har registrerats!", "Stäng");
    //Skicka ec till databas! 

    const sendData = {
      enkatNamn: data.regEnkatNamn,
      uppdragNamn: this.valtUppdrag.namn,
      verksamhetsomradeNamn: this.valtVerksamhetsomrade.namn,
      questionBase: JSON.parse(JSON.stringify(this.allaFragor))
    }
    
    this.enkatService.add(sendData).subscribe();

    //Reset 
    this.questionForm.reset();
    this.allaFragor = [];
    this.formData.reset();
    this.valdFragetyp == null;
    this.valtUppdrag == null;
    this.valtVerksamhetsomrade == null;
    this.allaSvarsalternativRadio = []; 
    this.allaSvarsalternativDropDown = [];
    this.allaAdditionalTextbox = [];
  }

  onClickRegistreraFraga(data : any) {    
    if (this.valdFragetyp == 'Radioknappsfråga') {

      let options: {key: string, value: string, customValue: boolean, valueOfCustomValue: string}[] = [];
      for (let i = 0; i < this.allaSvarsalternativRadio.length; i++) {
        options.push({key: 'answer'+i, value: this.allaSvarsalternativRadio[i].value, customValue: this.allaSvarsalternativRadio[i].customValue, valueOfCustomValue: 'customAnswer'+i})
      }

      let additionalTextbox: {key: string, value: string}[] = [];
      for (let i = 0; i < this.allaAdditionalTextbox.length; i++) {
        additionalTextbox.push({key: 'answer'+i, value: this.allaAdditionalTextbox[i]})
      }

      this.allaFragor.push(new RadiobuttonQuestion({
        key: data.regKey,
        label: data.regLabel,
        order: data.regOrder,
        options: options,
        information: data.regInformation,
        required: data.regRequired,
        additionalTextbox: additionalTextbox,
      }));
      this.questionForm.reset();
      this.valdFragetyp = undefined;
      this.dataSource = new MatTableDataSource(this.allaFragor);
      this.ngAfterViewInit();
    } else if (this.valdFragetyp == 'Dropdown-fråga') {

      let options: {key: string, value: string, customValue: boolean, valueOfCustomValue: string}[] = [];
      for (let i = 0; i < this.allaSvarsalternativDropDown.length; i++) {
        options.push({key: 'answer'+i, value: this.allaSvarsalternativDropDown[i], customValue: false, valueOfCustomValue: 'customAnswer'+i})
      }

      let additionalTextbox: {key: string, value: string}[] = [];
      for (let i = 0; i < this.allaAdditionalTextbox.length; i++) {
        additionalTextbox.push({key: 'answer'+i, value: this.allaAdditionalTextbox[i]})
      }

      this.allaFragor.push(new DropdownQuestion({
        key: data.regKey,
        label: data.regLabel,
        order: data.regOrder,
        options: options,
        required: data.regRequired,
        information: data.regInformation,
        additionalTextbox: additionalTextbox,
      }));
      this.questionForm.reset();
      this.valdFragetyp = undefined;
      this.dataSource = new MatTableDataSource(this.allaFragor);
      this.ngAfterViewInit();
    } else if (this.valdFragetyp == 'Textboxfråga'){

      let additionalTextbox: {key: string, value: string}[] = [];
      for (let i = 0; i < this.allaAdditionalTextbox.length; i++) {
        additionalTextbox.push({key: 'answer'+i, value: this.allaAdditionalTextbox[i]})
      }

      this.allaFragor.push(new TextboxQuestion({
        key: data.regKey,
        label: data.regLabel,
        order: data.regOrder,
        required: data.regRequired,
        information: data.regInformation,
        additionalTextbox: additionalTextbox,
      }))
      this.questionForm.reset();
      this.valdFragetyp = undefined;
      this.dataSource = new MatTableDataSource(this.allaFragor);
      this.ngAfterViewInit();
    } else {
      this.openSnackBar("Du har inte valt frågetyp", "Stäng");
    }
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  onClickControlType(event : any) {
    this.valdFragetyp = event.target.value;
  }

  onClickAddSvarsalternativRadio(data : any) {
    const svarsalternativ = data.regSvarsalternativRadio;
    let customValue = false;
    if (data.regCustomValue == "Ja") {
      customValue = true;
    } 
    this.allaSvarsalternativRadio.push({value: svarsalternativ, customValue: customValue});
  }

  onClickAddSvarsalternativDropDown(data : any) {
    const svarsalternativ = data.regSvarsalternativDropDown;
    this.allaSvarsalternativDropDown.push(svarsalternativ);
  }

  onClickAddAdditionalTextbox(data : any) {
    const rubrik = data.regAdditionalTextbox;
    this.allaAdditionalTextbox.push(rubrik);
  }

  onClickDeleteAdditionalTextbox(rubrik : String) {
    for(let i = 0; i < this.allaAdditionalTextbox.length; i++){ 
      if (this.allaAdditionalTextbox[i] === rubrik) { 
        this.allaAdditionalTextbox.splice(i, 1); 
        break;
      }
    }
  }

  onClickDeleteSvarsalternativRadio(svarsalternativ : {value: string, customValue: boolean}) {
    for(let i = 0; i < this.allaSvarsalternativRadio.length; i++){ 
      if (this.allaSvarsalternativRadio[i] === svarsalternativ) { 
        this.allaSvarsalternativRadio.splice(i, 1); 
        break;
      }
    }
  }

  onClickDeleteSvarsalternativDropDown(svarsalternativ: String) {
    for(let i = 0; i < this.allaSvarsalternativDropDown.length; i++){ 
      if (this.allaSvarsalternativDropDown[i] === svarsalternativ) { 
        this.allaSvarsalternativDropDown.splice(i, 1); 
        break;
      }
    }
  }

  changeVerksamhetsomrade(event : any) {
    this.valtVerksamhetsomrade = this.allaVerksamhetsomraden.find(p => p.namn === event.target.value);
  }

  changeUppdrag(event : any) {
    this.valtUppdrag = this.allaUppdrag.find(p => p.namn === event.target.value);
  }

  onClickResetQuestionForm() {
    this.questionForm.reset();
    this.formData.reset();
  }

  onClickVisaFraga(fraga: QuestionBase<any>) {
    this.visaEnskildFraga = true;
    this.fragaAttVisa = fraga;
  }

  onClickTillbakaVisaFraga() {
    this.visaEnskildFraga = false;
  }

  onClickDeleteFraga(fraga: QuestionBase<any>) {
    for(let i = 0; i < this.allaFragor.length; i++) {
      if (this.allaFragor[i] === fraga) { 
        this.allaFragor.splice(i, 1); 
        this.dataSource = new MatTableDataSource(this.allaFragor);
        this.ngAfterViewInit();
        break;
      }
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
}
