import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Arende } from 'src/app/models/arende.model';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { ArendeService } from 'src/app/services/arende.service';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

@Component({
  selector: 'app-dashboards',
  templateUrl: './dashboards.component.html',
  styleUrls: ['./dashboards.component.scss']
})
export class DashboardsComponent implements OnInit {
  title: string = "Dashboards";
  allaAr = ['2021', '2020', '2019'];
  allaKontor = ['Kiruna', 'Umeå', 'Sundsvall', 'Stockholm', 'Gävle', 'Linköping', 'Lund', 'Kalmar', 'Visby', 'Göteborg', 'Eskilstuna'];
  allaArenden: Arende[] = [];
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaUppdrag: Uppdrag[] = [];
  totAntal!: number;

  sorteradeArenden: Arende[] = [];

  arendeChart: any; 
  arendeData: any;
  
  formGenomfordaArenden!: FormGroup;

  constructor(private arendeService : ArendeService, private verksamhetsomradeService: VerksamhetsomradeService, private uppdragService: UppdragService, private fb: FormBuilder) { 
    this.arendeService.getAll().subscribe((data : Arende[]) => {
      this.allaArenden = data;
      this.totAntal = this.allaArenden.length;
      
      let granskadeArenden = this.allaArenden.filter(arende => arende.arGranskad == true);
      let oGranskadeArenden = this.allaArenden.filter(arende => arende.arGranskad == false);
      this.arendeData = [granskadeArenden.length, oGranskadeArenden.length]

      this.arendeChart = {
        labels: ["Genomförda", "Ej genomförda"],
        datasets: [{
          label: "Antal genomförda och ej genomförda ärenden",
          data: this.arendeData,
          backgroundColor: ['#EB6B6D', '#FFE8B1', '#ffd164', '#F8CBCC', '#CFEAEC', '#75c5c9'],
        }],
      }
    })

    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.formGenomfordaArenden = this.fb.group({
      regGenomfordaArendenKontor:[''],
      regGenomfordaArendenAr:[''],
      regGenomfordaArendenVerksamhetsomrade:[''],
      regGenomfordaArendenUppdrag:[''],
    })

    console.log(this.allaArenden);
    
  }

  ngOnInit(): void {

  }

  onChangeSorteringKontor(post: any) {

  }

  onChangeArendeSortering(post: any) {
    this.arendeService.getAll().subscribe((data: Arende[]) => {
      this.allaArenden = data;
      let sorteradeArenden: any = [];

      if (post.regGenomfordaArendenKontor != '') {
        this.allaArenden.forEach(arende => {
          if (arende.kontor === post.regGenomfordaArendenKontor) {
            sorteradeArenden.push(arende);
          }
        })
      } if (post.regGenomfordaArendenAr != '') {
        this.allaArenden.forEach(arende => {
          if (arende.ar === post.regGenomfordaArendenAr) {
            sorteradeArenden.push(arende);
          }
        })      
      } if (post.regGenomfordaArendenVerksamhetsomrade != '') {
        this.allaArenden.forEach(arende => {
          if (arende.verksamhetsomrade.namn === post.regGenomfordaArendenVerksamhetsomrade) {
            sorteradeArenden.push(arende);
          }
        }) 
      } if (post.regGenomfordaArendenUppdrag != '') {
        this.allaArenden.forEach(arende => {
          if (arende.uppdrag.namn === post.regGenomfordaArendenUppdrag) {
            sorteradeArenden.push(arende);
          }
        })
      }

      sorteradeArenden.filter((item: any, index: any) => sorteradeArenden.indexOf(item) === index)

      console.log(sorteradeArenden);
      console.log(this.allaArenden)

      this.totAntal = this.allaArenden.length;
      this.arendeChart = {
        labels: ["Genomförda", "Ej genomförda"],
        datasets: [{
          label: "Antal genomförda och ej genomförda ärenden",
          data: [4,5],
          backgroundColor: ['#EB6B6D', '#FFE8B1', '#ffd164', '#F8CBCC', '#CFEAEC', '#75c5c9'],
        }],
      }

    })
  }

}
