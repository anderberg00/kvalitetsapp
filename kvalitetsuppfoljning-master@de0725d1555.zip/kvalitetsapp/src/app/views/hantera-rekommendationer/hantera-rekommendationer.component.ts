import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Rekommendation } from 'src/app/models/rekommendation.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { RekommendationService } from 'src/app/services/rekommendation.service';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';

@Component({
  selector: 'app-hantera-rekommendationer',
  templateUrl: './hantera-rekommendationer.component.html',
  styleUrls: ['./hantera-rekommendationer.component.scss']
})
export class HanteraRekommendationerComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  title: String = "Hantera rekommendationer";
  dataSource: MatTableDataSource<Rekommendation> = new MatTableDataSource;
  allaRekommendationer: Rekommendation[] = [];
  displayedColumns = ['inskickadAv', 'verksamhetsomrade', 'visa', 'delete']
  
  regForm!: FormGroup;
  regArende!: FormGroup;

  constructor(private router: Router, private rekommendationService: RekommendationService, private fb: FormBuilder) {
  } 

  onClickVisaRekommendation(rekommendation : Rekommendation) {
    this.router.navigate(['/visa-rekommendation', rekommendation.id]);
  }

  onClickDeleteRekommendation(rekommendation : Rekommendation) {
    this.rekommendationService.delete(rekommendation.id).subscribe();
    this.rekommendationService.getAll().subscribe((data: Rekommendation[])=>{
      this.allaRekommendationer = data;
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  ngOnInit() {
    this.rekommendationService.getAll().subscribe((data: Rekommendation[])=>{
      this.allaRekommendationer = data;
      this.dataSource = new MatTableDataSource(data);
      console.log(this.allaRekommendationer);
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

}
