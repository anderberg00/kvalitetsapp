import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HanteraRekommendationerComponent } from './hantera-rekommendationer.component';

describe('HanteraRekommendationerComponent', () => {
  let component: HanteraRekommendationerComponent;
  let fixture: ComponentFixture<HanteraRekommendationerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HanteraRekommendationerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HanteraRekommendationerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
