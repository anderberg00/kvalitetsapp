import { Component, OnInit } from '@angular/core';
import { Arende } from 'src/app/models/arende.model';
import { ArendeService } from 'src/app/services/arende.service';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  title: string = "Min profil"
  anvandare!: string;
  roll!: string;
  mail!: string;

  nbrGenomforda!: number;
  nbrOgenomforda!: number;
  allaMinaArenden: Arende[] = [];

  constructor(private arendeService: ArendeService, private authenticationService: AuthenticationService) {
    this.arendeService.getAll().subscribe((data: Arende[])=>{
      this.allaMinaArenden = data;
      this.nbrGenomforda = this.allaMinaArenden.filter(arende => (arende.arGranskad)).length;
      this.nbrOgenomforda = this.allaMinaArenden.filter(arende => (!arende.arGranskad)).length;
    });
  }

  ngOnInit(): void {
    this.anvandare = this.authenticationService.getNamn();
    this.mail = this.authenticationService.getMail();
    this.roll = this.authenticationService.getRoll();
    console.log(this.roll)
  }

  isAdmin(): boolean {
    if(this.roll == "Admin") {
      return true;
    }
    return false;
  }
}
