import { Component, KeyValueDiffers, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { Uppdrag } from 'src/app/models/uppdrag.model';
import { Verksamhetsomrade } from 'src/app/models/verksamhetsomrade.model';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Kvalitetsmatt } from 'src/app/models/kvalitetsmatt.model';
import { KvalitetsmattService } from 'src/app/services/kvalitetsmatt.service';

@Component({
  selector: 'app-hantera-processer',
  templateUrl: './hantera-processer.component.html',
  styleUrls: ['./hantera-processer.component.scss']
})
export class HanteraProcesserComponent implements OnInit {
  title: string = "Hantera processer";
  allaVerksamhetsomraden: Verksamhetsomrade[] = [];
  allaUppdrag: Uppdrag[] = [];
  allaKvalitetsmatt: Kvalitetsmatt[] = [];

  uppdragForm!: FormGroup;
  verksamhetsomradeForm!: FormGroup;
  kvalitetsmattForm!: FormGroup;

  constructor(private kvalitetsmattService: KvalitetsmattService, private snackBar: MatSnackBar, private uppdragService: UppdragService, private verksamhetsomradeService: VerksamhetsomradeService, private router: Router, private fb: FormBuilder) { 
    this.uppdragForm = this.fb.group({
      regUppdragNamn: ['', Validators.required],
    })

    this.verksamhetsomradeForm = this.fb.group({
      regVerksamhetsomradeNamn:['', Validators.required]
    })

    this.kvalitetsmattForm = this.fb.group({
      regKvalitetsmattNamn:['', Validators.required]
    })

    this.uppdragService.getAll().subscribe((data: Uppdrag[])=>{
      this.allaUppdrag = data;
    });

    this.verksamhetsomradeService.getAll().subscribe((data: Verksamhetsomrade[])=>{
      this.allaVerksamhetsomraden = data;
    });

    this.kvalitetsmattService.getAll().subscribe((data: Kvalitetsmatt[])=>{
      this.allaKvalitetsmatt = data;
    });
  }

  ngOnInit(): void {
  
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action);
  }

  onClickRedigeraVerksamhetsomrade(verksamhetsomrade: Verksamhetsomrade) {
    this.router.navigate(['/redigera-verksamhetsomrade', verksamhetsomrade.namn]);
  }

  onClickTaBortVerksamhetsomrade(verksamhetsomrade: Verksamhetsomrade) {
    this.allaVerksamhetsomraden = this.allaVerksamhetsomraden.filter(v => v !== verksamhetsomrade);
    this.verksamhetsomradeService.delete(verksamhetsomrade).subscribe();
  }

  onClickTaBortUppdrag(uppdrag: Uppdrag) {
    this.allaUppdrag = this.allaUppdrag.filter(u => u !== uppdrag);
    this.uppdragService.delete(uppdrag).subscribe();
  }

  onClickTaBortKvalitetsmatt(kvalitetsmatt: Kvalitetsmatt) {
    this.allaKvalitetsmatt = this.allaKvalitetsmatt.filter(u => u !== kvalitetsmatt);
    this.kvalitetsmattService.delete(kvalitetsmatt).subscribe();
  }

  onClickResetUppdrag() {
    this.uppdragForm.reset();
  }

  onClickResetVerksamhetsomrade() {
    this.verksamhetsomradeForm.reset();
  }

  onClickResetKvalitetsmatt() {
    this.kvalitetsmattForm.reset();
  }

  onClickAddUppdrag(data: any) {
    if (data.regUppdragNamn === "" || null) {
      this.openSnackBar("Du måste ange ett namn på uppdraget", "Stäng");
      return;
    }

    let u : Uppdrag = {
      namn: data.regUppdragNamn,
    };

    this.allaUppdrag.push(u);
    this.uppdragService.add(u).subscribe();
    this.uppdragForm.reset();
  }

  onClickAddVerksamhetsomrade(data: any) {
    if (data.regVerksamhetsomradeNamn === "" || null) {
      this.openSnackBar("Du måste ange ett namn på verksamhetsområdet", "Stäng");
      return;
    }

    let v : Verksamhetsomrade = {
      namn: data.regVerksamhetsomradeNamn,
      information: []
    }

    this.allaVerksamhetsomraden.push(v);
    this.verksamhetsomradeService.add(v).subscribe();
    this.verksamhetsomradeForm.reset();
  }

  onClickAddKvalitetsmatt(data: any) {
    if (data.regKvalitetsmattNamn === "" || null) {
      this.openSnackBar("Du måste ange ett namn på kvalitetsmåttet", "Stäng");
      return;
    }

    let k : Kvalitetsmatt = {
      namn: data.regKvalitetsmattNamn,
    }

    this.allaKvalitetsmatt.push(k);
    this.kvalitetsmattService.add(k).subscribe();
    this.kvalitetsmattForm.reset();
  }
 

}
