import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MinaArendenComponent } from './mina-arenden.component';

describe('MinaArendenComponent', () => {
  let component: MinaArendenComponent;
  let fixture: ComponentFixture<MinaArendenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MinaArendenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MinaArendenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
