import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Arende } from 'src/app/models/arende.model';
import { ArendeService } from 'src/app/services/arende.service';

@Component({
  selector: 'app-mina-arenden',
  templateUrl: './mina-arenden.component.html',
  styleUrls: ['./mina-arenden.component.scss']
})


export class MinaArendenComponent {
  @ViewChild('paginatorFirst') paginatorFirst!: MatPaginator;
  @ViewChild('paginatorSecond') paginatorSecond!: MatPaginator;
  @ViewChild('sortFirst') sortFirst!: MatSort;
  @ViewChild('sortSecond') sortSecond!: MatSort;
  
  title: string = "Mina ärenden";
  displayedColumns = ['status', 'verksamhetsomrade', 'uppdrag', 'slutdatum','enkat'];

  allaMinaArenden: Arende[] = [];
  sorteradeArenden: Arende[] = [];
  fardiggranskadeArenden: Arende[] = [];
  ofardiggranskadeArenden: Arende[] = [];
  narmasteSlutdatum: string = '4';

  dataSource1!: MatTableDataSource<Arende>;
  dataSource2!: MatTableDataSource<Arende>;
  
  constructor(private arendeService: ArendeService, private router: Router) { 
  }
  
  ngOnInit() {
    this.arendeService.getAll().subscribe((data: Arende[])=>{
      this.allaMinaArenden = data;

      this.fardiggranskadeArenden = this.allaMinaArenden.filter(arende => (arende.arGranskad));

      this.ofardiggranskadeArenden = this.allaMinaArenden.filter(arende => (!arende.arGranskad));

      this.dataSource2 = new MatTableDataSource(this.fardiggranskadeArenden);
      this.dataSource2.sortingDataAccessor = (item : any, property : any) => {
        switch(property) {
          case 'verksamhetsomrade': return item.verksamhetsomrade.namn;
          case 'uppdrag': return item.uppdrag.namn;
          default: return item[property];
        }
      };
      this.dataSource2.paginator = this.paginatorSecond;
      this.dataSource2.sort = this.sortSecond;

      this.dataSource1 = new MatTableDataSource(this.ofardiggranskadeArenden);
      this.dataSource1.sortingDataAccessor = (item : any, property : any) => {
        switch(property) {
          case 'verksamhetsomrade': return item.verksamhetsomrade.namn;
          case 'uppdrag': return item.uppdrag.namn;
          default: return item[property];
        }
      };
      this.dataSource1.sort = this.sortFirst;
      this.dataSource1.paginator = this.paginatorFirst;
    }); 
  }

  ngAfterViewInit() {
    
  }

  onClickVisaEnkatShowOnly(arende: Arende) {
    this.router.navigate(['/visa-enkatsvar/', arende.id])
  }

  onClickVisaEnkat(arende : Arende) {
    this.router.navigate(['/visa-arende/', arende.id]);
  }
}
