import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HanteraArendenComponent } from './hantera-arenden.component';

describe('HanteraArendenComponent', () => {
  let component: HanteraArendenComponent;
  let fixture: ComponentFixture<HanteraArendenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HanteraArendenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HanteraArendenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
