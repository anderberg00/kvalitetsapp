import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSort, Sort } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { VerksamhetsomradeService } from 'src/app/services/verksamhetsomrade.service';
import { UppdragService } from 'src/app/services/uppdrag.service';
import { ArendeService } from 'src/app/services/arende.service';
import { Arende } from 'src/app/models/arende.model';

@Component({
  selector: 'app-hantera-arenden',
  templateUrl: './hantera-arenden.component.html',
  styleUrls: ['./hantera-arenden.component.scss']
})

export class HanteraArendenComponent implements OnInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  title: string = "Hantera ärenden";
  displayedColumns = ['status', 'verksamhetsomrade', 'uppdrag', 'handlaggareNotifiering', 'forstaHandlaggare', 'andraHandlaggare', 'slutdatum', 'visa', 'redigera'];

  allaArenden: Arende[] = [];
  dataSource!: MatTableDataSource<Arende>;

  constructor(private router: Router, private arendeService: ArendeService) {
    
  }

  ngAfterViewInit() {
    
  }

  ngOnInit(): void {
    this.arendeService.getAll().subscribe((data: Arende[])=>{
      this.allaArenden = data;
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.sortingDataAccessor = (item : any, property : any) => {
        switch(property) {
          case 'verksamhetsomrade': return item.verksamhetsomrade.namn;
          case 'uppdrag': return item.uppdrag.namn;
          default: return item[property];
        }
      };
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });   
  }

  onClickRedigeraArende(arende: Arende) {
    this.router.navigate(['/redigera-arende', arende.id]);
  }

  onClickVisaArende(arende: Arende) {
    this.router.navigate(['/visa-arende-admin/', arende.id]);
  }

  onClickNyttArende() {
    this.router.navigate(['/registrera-arenden/']);
  }

}
