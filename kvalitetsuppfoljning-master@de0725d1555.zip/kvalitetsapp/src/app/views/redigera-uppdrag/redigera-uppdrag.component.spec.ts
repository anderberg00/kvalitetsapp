import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RedigeraUppdragComponent } from './redigera-uppdrag.component';

describe('RedigeraUppdragComponent', () => {
  let component: RedigeraUppdragComponent;
  let fixture: ComponentFixture<RedigeraUppdragComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RedigeraUppdragComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RedigeraUppdragComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
