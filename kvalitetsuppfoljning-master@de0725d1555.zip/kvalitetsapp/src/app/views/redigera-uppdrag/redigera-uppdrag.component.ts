import { Component, OnInit } from '@angular/core';
import { Uppdrag } from 'src/app/models/uppdrag.model';

@Component({
  selector: 'app-redigera-uppdrag',
  templateUrl: './redigera-uppdrag.component.html',
  styleUrls: ['./redigera-uppdrag.component.scss']
})
export class RedigeraUppdragComponent implements OnInit {
  title: string = "Redigera uppdrag";
  uppdragAttVisa!: Uppdrag;

  constructor() { 
    this.uppdragAttVisa = {
      namn: 'Årsredovisning',
    };
  }

  ngOnInit(): void {
  }

}
