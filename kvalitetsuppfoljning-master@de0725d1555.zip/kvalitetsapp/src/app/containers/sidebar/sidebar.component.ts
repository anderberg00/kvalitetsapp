import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Arende } from 'src/app/models/arende.model';
import { ArendeService } from 'src/app/services/arende.service';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  nbrToDo: number = 0;
  allaArenden: Arende[] = [];

  arAdmin!: boolean;
  visaArendeSubmeny: boolean = false;
  visaHanteraSubmeny: boolean = false;
  visaStatistikSubmeny: boolean = false;

  constructor(private arendeService: ArendeService, private router: Router, private authenticationService : AuthenticationService) { 
    this.arendeService.getAll().subscribe((data: Arende[]) => {
      this.allaArenden = data;
      this.nbrToDo = this.allaArenden.filter(arende => !arende.arGranskad).length;
    }) 
  }

  ngOnInit(): void {
    this.arAdmin = this.authenticationService.checkArAdmin();
  }

  isArAdmin(): boolean{
    return this.arAdmin;
  }

  onClickArenden() {
    if (this.visaArendeSubmeny == false) {
      this.visaArendeSubmeny = true;
    } else {
      this.visaArendeSubmeny = false;
    }
  }

  onClickHantera() {
    if (this.visaHanteraSubmeny == false) {
      this.visaHanteraSubmeny = true;
    } else {
      this.visaHanteraSubmeny = false;
    }
  }

  onClickStatistik() {
    if (this.visaStatistikSubmeny == false) {
      this.visaStatistikSubmeny = true;
    } else {
      this.visaStatistikSubmeny = false;
    }
  }

}
