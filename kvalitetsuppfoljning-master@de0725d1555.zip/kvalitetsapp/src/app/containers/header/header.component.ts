import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  profileText: string = "Min profil";
  logOutText: string = "Logga ut";
  
  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  onClickLogOut() {
    this.router.navigateByUrl("/logga-in");
    return; //Login-logic to be implemented...
  }

  onClickProfile() {
    this.router.navigateByUrl("/profile");
    return;
  }

}
