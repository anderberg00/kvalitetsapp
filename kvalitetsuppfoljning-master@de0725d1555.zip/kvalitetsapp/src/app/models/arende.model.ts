import { UUID } from "angular2-uuid";
import { QuestionBase } from "../questionnaire/question-base";
import { DropdownQuestion } from "../questionnaire/question-dropdown";
import { RadiobuttonQuestion } from "../questionnaire/question-radiobutton";
import { Enkat } from "./enkat.model";
import { Enkatsvar } from "./enkatsvar.model";
import { Uppdrag } from "./uppdrag.model";
import { Verksamhetsomrade } from "./verksamhetsomrade.model";

export class Arende {
    ar!: string;
    kontor!: string;
    slutdatum!: string;
    notifieringsdatum!: string;
    handlaggareNotifiering!: string;
    forstaHandlaggare?: string;
    andraHandlaggare?: string;
    verksamhetsomrade!: Verksamhetsomrade;
    uppdrag!: Uppdrag;
    id!: string;
    enkat!: Enkat;
    status!: string;
    arGranskad!: boolean;
    //Key är tagna från verksamhetsområdet, value läses in vid registrering
    varden!: { key: string; value: string; }[];
}
    // constructor(
    //     ar: string, 
    //     kontor: string, 
    //     slutdatum: string, 
    //     notifieringsdatum: string, 
    //     handlaggareNotifiering: string, 
    //     verksamhetsomrade: Verksamhetsomrade, 
    //     uppdrag: Uppdrag,
    //     varden?: {key: string; value: string} [],
    //     forstaHandlaggare?: string, 
    //     andraHandlaggare?: string,
    //      ) {
    //     this._ar = ar;
    //     this._kontor = kontor;
    //     this._slutdatum = slutdatum;
    //     this._notifieringsdatum = notifieringsdatum;
    //     this._handlaggareNotifiering = handlaggareNotifiering;
    //     this._forstaHandlaggare = forstaHandlaggare || undefined;
    //     this._andraHandlaggare = andraHandlaggare || undefined;
    //     this._verksamhetsomrade = verksamhetsomrade;
    //     this._uppdrag = uppdrag;
    //     this._varden = varden || [];
    //     this._enkat = this.setEnkat();
    //     this._granskningsnummer = UUID.UUID();
    //     this._status = this.setStatus();
    // }

 /*    public get ar(): string {
      return this._ar;
    }
    public set ar(value: string) {
      this._ar = value;
    }
  
    public get kontor(): string {
      return this._kontor;
    }
    public set kontor(value: string) {
      this._kontor = value;
    }

    public get slutdatum(): string {
      return this._slutdatum;
    }
    public set slutdatum(value: string) {
      this._slutdatum = value;
    }

    public get notifieringsdatum(): string {
      return this._notifieringsdatum;
    }
    public set notifieringsdatum(value: string) {
      this._notifieringsdatum = value;
    }

    public get handlaggareNotifiering(): string {
      return this._handlaggareNotifiering;
    }
    public set handlaggareNotifiering(value: string) {
      this._handlaggareNotifiering = value;
    }

    public get forstaHandlaggare(): string | undefined {
      return this._forstaHandlaggare;
    }
    public set forstaHandlaggare(value: string | undefined) {
      this._forstaHandlaggare = value;
    }

    public get andraHandlaggare(): string | undefined {
      return this._andraHandlaggare;
    }
    public set andraHandlaggare(value: string | undefined) {
      this._andraHandlaggare = value;
    }

    public get verksamhetsomrade(): Verksamhetsomrade {
      return this._verksamhetsomrade;
    }
    public set verksamhetsomrade(value: Verksamhetsomrade) {
      this._verksamhetsomrade = value;
    }

    public get uppdrag(): Uppdrag {
      return this._uppdrag;
    }
    public set uppdrag(value: Uppdrag) {
      this._uppdrag = value;
    }

    public get granskningsnummer(): string {
      return this._granskningsnummer;
    }
    public set granskningsnummer(value: string) {
      this._granskningsnummer = value;
    }

    public get enkat(): Enkat {
      return this._enkat;
    }
    public set enkat(value: Enkat) {
      this._enkat = value;
    }

    public get status(): string {
      return this._status;
    }
    public set status(value: string) {
      this._status = value;
    }
    public get varden(): { key: string; value: string; }[] | undefined {
      return this._varden;
    }
    public set varden(value: { key: string; value: string; }[] | undefined) {
      this._varden = value;
    } */

    /* setEnkat() {
        const questions: QuestionBase<any>[] = [

            new DropdownQuestion({
              key: 'testardropdown',
              label: "Testar en dropdown question",
              order: 4,
              options: [
                {key: 'answer1', value: 'Lund', customValue: true},
                {key: 'answer2', value: 'Göteborg', customValue: false},
              ]
            }),
      
            new RadiobuttonQuestion({
              key: 'beslutstyp',
              label: 'Vilken typ av beslut följer du upp?',
              order: 2,
              options: [
                {key: 'answer1',  value: 'Manuellt', customValue: false},
                {key: 'answer2',  value: 'Maskinellt', customValue: false},
              ]
            }),
      
          new RadiobuttonQuestion({
            key: 'gender',
            label: 'Vilket kön har personen?',
            order: 1,
            options: [
              {key: 'answer1',  value: 'Kvinna', customValue: false},
              {key: 'answer2',  value: 'Man', customValue: false}
            ]
          })];
        
          let v : Verksamhetsomrade = {
            namn: "Hemutrustningslån",
            information: [
              {key: "Lånenummer", visaHandlaggare: true, kolumnExcel: "9"},
              {key: "Beslutsdatum", visaHandlaggare: true, kolumnExcel: "10"},
              {key: "Kön", visaHandlaggare: false, kolumnExcel: "11"},
              ]
            }
        let uppdrag: Uppdrag = {
          namn: 'Lärtriad',
        };

        return new Enkat("Enkät 1",v, uppdrag, questions);
    } */


 