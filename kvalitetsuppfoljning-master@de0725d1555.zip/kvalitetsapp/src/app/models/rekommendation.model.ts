import { Verksamhetsomrade } from "./verksamhetsomrade.model";

export  class Rekommendation {
    private _id!: String;
    private _inskickadAv!: String;
    private _verksamhetsomrade!: Verksamhetsomrade;
    private _motivering!: string;
    private _varden!: { key: string; value: string; }[];

    public get varden(): { key: string; value: string; }[] {
        return this._varden;
    }
    
    public set varden(value: { key: string; value: string; }[]) {
        this._varden = value;
    }

    public get motivering(): string {
        return this._motivering;
    }
    public set motivering(value: string) {
        this._motivering = value;
    }

    public get verksamhetsomrade(): Verksamhetsomrade {
        return this._verksamhetsomrade;
    }
    public set verksamhetsomrade(value: Verksamhetsomrade) {
        this._verksamhetsomrade = value;
    }

    public get id(): String {
        return this._id;
    }
    public set id(value: String) {
        this._id = value;
    }

    public get inskickadAv(): String {
        return this._inskickadAv;
    }
    public set inskickadAv(value: String) {
        this._inskickadAv = value;
    }

}