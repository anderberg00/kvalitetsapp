export class User {
    username!: string;
    fornamn!: string;
    efternamn!: string;
    mail!: string;
    password!: string;
    arAdmin!: boolean;
}
