import { QuestionBase } from "../questionnaire/question-base";
import { Enkat } from "./enkat.model";


export class Enkatsvar {
    questionBases!: QuestionBase<any>[];
    inskickadAv!: string;
}
