export class Uppdrag {
    namn!: string;
}
