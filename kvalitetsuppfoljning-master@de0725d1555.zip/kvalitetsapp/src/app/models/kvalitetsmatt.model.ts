export class Kvalitetsmatt {
    namn!: string;
}