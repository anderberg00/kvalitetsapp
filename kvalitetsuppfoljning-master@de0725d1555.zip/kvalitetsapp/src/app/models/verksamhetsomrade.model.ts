export class Verksamhetsomrade {
  namn!: string;
  information!: { key: string; visaHandlaggare: boolean; kolumnExcel: string; }[];
}



