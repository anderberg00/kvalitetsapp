import { Observable } from "rxjs";
import { QuestionBase } from "../questionnaire/question-base";
import { Uppdrag } from "./uppdrag.model";
import { Verksamhetsomrade } from "./verksamhetsomrade.model";

export class Enkat {
    questionBases!: QuestionBase<any>[];
    namn!: string;
    id!: string;
    verksamhetsomrade!: Verksamhetsomrade;
    uppdrag!: Uppdrag;
}


