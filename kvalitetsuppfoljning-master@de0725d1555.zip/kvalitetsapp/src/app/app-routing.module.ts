import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './views/login/login.component';
import { ProfileComponent } from './views/profile/profile.component';
import { StatisticsComponent } from './views/statistics/statistics.component';
import { DashboardsComponent } from './views/dashboards/dashboards.component';
import { MinaArendenComponent } from './views/mina-arenden/mina-arenden.component';
import { HandbokComponent } from './views/handbok/handbok.component';
import { HanteraProcesserComponent } from './views/hantera-processer/hantera-processer.component';
import { HanteraArendenComponent } from './views/hantera-arenden/hantera-arenden.component';
import { RedigeraArendeComponent } from './views/redigera-arende/redigera-arende.component';
import { VisaArendeComponent } from './views/visa-arende/visa-arende.component';
import { RedigeraUppdragComponent } from './views/redigera-uppdrag/redigera-uppdrag.component';
import { RedigeraVerksamhetsomradeComponent } from './views/redigera-verksamhetsomrade/redigera-verksamhetsomrade.component';
import { RegistreraArendenComponent } from './views/registrera-arenden/registrera-arenden.component';
import { HanteraEnkaterComponent } from './views/hantera-enkater/hantera-enkater.component';
import { RedigeraEnkatComponent } from './views/redigera-enkat/redigera-enkat.component';
import { SkapaEnkatComponent } from './views/skapa-enkat/skapa-enkat.component';
import { VisaEnkatComponent } from './views/visa-enkat/visa-enkat.component';
import { VisaArendeAdminComponent } from './views/visa-arende-admin/visa-arende-admin.component';
import { HanteraRekommendationerComponent } from './views/hantera-rekommendationer/hantera-rekommendationer.component';
import { RekommenderaArendenComponent } from './views/rekommendera-arende/rekommendera-arenden.component';
import { VisaRekommendationComponent } from './views/visa-rekommendation/visa-rekommendation.component';
import { VisaEnkatsvarComponent } from './views/visa-enkatsvar/visa-enkatsvar.component';

const routes: Routes = [
   { path: 'logga-in', component: LoginComponent},
   { path: 'registrera-arenden', component: RegistreraArendenComponent},
   { path: 'enkatsvar', component: StatisticsComponent},
   { path: 'profile', component: ProfileComponent},
   { path: 'dashboards', component: DashboardsComponent},
   { path: 'mina-arenden', component: MinaArendenComponent},
   { path: 'hantera-arenden', component: HanteraArendenComponent},
   { path: 'handbok', component: HandbokComponent},
   { path: 'hantera-processer', component: HanteraProcesserComponent},
   { path: 'redigera-arende/:granskningsnummer', component: RedigeraArendeComponent},
   { path: 'visa-arende/:granskningsnummer', component: VisaArendeComponent},
   { path: 'visa-arende-admin/:granskningsnummer', component: VisaArendeAdminComponent},
   { path: 'redigera-uppdrag/:namn', component: RedigeraUppdragComponent},
   { path: 'redigera-verksamhetsomrade/:namn', component: RedigeraVerksamhetsomradeComponent},
   { path: 'hantera-enkater', component: HanteraEnkaterComponent},
   { path: 'visa-enkat/:namn', component: VisaEnkatComponent},
   { path: 'visa-rekommendation/:id', component: VisaRekommendationComponent},
   { path: 'redigera-enkat', component: RedigeraEnkatComponent},
   { path: 'skapa-enkat', component: SkapaEnkatComponent},
   { path: 'hantera-rekommendationer', component: HanteraRekommendationerComponent},
   { path: 'rekommendera-arenden', component: RekommenderaArendenComponent},
   { path: 'visa-enkatsvar/:granskningsnummer', component: VisaEnkatsvarComponent},
   { path: '**', component: LoginComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

}
